// Notification and Help dropdowns
const notifIcon = document.getElementById('notifIcon');
const helpIcon = document.getElementById('helpIcon');
const notifDropdown = document.getElementById('notifDropdown');
const helpDropdown = document.getElementById('helpDropdown');

notifIcon.addEventListener('click', () => {
  notifDropdown.classList.toggle('show');
  helpDropdown.classList.remove('show');
});

helpIcon.addEventListener('click', () => {
  helpDropdown.classList.toggle('show');
  notifDropdown.classList.remove('show');
});

document.addEventListener('click', (e) => {
  if (!e.target.closest('.icons')) {
    notifDropdown.classList.remove('show');
    helpDropdown.classList.remove('show');
  }
});

// Auto-Hide Topbar Functionality
function initializeAutoHideTopbar() {
 const searchHeader = document.querySelector('.search-header');
 const mainContent = document.querySelector('.main');
 
 if (!searchHeader) return;
 
 window.addEventListener('scroll', function() {
   if (!autoHideEnabled) return;
   
   didScroll = true;
   
   if (scrollTimer) {
     clearTimeout(scrollTimer);
   }
   
   scrollTimer = setTimeout(function() {
     if (didScroll) {
       handleScroll();
       didScroll = false;
     }
   }, 100);
 });
 
 function handleScroll() {
   const currentScrollTop = window.pageYOffset || document.documentElement.scrollTop;
   
   if (Math.abs(lastScrollTop - currentScrollTop) <= scrollDelta) {
     return;
   }
   
   if (shouldDisableAutoHide()) {
     return;
   }
   
   if (currentScrollTop > lastScrollTop && currentScrollTop > navbarHeight) {
     hideTopbar();
   } else {
     if (currentScrollTop + window.innerHeight < document.documentElement.scrollHeight) {
       showTopbar();
     }
   }
   
   lastScrollTop = currentScrollTop;
 }
 
 function hideTopbar() {
   searchHeader.classList.add('header-hidden');
   searchHeader.classList.remove('header-visible');
   searchHeader.classList.add('scrolling-down');
   searchHeader.classList.remove('scrolling-up');
   
   if (mainContent) {
     mainContent.classList.add('header-hidden');
   }
 }
 
 function showTopbar() {
   searchHeader.classList.remove('header-hidden');
   searchHeader.classList.add('header-visible');
   searchHeader.classList.remove('scrolling-down');
   searchHeader.classList.add('scrolling-up');
   
   if (mainContent) {
     mainContent.classList.remove('header-hidden');
   }
 }
 
 function handleTopOfPage() {
   const currentScrollTop = window.pageYOffset || document.documentElement.scrollTop;
   
   if (currentScrollTop <= 0) {
     showTopbar();
   }
 }
 
 window.addEventListener('scroll', handleTopOfPage);
 
 // Touch event support for mobile
 let touchStartY = 0;
 let touchEndY = 0;
 
 document.addEventListener('touchstart', function(e) {
   touchStartY = e.changedTouches[0].screenY;
 });
 
 document.addEventListener('touchend', function(e) {
   touchEndY = e.changedTouches[0].screenY;
   handleTouchGesture();
 });
 
 function handleTouchGesture() {
   if (!autoHideEnabled) return;
   
   const currentScrollTop = window.pageYOffset || document.documentElement.scrollTop;
   
   if (touchEndY > touchStartY && currentScrollTop > navbarHeight) {
     showTopbar();
   } else if (touchEndY < touchStartY && currentScrollTop > navbarHeight) {
     hideTopbar();
   }
 }
}

// Enhanced scroll behavior
function initializeEnhancedScrollBehavior() {
 let scrollTimeout;
 
 window.addEventListener('scroll', function() {
   document.body.classList.add('is-scrolling');
   
   window.clearTimeout(scrollTimeout);
   
   scrollTimeout = setTimeout(function() {
     document.body.classList.remove('is-scrolling');
   }, 100);
 });
}

// Check if auto-hide should be disabled
function shouldDisableAutoHide() {
 const modal = document.getElementById('modal');
 if (modal && !modal.classList.contains('hidden')) {
   return true;
 }
 
 const openDropdowns = document.querySelectorAll('.dropdown.show');
 if (openDropdowns.length > 0) {
   return true;
 }
 
 if (window.innerHeight < 600) {
   return true;
 }
 
 return false;
}

// Respect user's motion preferences
function respectsReducedMotion() {
 return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

// Initialize auto-hide with preferences
function initializeAutoHideWithPreferences() {
 if (respectsReducedMotion()) {
   console.log('Auto-hide disabled due to user motion preferences');
   return;
 }
 
 initializeAutoHideTopbar();
 initializeEnhancedScrollBehavior();
}

// Manual toggle for auto-hide feature
function initializeManualToggle() {
 const toggleButton = document.getElementById('toggleAutoHide');
 
 if (toggleButton) {
   toggleButton.addEventListener('click', function() {
     autoHideEnabled = !autoHideEnabled;
     
     if (autoHideEnabled) {
       toggleButton.title = 'Disable auto-hide topbar';
       showNotification('Auto-hide enabled', 'info');
     } else {
       toggleButton.title = 'Enable auto-hide topbar';
       
       const searchHeader = document.querySelector('.search-header');
       const mainContent = document.querySelector('.main');
       if (searchHeader) {
         searchHeader.classList.remove('header-hidden', 'scrolling-down');
         searchHeader.classList.add('header-visible');
       }
       if (mainContent) {
         mainContent.classList.remove('header-hidden');
       }
       showNotification('Auto-hide disabled', 'info');
     }
   });
 }
}

document.addEventListener('DOMContentLoaded', function() {
  initializeAutoHideWithPreferences();
  initializeManualToggle();
  initializeDropdowns();
});

// Auto-Hide Topbar Variables
let lastScrollTop = 0;
let scrollDelta = 5;
let navbarHeight = 80;
let didScroll = false;
let scrollTimer = null;
let autoHideEnabled = true;

// Chart configurations
Chart.defaults.font.family = "'Segoe UI', sans-serif";
Chart.defaults.color = '#666';

// Patient Visits vs Deliveries Chart
const visitsCtx = document.getElementById('visitsChart').getContext('2d');
const visitsChart = new Chart(visitsCtx, {
  type: 'bar',
  data: {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
      {
        label: 'Patient Visits',
        data: [45, 52, 48, 58, 55, 65],
        backgroundColor: '#ef4444',
        borderRadius: 4,
        barThickness: 20
      },
      {
        label: 'Deliveries',
        data: [8, 12, 10, 15, 18, 22],
        backgroundColor: '#fca5a5',
        borderRadius: 4,
        barThickness: 20
      }
    ]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom',
        labels: {
          usePointStyle: true,
          padding: 20
        }
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 80,
        grid: {
          color: '#f3f4f6'
        }
      },
      x: {
        grid: {
          display: false
        }
      }
    }
  }
});

// Patient Distribution Pie Chart
const distributionCtx = document.getElementById('distributionChart').getContext('2d');
const distributionChart = new Chart(distributionCtx, {
  type: 'doughnut',
  data: {
    labels: ['Prenatal', 'Postnatal', 'Gynecology'],
    datasets: [{
      data: [60, 25, 15],
      backgroundColor: [
        '#ef4444',
        '#fca5a5',
        '#22c55e'
      ],
      borderWidth: 2,
      borderColor: '#ffffff'
    }]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'right',
        labels: {
          usePointStyle: true,
          padding: 20,
          generateLabels: function(chart) {
            const data = chart.data;
            if (data.labels.length && data.datasets.length) {
              return data.labels.map((label, i) => {
                const dataset = data.datasets[0];
                const value = dataset.data[i];
                return {
                  text: `${label} ${value}%`,
                  fillStyle: dataset.backgroundColor[i],
                  strokeStyle: dataset.backgroundColor[i],
                  pointStyle: 'circle'
                };
              });
            }
            return [];
          }
        }
      }
    },
    cutout: '60%'
  }
});

// Appointment Trends Line Chart
const appointmentCtx = document.getElementById('appointmentChart').getContext('2d');
const appointmentChart = new Chart(appointmentCtx, {
  type: 'line',
  data: {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [{
      label: 'Patient Visits',
      data: [45, 52, 48, 58, 55, 65],
      borderColor: '#ef4444',
      backgroundColor: 'rgba(239, 68, 68, 0.1)',
      borderWidth: 3,
      fill: true,
      tension: 0.4,
      pointBackgroundColor: '#ef4444',
      pointBorderColor: '#ffffff',
      pointBorderWidth: 2,
      pointRadius: 6
    }]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 80,
        grid: {
          color: '#f3f4f6'
        }
      },
      x: {
        grid: {
          display: false
        }
      }
    },
    elements: {
      point: {
        hoverRadius: 8
      }
    }
  }
});

// Export functions
function exportToPDF() {
  alert('PDF export functionality would be implemented here');
}

function exportToExcel() {
  alert('Excel export functionality would be implemented here');
}

function downloadChart(chartId) {
  let chart;
  switch(chartId) {
    case 'visitsChart':
      chart = visitsChart;
      break;
    case 'distributionChart':
      chart = distributionChart;
      break;
    case 'appointmentChart':
      chart = appointmentChart;
      break;
  }
  
  if (chart) {
    const url = chart.toBase64Image();
    const link = document.createElement('a');
    link.download = `${chartId}_chart.png`;
    link.href = url;
    link.click();
  }
}

// Filter change handlers
document.getElementById('reportType').addEventListener('change', function() {
  // Update charts based on report type
  console.log('Report type changed to:', this.value);
});

document.getElementById('timeRange').addEventListener('change', function() {
  // Update charts based on time range
  console.log('Time range changed to:', this.value);
});