// Firebase Configuration - Enhanced for cross-platform compatibility
const firebaseConfig = {
  apiKey: "AIzaSyBGPYM5JHrSXOd9PWbQ4TzoqUtlf5qCwjs",
  authDomain: "pregnacare-web.firebaseapp.com",
  databaseURL: "https://pregnacare-web-default-rtdb.firebaseio.com",
  projectId: "pregnacare-web",
  storageBucket: "pregnacare-web.firebasestorage.app",
  messagingSenderId: "408625794290",
  appId: "1:408625794290:web:bb131c8b35869b31acd46b",
  measurementId: "G-HZB017TYX3"
};

// Initialize Firebase with error handling
let database, auth, messaging;
try {
  firebase.initializeApp(firebaseConfig);
  database = firebase.database();
  auth = firebase.auth();
  messaging = firebase.messaging && firebase.messaging.isSupported() ? firebase.messaging() : null;
  console.log('✅ Firebase initialized successfully');
} catch (error) {
  console.error('❌ Firebase initialization failed:', error);
  showToast('Failed to initialize messaging system', 'error');
}

// Global Variables
let currentUser = null;
let currentConversation = null;
let conversations = {};
let users = {};
let messageListeners = {};
let presenceRef = null;
let notificationPermission = 'default';
let isInitialized = false;

// Database References - Structured for mobile app compatibility
const DatabasePaths = {
  USERS: 'users',
  CONVERSATIONS: 'conversations',
  MESSAGES: 'messages',
  USER_CONVERSATIONS: 'userConversations',
  PRESENCE: 'presence',
  NOTIFICATIONS: 'notifications',
  APP_METADATA: 'appMetadata'
};

// DOM Elements - with null checks
const getElement = (id) => document.getElementById(id);
let conversationsList, chatArea, newMessageModal, connectionIndicator, 
    connectionText, connectionIcon, toastContainer, unreadCount;

// Initialize App
document.addEventListener('DOMContentLoaded', function() {
  console.log('🚀 Initializing PregnaCare Messages System...');
  
  // Initialize DOM elements
  initializeDOMElements();
  
  if (!validateRequiredElements()) {
    console.error('❌ Required DOM elements not found');
    return;
  }
  
  initializeAuth();
  setupEventListeners(); // FIXED: Added this missing call
  setupNotifications();
  loadUsers();
  updateConnectionStatus('connecting');
  handlePageNavigation();
  
  // Initialize real-time connection monitoring
  monitorConnectionStatus();
  
  isInitialized = true;
});

// Initialize DOM elements with error handling
function initializeDOMElements() {
  conversationsList = getElement('conversationsList');
  chatArea = getElement('chatArea');
  newMessageModal = getElement('newMessageModal');
  connectionIndicator = getElement('connectionIndicator');
  connectionText = getElement('connectionText');
  connectionIcon = getElement('connectionIcon');
  toastContainer = getElement('toastContainer');
  unreadCount = getElement('unreadCount');
}

// Validate required DOM elements
function validateRequiredElements() {
  const required = [conversationsList, chatArea, toastContainer];
  return required.every(element => element !== null);
}

// Enhanced event listeners setup with proper error handling
function setupEventListeners() {
  console.log('🎯 Setting up event listeners...');
  
  try {
    // New Message Button
    const newMessageBtn = getElement('newMessageBtn');
    if (newMessageBtn) {
      newMessageBtn.addEventListener('click', (e) => {
        e.preventDefault();
        console.log('📝 New message button clicked');
        openNewMessageModal();
      });
      console.log('✅ New message button listener added');
    } else {
      console.warn('⚠️ New message button not found');
    }
    
    // Refresh Messages Button
    const refreshBtn = getElement('refreshMessages');
    if (refreshBtn) {
      refreshBtn.addEventListener('click', (e) => {
        e.preventDefault();
        console.log('🔄 Refresh button clicked');
        refreshMessages();
      });
      console.log('✅ Refresh button listener added');
    } else {
      console.warn('⚠️ Refresh button not found');
    }
    
    // Close Modal Button
    const closeBtn = getElement('closeModal');
    if (closeBtn) {
      closeBtn.addEventListener('click', (e) => {
        e.preventDefault();
        closeModalHandler();
      });
      console.log('✅ Close modal button listener added');
    }
    
    // Cancel Message Button
    const cancelBtn = getElement('cancelMessage');
    if (cancelBtn) {
      cancelBtn.addEventListener('click', (e) => {
        e.preventDefault();
        closeModalHandler();
      });
      console.log('✅ Cancel message button listener added');
    }
    
    // Modal click outside to close
    if (newMessageModal) {
      newMessageModal.addEventListener('click', (e) => {
        if (e.target === newMessageModal) {
          closeModalHandler();
        }
      });
    }
    
    // Escape key to close modal
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && newMessageModal && newMessageModal.style.display === 'block') {
        closeModalHandler();
      }
    });
    
    // Search conversations
    const searchInput = getElement('searchConversations');
    if (searchInput) {
      let searchTimeout;
      searchInput.addEventListener('input', (e) => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
          filterConversations(e.target.value.trim());
        }, 300);
      });
    }
    
    // Filter tabs
    const filterTabs = document.querySelectorAll('.filter-tab');
    filterTabs.forEach(tab => {
      tab.addEventListener('click', (e) => {
        e.preventDefault();
        
        // Remove active class from all tabs
        filterTabs.forEach(t => t.classList.remove('active'));
        
        // Add active class to clicked tab
        tab.classList.add('active');
        
        // Filter conversations
        const filter = tab.getAttribute('data-filter');
        filterConversationsByType(filter);
      });
    });
    
    // Connection indicator click
    if (connectionIndicator) {
      connectionIndicator.addEventListener('click', (e) => {
        e.preventDefault();
        console.log('🔗 Connection indicator clicked');
        showConnectionDetails();
      });
    }
    
    console.log('✅ All event listeners set up successfully');
    
  } catch (error) {
    console.error('❌ Error setting up event listeners:', error);
  }
}

// Add the missing refresh function
function refreshMessages() {
  console.log('🔄 Refreshing messages...');
  
  try {
    // Show loading state on refresh button
    const refreshBtn = getElement('refreshMessages');
    if (refreshBtn) {
      const originalContent = refreshBtn.innerHTML;
      refreshBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> <span>Refreshing...</span>';
      refreshBtn.disabled = true;
      
      // Restore button after refresh
      setTimeout(() => {
        refreshBtn.innerHTML = originalContent;
        refreshBtn.disabled = false;
      }, 2000);
    }
    
    // Reload all data
    if (currentUser && database) {
      loadUsers();
      loadConversations();
      loadUserConversations();
      
      // Refresh current conversation if one is selected
      if (currentConversation) {
        cleanupMessageListener(currentConversation);
        listenForMessages(currentConversation);
      }
      
      showToast('Messages refreshed successfully', 'success');
    } else {
      showToast('Unable to refresh - not connected', 'error');
    }
    
  } catch (error) {
    console.error('❌ Error refreshing messages:', error);
    showToast('Failed to refresh messages', 'error');
  }
}

// Enhanced Authentication with better error handling
function initializeAuth() {
  console.log('🔐 Initializing authentication...');
  
  if (!auth) {
    console.error('❌ Firebase Auth not initialized');
    handleDemoAuth();
    return;
  }
  
  // Check for existing authentication state
  auth.onAuthStateChanged((user) => {
    if (user) {
      console.log('✅ User authenticated:', user.uid);
      currentUser = {
        uid: user.uid,
        name: user.displayName || 'Admin User',
        email: user.email,
        role: 'admin',
        avatar: getAvatarFromName(user.displayName || 'Admin User'),
        platform: 'web',
        lastActive: firebase.database.ServerValue.TIMESTAMP
      };
      
      initializeUserSession();
    } else {
      handleDemoAuth();
    }
  });
}

// Handle demo authentication with validation
function handleDemoAuth() {
  console.log('🔄 Using demo authentication...');
  currentUser = {
    uid: 'admin_web_001',
    name: 'Rhyziel Kyle Toquero',
    email: 'admin@pregnacare.com',
    role: 'admin',
    avatar: 'RK',
    platform: 'web',
    lastActive: Date.now()
  };
  
  initializeUserSession();
}

// Initialize user session with enhanced error handling
function initializeUserSession() {
  if (!currentUser || !database) {
    console.error('❌ Cannot initialize user session - missing requirements');
    return;
  }
  
  console.log('👤 Initializing user session for:', currentUser.name);
  
  try {
    // Set user data in Firebase with enhanced structure
    const userRef = database.ref(`${DatabasePaths.USERS}/${currentUser.uid}`);
    userRef.update({
      ...currentUser,
      isOnline: true,
      lastSeen: firebase.database.ServerValue.TIMESTAMP || Date.now(),
      platform: 'web'
    }).catch(error => handleFirebaseError(error, 'user update'));

    // Setup presence system
    setupPresenceSystem();
    
    // Load user's conversations and data
    loadConversations();
    loadUserConversations();
    updateConnectionStatus('connected');
    
    // Initialize demo data for testing after delay
    setTimeout(() => {
      initializeDemoData();
    }, 2000);
    
  } catch (error) {
    console.error('❌ Error initializing user session:', error);
    handleFirebaseError(error, 'user session initialization');
  }
}

// Enhanced presence system with better error handling
function setupPresenceSystem() {
  if (!database || !currentUser) return;
  
  try {
    // Reference to the user's presence in Firebase
    presenceRef = database.ref(`${DatabasePaths.PRESENCE}/${currentUser.uid}`);
    
    // Set online presence
    presenceRef.set({
      isOnline: true,
      lastSeen: firebase.database.ServerValue.TIMESTAMP || Date.now(),
      platform: currentUser.platform,
      userAgent: navigator.userAgent
    }).catch(error => console.warn('Presence update failed:', error));

    // Remove presence when user disconnects
    presenceRef.onDisconnect().update({
      isOnline: false,
      lastSeen: firebase.database.ServerValue.TIMESTAMP || Date.now()
    }).catch(error => console.warn('Presence disconnect handler failed:', error));

    // Also update main user record
    const userRef = database.ref(`${DatabasePaths.USERS}/${currentUser.uid}`);
    userRef.onDisconnect().update({
      isOnline: false,
      lastSeen: firebase.database.ServerValue.TIMESTAMP || Date.now()
    }).catch(error => console.warn('User disconnect handler failed:', error));
    
  } catch (error) {
    console.error('❌ Error setting up presence system:', error);
  }
}

// Enhanced user loading with better error handling
function loadUsers() {
  if (!database) return;
  
  console.log('👥 Loading users...');
  
  database.ref(DatabasePaths.USERS).on('value', (snapshot) => {
    try {
      users = snapshot.val() || {};
      console.log(`📊 Loaded ${Object.keys(users).length} users`);
      populateRecipientSelect();
    } catch (error) {
      console.error('❌ Error processing users data:', error);
    }
  }, (error) => {
    console.error('❌ Error loading users:', error);
    handleFirebaseError(error, 'load users');
  });
}

// Enhanced conversation loading with better error handling
function loadConversations() {
  if (!database || !currentUser) return;
  
  console.log('💬 Loading conversations...');
  
  const conversationsRef = database.ref(DatabasePaths.CONVERSATIONS)
    .orderByChild('lastMessage/timestamp');
  
  conversationsRef.on('value', (snapshot) => {
    try {
      conversations = {};
      const data = snapshot.val();
      
      if (data) {
        Object.keys(data).forEach(conversationId => {
          const conversation = data[conversationId];
          
          // Only include conversations where current user is a participant
          if (conversation.participants && conversation.participants[currentUser.uid]) {
            conversations[conversationId] = {
              ...conversation,
              id: conversationId
            };
          }
        });
        
        console.log(`✅ Loaded ${Object.keys(conversations).length} conversations`);
      } else {
        console.log('📭 No conversations found');
      }
      
      renderConversations();
      updateUnreadCount();
      
    } catch (error) {
      console.error('❌ Error processing conversations:', error);
    }
  }, (error) => {
    console.error('❌ Error loading conversations:', error);
    handleFirebaseError(error, 'load conversations');
  });
}

// Load user-specific conversation index
function loadUserConversations() {
  if (!database || !currentUser) return;
  
  const userConversationsRef = database.ref(`${DatabasePaths.USER_CONVERSATIONS}/${currentUser.uid}`);
  
  userConversationsRef.on('value', (snapshot) => {
    try {
      const userConversations = snapshot.val() || {};
      console.log(`📱 User conversations index loaded: ${Object.keys(userConversations).length} items`);
    } catch (error) {
      console.error('❌ Error processing user conversations:', error);
    }
  }, (error) => {
    console.warn('⚠️ Could not load user conversations index:', error);
  });
}

// Enhanced conversation rendering with null checks
function renderConversations() {
  if (!conversationsList) return;
  
  const conversationsArray = Object.values(conversations);
  conversationsArray.sort((a, b) => {
    const aTime = a.lastMessage ? a.lastMessage.timestamp : 0;
    const bTime = b.lastMessage ? b.lastMessage.timestamp : 0;
    return bTime - aTime;
  });

  let html = '';
  
  if (conversationsArray.length === 0) {
    html = `
      <div class="no-conversations" style="text-align: center; padding: 40px 20px; color: #6c757d;">
        <i class="fas fa-inbox" style="font-size: 48px; margin-bottom: 20px; display: block; color: #dee2e6;"></i>
        <h3 style="margin-bottom: 10px; font-size: 18px;">No conversations yet</h3>
        <p style="margin-bottom: 20px;">Use the "New Message" button above to start a conversation</p>
      </div>
    `;
  } else {
    conversationsArray.forEach(conversation => {
      const otherParticipantId = Object.keys(conversation.participants || {})
        .find(id => id !== currentUser.uid);
      const otherParticipant = users[otherParticipantId] || { 
        name: 'Unknown User', 
        avatar: '??',
        role: 'user'
      };
      
      const isUnread = conversation.lastMessage && 
                      conversation.lastMessage.senderId !== currentUser.uid && 
                      (!conversation.lastReadBy || !conversation.lastReadBy[currentUser.uid] ||
                       conversation.lastReadBy[currentUser.uid] < conversation.lastMessage.timestamp);
      
      const timeAgo = conversation.lastMessage ? formatTimeAgo(conversation.lastMessage.timestamp) : '';
      const preview = conversation.lastMessage ? 
        escapeHTML(conversation.lastMessage.content.substring(0, 50)) + (conversation.lastMessage.content.length > 50 ? '...' : '') : 
        'No messages yet';
      
      // Check if user is online
      const isOnline = users[otherParticipantId] && users[otherParticipantId].isOnline;
      
      html += `
        <div class="conversation-item ${currentConversation === conversation.id ? 'active' : ''}" 
             onclick="selectConversation('${conversation.id}')"
             data-role="${escapeHTML(otherParticipant.role || 'user')}"
             data-conversation-id="${conversation.id}">
          <div class="conversation-avatar">
            ${escapeHTML(otherParticipant.avatar)}
            ${isOnline ? '<div class="online-indicator"></div>' : ''}
          </div>
          <div class="conversation-info">
            <div class="conversation-name">${escapeHTML(otherParticipant.name)}</div>
            <div class="conversation-preview">${preview}</div>
          </div>
          <div class="conversation-meta">
            <div class="conversation-time">${timeAgo}</div>
            ${isUnread ? '<div class="unread-badge">New</div>' : ''}
          </div>
        </div>
      `;
    });
  }
  
  conversationsList.innerHTML = html;
}

// Enhanced conversation selection with validation
function selectConversation(conversationId) {
  if (!conversationId || currentConversation === conversationId) return;
  
  console.log(`💬 Selecting conversation: ${conversationId}`);
  
  // Clean up previous message listener
  cleanupMessageListener(currentConversation);
  
  currentConversation = conversationId;
  const conversation = conversations[conversationId];
  
  if (!conversation) {
    console.error('❌ Conversation not found:', conversationId);
    showToast('Conversation not found', 'error');
    return;
  }
  
  try {
    // Mark conversation as read
    markConversationAsRead(conversationId);
    
    // Update user's last active conversation
    updateUserActiveConversation(conversationId);
    
    // Render chat interface
    renderChatArea(conversation);
    
    // Start listening for messages
    listenForMessages(conversationId);
    
    // Update conversation list UI
    renderConversations();
    
  } catch (error) {
    console.error('❌ Error selecting conversation:', error);
    showToast('Failed to load conversation', 'error');
  }
}

// Clean up message listener
function cleanupMessageListener(conversationId) {
  if (conversationId && messageListeners[conversationId]) {
    try {
      messageListeners[conversationId]();
      delete messageListeners[conversationId];
    } catch (error) {
      console.warn('⚠️ Error cleaning up message listener:', error);
    }
  }
}

// Enhanced chat area rendering with null checks
function renderChatArea(conversation) {
  if (!chatArea || !conversation) return;
  
  const otherParticipantId = Object.keys(conversation.participants || {})
    .find(id => id !== currentUser.uid);
  const otherParticipant = users[otherParticipantId] || { 
    name: 'Unknown User', 
    avatar: '??',
    role: 'user'
  };
  const isOnline = users[otherParticipantId] && users[otherParticipantId].isOnline;
  
  chatArea.innerHTML = `
    <div class="chat-header">
      <div class="chat-user-info">
        <div class="chat-avatar">
          ${escapeHTML(otherParticipant.avatar)}
          ${isOnline ? '<div class="online-indicator"></div>' : ''}
        </div>
        <div class="chat-user-details">
          <h3>${escapeHTML(otherParticipant.name)}</h3>
          <div class="chat-status">
            <div class="status-dot ${isOnline ? '' : 'offline'}"></div>
            ${isOnline ? 'Online' : 'Offline'}
            ${otherParticipant.role ? ` • ${escapeHTML(otherParticipant.role)}` : ''}
          </div>
        </div>
      </div>
      <div class="chat-actions">
        <button class="icon-btn" title="Call" onclick="initiateCall('${otherParticipantId}')">
          <i class="fas fa-phone"></i>
        </button>
        <button class="icon-btn" title="Video Call" onclick="initiateVideoCall('${otherParticipantId}')">
          <i class="fas fa-video"></i>
        </button>
        <button class="icon-btn" title="More Options" onclick="showChatOptions('${currentConversation}')">
          <i class="fas fa-ellipsis-v"></i>
        </button>
      </div>
    </div>
    <div class="messages-area" id="messagesArea">
      <div class="loading-messages" style="text-align: center; padding: 40px; color: #6c757d;">
        <i class="fas fa-spinner fa-spin" style="font-size: 24px; margin-bottom: 10px; display: block;"></i>
        <p>Loading messages...</p>
      </div>
    </div>
    <div class="message-input-area">
      <div class="message-input-container">
        <button class="attach-btn" title="Attach File" onclick="attachFile()">
          <i class="fas fa-paperclip"></i>
        </button>
        <textarea class="message-input" id="messageInput" placeholder="Type a message..." rows="1"></textarea>
        <button class="emoji-btn" title="Add Emoji" onclick="showEmojiPicker()">
          <i class="fas fa-smile"></i>
        </button>
        <button class="send-btn" id="sendBtn" title="Send Message" disabled>
          <i class="fas fa-paper-plane"></i>
        </button>
      </div>
    </div>
  `;
  
  // Setup message input handlers
  setupMessageInput();
}

// Enhanced message input with better event handling
function setupMessageInput() {
  const messageInput = getElement('messageInput');
  const sendBtn = getElement('sendBtn');
  
  if (!messageInput || !sendBtn) return;
  
  let typingTimeout;
  
  // Auto-resize textarea and handle typing indicators
  messageInput.addEventListener('input', function() {
    this.style.height = 'auto';
    this.style.height = Math.min(this.scrollHeight, 120) + 'px';
    
    sendBtn.disabled = !this.value.trim();
    
    // Send typing indicator
    if (currentConversation && this.value.trim()) {
      sendTypingIndicator(true);
      
      clearTimeout(typingTimeout);
      typingTimeout = setTimeout(() => {
        sendTypingIndicator(false);
      }, 3000);
    }
  });
  
  // Send on Enter (not Shift+Enter)
  messageInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });
  
  // Stop typing indicator when user stops typing
  messageInput.addEventListener('blur', () => {
    sendTypingIndicator(false);
  });
  
  sendBtn.addEventListener('click', sendMessage);
}

// Send typing indicator with error handling
function sendTypingIndicator(isTyping) {
  if (!currentConversation || !database) return;
  
  try {
    const typingRef = database.ref(`${DatabasePaths.CONVERSATIONS}/${currentConversation}/typing/${currentUser.uid}`);
    
    if (isTyping) {
      typingRef.set({
        isTyping: true,
        timestamp: firebase.database.ServerValue.TIMESTAMP || Date.now(),
        userName: currentUser.name
      }).catch(error => console.warn('Typing indicator failed:', error));
    } else {
      typingRef.remove().catch(error => console.warn('Remove typing indicator failed:', error));
    }
  } catch (error) {
    console.warn('⚠️ Typing indicator error:', error);
  }
}

// Enhanced message listening with better error handling
function listenForMessages(conversationId) {
  if (!database || !conversationId) return;
  
  console.log(`👂 Listening for messages in conversation: ${conversationId}`);
  
  const messagesRef = database.ref(`${DatabasePaths.MESSAGES}/${conversationId}`)
    .orderByChild('timestamp');
  
  const handleMessages = (snapshot) => {
    try {
      const messages = [];
      snapshot.forEach(childSnapshot => {
        messages.push({
          id: childSnapshot.key,
          ...childSnapshot.val()
        });
      });
      
      console.log(`📨 Loaded ${messages.length} messages`);
      renderMessages(messages);
      
      // Mark messages as read
      markMessagesAsRead(conversationId, messages);
    } catch (error) {
      console.error('❌ Error processing messages:', error);
    }
  };
  
  const handleError = (error) => {
    console.error('❌ Error loading messages:', error);
    handleFirebaseError(error, 'load messages');
  };
  
  messagesRef.on('value', handleMessages, handleError);
  
  messageListeners[conversationId] = () => {
    messagesRef.off('value', handleMessages);
  };
  
  // Also listen for typing indicators
  listenForTypingIndicators(conversationId);
}

// Listen for typing indicators with error handling
function listenForTypingIndicators(conversationId) {
  if (!database || !conversationId) return;
  
  const typingRef = database.ref(`${DatabasePaths.CONVERSATIONS}/${conversationId}/typing`);
  
  typingRef.on('value', (snapshot) => {
    try {
      const typingUsers = snapshot.val() || {};
      const otherUsersTyping = Object.keys(typingUsers)
        .filter(uid => uid !== currentUser.uid)
        .map(uid => typingUsers[uid])
        .filter(user => user && user.isTyping);
      
      displayTypingIndicator(otherUsersTyping);
    } catch (error) {
      console.warn('⚠️ Error processing typing indicators:', error);
    }
  }, (error) => {
    console.warn('⚠️ Error listening for typing indicators:', error);
  });
}

// Display typing indicator with null checks
function displayTypingIndicator(typingUsers) {
  const messagesArea = getElement('messagesArea');
  if (!messagesArea || !Array.isArray(typingUsers)) return;
  
  // Remove existing typing indicator
  const existingIndicator = messagesArea.querySelector('.typing-indicator');
  if (existingIndicator) {
    existingIndicator.remove();
  }
  
  // Show typing indicator if someone is typing
  if (typingUsers.length > 0) {
    const typingIndicator = document.createElement('div');
    typingIndicator.className = 'typing-indicator';
    typingIndicator.innerHTML = `
      <div class="typing-dots">
        <div class="typing-dot"></div>
        <div class="typing-dot"></div>
        <div class="typing-dot"></div>
      </div>
      <span>${escapeHTML(typingUsers[0].userName || 'Someone')} is typing...</span>
    `;
    
    messagesArea.appendChild(typingIndicator);
    messagesArea.scrollTop = messagesArea.scrollHeight;
  }
}

// Enhanced message rendering with better validation
function renderMessages(messages) {
  const messagesArea = getElement('messagesArea');
  if (!messagesArea || !Array.isArray(messages)) return;
  
  let html = '';
  
  if (messages.length === 0) {
    html = `
      <div class="no-messages" style="text-align: center; padding: 40px; color: #6c757d;">
        <i class="fas fa-comment-dots" style="font-size: 48px; margin-bottom: 20px; display: block; color: #dee2e6;"></i>
        <h3 style="margin-bottom: 10px;">No messages yet</h3>
        <p>Send a message to start the conversation</p>
      </div>
    `;
  } else {
    messages.forEach((message, index) => {
      if (!message || !message.senderId) return;
      
      const isSent = message.senderId === currentUser.uid;
      const sender = users[message.senderId] || { name: 'Unknown', avatar: '??' };
      const showAvatar = !isSent && (index === 0 || messages[index - 1].senderId !== message.senderId);
      
      // Enhanced message status
      let messageStatus = '';
      if (isSent) {
        if (message.readBy && Object.keys(message.readBy).length > 1) {
          messageStatus = '<i class="fas fa-check-double message-status read" title="Read"></i>';
        } else if (message.delivered) {
          messageStatus = '<i class="fas fa-check-double message-status delivered" title="Delivered"></i>';
        } else {
          messageStatus = '<i class="fas fa-check message-status sent" title="Sent"></i>';
        }
      }
      
      html += `
        <div class="message ${isSent ? 'sent' : 'received'}" data-message-id="${message.id}">
          <div class="message-content">
            ${!isSent && showAvatar ? `<div class="message-avatar">${escapeHTML(sender.avatar)}</div>` : ''}
            <div class="message-bubble">
              ${escapeHTML(message.content || '')}
              ${message.type === 'system' ? '<div class="system-message-indicator"><i class="fas fa-info-circle"></i></div>' : ''}
            </div>
            <div class="message-time">
              ${formatTime(message.timestamp)}
              ${messageStatus}
            </div>
          </div>
        </div>
      `;
    });
  }
  
  messagesArea.innerHTML = html;
  messagesArea.scrollTop = messagesArea.scrollHeight;
}

// Enhanced message sending with comprehensive error handling
function sendMessage() {
  const messageInput = getElement('messageInput');
  const sendBtn = getElement('sendBtn');
  
  if (!messageInput || !sendBtn) return;
  
  const content = messageInput.value.trim();
  
  if (!content || !currentConversation) {
    showToast('Please enter a message', 'error');
    return;
  }
  
  if (!database) {
    showToast('Messaging service unavailable', 'error');
    return;
  }
  
  console.log('📤 Sending message...');
  
  sendBtn.disabled = true;
  sendBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
  
  // Stop typing indicator
  sendTypingIndicator(false);
  
  const messageId = database.ref(`${DatabasePaths.MESSAGES}/${currentConversation}`).push().key;
  const timestamp = Date.now();
  
  const message = {
    id: messageId,
    content: content,
    senderId: currentUser.uid,
    senderName: currentUser.name,
    senderAvatar: currentUser.avatar,
    timestamp: timestamp,
    type: 'text',
    platform: 'web',
    delivered: false,
    readBy: {
      [currentUser.uid]: timestamp
    }
  };
  
  // Add message to Firebase
  const messageRef = database.ref(`${DatabasePaths.MESSAGES}/${currentConversation}/${messageId}`);
  
  messageRef.set(message)
    .then(() => {
      console.log('✅ Message sent successfully');
      return updateConversationLastMessage(currentConversation, message);
    })
    .then(() => {
      return sendNotificationToParticipants(currentConversation, message);
    })
    .then(() => {
      messageInput.value = '';
      messageInput.style.height = 'auto';
      sendBtn.innerHTML = '<i class="fas fa-paper-plane"></i>';
      sendBtn.disabled = true;
      
      showToast('Message sent successfully', 'success');
    })
    .catch((error) => {
      console.error('❌ Error sending message:', error);
      handleFirebaseError(error, 'send message');
      sendBtn.innerHTML = '<i class="fas fa-paper-plane"></i>';
      sendBtn.disabled = false;
    });
}

// Setup new message form with simple input validation
function setupNewMessageForm() {
  console.log('📝 Setting up new message form...');
  
  const form = getElement('newMessageForm');
  const recipientInput = getElement('recipientInput');
  const subjectInput = getElement('messageSubject');
  const contentInput = getElement('messageContent');
  const sendBtn = getElement('sendNewMessage');
  const characterCount = document.querySelector('.character-count');
  
  if (!form || !recipientInput || !subjectInput || !contentInput || !sendBtn) {
    console.warn('⚠️ New message form elements not found');
    return;
  }
  
  // Recipient input validation - simple text validation
  recipientInput.addEventListener('input', function() {
    const value = this.value.trim();
    const isValid = value.length > 0;
    validateField(this, isValid);
    checkFormValidity();
  });
  
  // Subject input validation
  subjectInput.addEventListener('input', function() {
    const value = this.value.trim();
    const isValid = value.length > 0 && value.length <= 100;
    validateField(this, isValid);
    checkFormValidity();
  });
  
  // Content input with character count
  contentInput.addEventListener('input', function() {
    const length = this.value.length;
    const maxLength = 10000;
    
    // Update character count
    if (characterCount) {
      characterCount.textContent = `${length}/${maxLength} characters`;
      characterCount.classList.toggle('warning', length > maxLength * 0.8);
      characterCount.classList.toggle('danger', length > maxLength * 0.95);
    }
    
    const isValid = this.value.trim().length > 0 && length <= maxLength;
    validateField(this, isValid);
    checkFormValidity();
  });
  
  // Form submission
  form.addEventListener('submit', function(e) {
    e.preventDefault();
    handleNewMessageSubmit();
  });
  
  console.log('✅ New message form setup complete');
}

// Validate individual form field
function validateField(field, isValid) {
  if (!field) return;
  
  field.classList.toggle('is-valid', isValid);
  field.classList.toggle('is-invalid', !isValid);
}

// Check overall form validity
function checkFormValidity() {
  const recipientInput = getElement('recipientInput');
  const subjectInput = getElement('messageSubject');
  const contentInput = getElement('messageContent');
  const sendBtn = getElement('sendNewMessage');
  
  if (!sendBtn) return;
  
  const isRecipientValid = recipientInput && recipientInput.value.trim().length > 0;
  const isSubjectValid = subjectInput && subjectInput.value.trim().length > 0 && subjectInput.value.trim().length <= 100;
  const isContentValid = contentInput && contentInput.value.trim().length > 0 && contentInput.value.length <= 10000;
  
  const isFormValid = isRecipientValid && isSubjectValid && isContentValid;
  
  sendBtn.disabled = !isFormValid;
}

// Handle new message form submission with simple recipient lookup
function handleNewMessageSubmit() {
  const recipientInput = getElement('recipientInput');
  const subjectInput = getElement('messageSubject');
  const contentInput = getElement('messageContent');
  
  if (!recipientInput || !subjectInput || !contentInput) {
    showToast('Form elements not found', 'error');
    return;
  }
  
  const recipientName = recipientInput.value.trim();
  const subject = subjectInput.value.trim();
  const content = contentInput.value.trim();
  
  // Basic validation
  if (!recipientName || !subject || !content) {
    showToast('Please fill in all required fields', 'error');
    return;
  }
  
  if (subject.length > 100) {
    showToast('Subject is too long (max 100 characters)', 'error');
    return;
  }
  
  if (content.length > 10000) {
    showToast('Message is too long (max 10,000 characters)', 'error');
    return;
  }
  
  // Find recipient by name (case-insensitive)
  const recipient = findRecipientByName(recipientName);
  
  if (!recipient) {
    showToast(`Recipient "${recipientName}" not found. Please check the name and try again.`, 'error');
    return;
  }
  
  console.log('📤 Submitting new message to:', recipient.name);
  createNewConversationSimple(recipient.uid, subject, content);
}

// Simple recipient lookup by name
function findRecipientByName(name) {
  if (!name || !users) return null;
  
  const lowerName = name.toLowerCase().trim();
  
  // First try exact match
  let recipient = Object.values(users).find(user => 
    user && 
    user.uid !== currentUser?.uid && 
    user.name && 
    user.name.toLowerCase().trim() === lowerName
  );
  
  // If no exact match, try partial match
  if (!recipient) {
    recipient = Object.values(users).find(user => 
      user && 
      user.uid !== currentUser?.uid && 
      user.name && 
      user.name.toLowerCase().includes(lowerName)
    );
  }
  
  return recipient;
}

// Simplified conversation creation
function createNewConversationSimple(recipientId, subject, content) {
  if (!database || !currentUser) {
    showToast('Messaging service unavailable', 'error');
    return;
  }
  
  if (!users[recipientId]) {
    showToast('Selected recipient is not available', 'error');
    return;
  }
  
  const recipient = users[recipientId];
  console.log('🆕 Creating new conversation with:', recipient.name);
  
  const sendBtn = getElement('sendNewMessage');
  if (sendBtn) {
    sendBtn.disabled = true;
    sendBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating...';
  }
  
  const conversationId = database.ref(DatabasePaths.CONVERSATIONS).push().key;
  const timestamp = Date.now();
  
  const conversationData = {
    id: conversationId,
    participants: {
      [currentUser.uid]: {
        role: currentUser.role,
        joinedAt: timestamp,
        name: currentUser.name,
        avatar: currentUser.avatar
      },
      [recipientId]: {
        role: recipient.role || 'user',
        joinedAt: timestamp,
        name: recipient.name || 'Unknown',
        avatar: recipient.avatar || '??'
      }
    },
    subject: subject,
    createdAt: timestamp,
    createdBy: currentUser.uid,
    platform: 'web',
    type: 'direct',
    lastActivity: timestamp
  };
  
  // Create conversation
  const conversationRef = database.ref(`${DatabasePaths.CONVERSATIONS}/${conversationId}`);
  
  conversationRef.set(conversationData)
    .then(() => {
      console.log('✅ Conversation created');
      
      // Add to user conversation indexes
      const userConversationUpdates = {};
      userConversationUpdates[`${DatabasePaths.USER_CONVERSATIONS}/${currentUser.uid}/${conversationId}`] = {
        lastActivity: timestamp,
        otherParticipant: recipientId
      };
      userConversationUpdates[`${DatabasePaths.USER_CONVERSATIONS}/${recipientId}/${conversationId}`] = {
        lastActivity: timestamp,
        otherParticipant: currentUser.uid
      };
      
      return database.ref().update(userConversationUpdates);
    })
    .then(() => {
      // Send first message
      const messageId = database.ref(`${DatabasePaths.MESSAGES}/${conversationId}`).push().key;
      const message = {
        id: messageId,
        content: content,
        senderId: currentUser.uid,
        senderName: currentUser.name,
        senderAvatar: currentUser.avatar,
        timestamp: timestamp,
        type: 'text',
        platform: 'web',
        delivered: false,
        readBy: {
          [currentUser.uid]: timestamp
        }
      };
      
      return database.ref(`${DatabasePaths.MESSAGES}/${conversationId}/${messageId}`).set(message);
    })
    .then(() => {
      // Update conversation with last message
      return conversationRef.update({
        lastMessage: {
          content: content,
          senderId: currentUser.uid,
          senderName: currentUser.name,
          timestamp: timestamp,
          type: 'text'
        }
      });
    })
    .then(() => {
      showToast(`Conversation started with ${recipient.name}`, 'success');
      closeModalHandler();
      
      // Auto-select the new conversation
      setTimeout(() => selectConversation(conversationId), 500);
    })
    .catch((error) => {
      console.error('❌ Error creating conversation:', error);
      handleFirebaseError(error, 'create conversation');
    })
    .finally(() => {
      if (sendBtn) {
        sendBtn.disabled = false;
        sendBtn.innerHTML = '<i class="fas fa-paper-plane"></i> Send Message';
      }
    });
}

// Enhanced modal handling
function openNewMessageModal() {
  if (!newMessageModal) {
    console.warn('⚠️ New message modal not found');
    return;
  }
  
  // Reset form
  resetNewMessageForm();
  
  // Setup form if not already done
  const recipientInput = getElement('recipientInput');
  if (recipientInput && !recipientInput.hasAttribute('data-setup')) {
    setupNewMessageForm();
    recipientInput.setAttribute('data-setup', 'true');
  }
  
  newMessageModal.style.display = 'block';
  document.body.style.overflow = 'hidden';
  
  // Focus on recipient input
  setTimeout(() => {
    if (recipientInput) {
      recipientInput.focus();
    }
  }, 100);
  
  showToast('Compose new message', 'info');
}

// Simple form reset function
function resetNewMessageForm() {
  const recipientInput = getElement('recipientInput');
  const subjectInput = getElement('messageSubject');
  const contentInput = getElement('messageContent');
  const characterCount = document.querySelector('.character-count');
  const sendBtn = getElement('sendNewMessage');
  
  // Clear form fields
  if (recipientInput) {
    recipientInput.value = '';
    recipientInput.classList.remove('is-valid', 'is-invalid');
  }
  if (subjectInput) {
    subjectInput.value = '';
    subjectInput.classList.remove('is-valid', 'is-invalid');
  }
  if (contentInput) {
    contentInput.value = '';
    contentInput.classList.remove('is-valid', 'is-invalid');
  }
  if (characterCount) {
    characterCount.textContent = '0/10000 characters';
    characterCount.classList.remove('warning', 'danger');
  }
  if (sendBtn) {
    sendBtn.disabled = true;
  }
}

// Enhanced close modal with proper cleanup
function closeModalHandler() {
  try {
    if (newMessageModal) {
      newMessageModal.style.display = 'none';
    }
    document.body.style.overflow = '';
    
    // Reset form
    resetNewMessageForm();
    
    console.log('✅ Modal closed and form cleared');
  } catch (error) {
    console.warn('⚠️ Error closing modal:', error);
  }
}

// Populate recipient suggestions for auto-complete (optional helper)
function populateRecipientSelect() {
  console.log('👥 Available recipients for reference:');
  
  const availableUsers = Object.values(users).filter(user => 
    user && user.uid !== currentUser?.uid
  );
  
  console.log(`📊 Available recipients: ${availableUsers.length}`);
  
  availableUsers.forEach(user => {
    console.log(`- ${user.name} (${user.role}) - ${user.isOnline ? 'Online' : 'Offline'}`);
  });
  
  // You could use this list to show available recipients to the user
  // For example, in a help text or placeholder
  if (availableUsers.length > 0) {
    const recipientInput = getElement('recipientInput');
    if (recipientInput && !recipientInput.placeholder.includes('e.g.')) {
      const exampleNames = availableUsers.slice(0, 2).map(u => u.name).join(', ');
      recipientInput.placeholder = `Enter recipient name (e.g. ${exampleNames})`;
    }
  }
}

// Add missing filter functions
function filterConversations(searchTerm) {
  if (!searchTerm) {
    renderConversations();
    return;
  }
  
  const filteredConversations = Object.values(conversations).filter(conversation => {
    const otherParticipantId = Object.keys(conversation.participants || {})
      .find(id => id !== currentUser.uid);
    const otherParticipant = users[otherParticipantId] || {};
    
    return (otherParticipant.name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
           (conversation.subject || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
           (conversation.lastMessage?.content || '').toLowerCase().includes(searchTerm.toLowerCase());
  });
  
  renderFilteredConversations(filteredConversations);
}

function filterConversationsByType(filter) {
  let filteredConversations = Object.values(conversations);
  
  if (filter === 'unread') {
    filteredConversations = filteredConversations.filter(conversation => {
      return conversation.lastMessage && 
             conversation.lastMessage.senderId !== currentUser.uid && 
             (!conversation.lastReadBy || !conversation.lastReadBy[currentUser.uid] ||
              conversation.lastReadBy[currentUser.uid] < conversation.lastMessage.timestamp);
    });
  } else if (filter === 'patients') {
    filteredConversations = filteredConversations.filter(conversation => {
      const otherParticipantId = Object.keys(conversation.participants || {})
        .find(id => id !== currentUser.uid);
      const otherParticipant = users[otherParticipantId] || {};
      return otherParticipant.role === 'patient';
    });
  } else if (filter === 'doctors') {
    filteredConversations = filteredConversations.filter(conversation => {
      const otherParticipantId = Object.keys(conversation.participants || {})
        .find(id => id !== currentUser.uid);
      const otherParticipant = users[otherParticipantId] || {};
      return otherParticipant.role === 'doctor';
    });
  }
  
  renderFilteredConversations(filteredConversations);
}

function renderFilteredConversations(filteredConversations) {
  if (!conversationsList) return;
  
  filteredConversations.sort((a, b) => {
    const aTime = a.lastMessage ? a.lastMessage.timestamp : 0;
    const bTime = b.lastMessage ? b.lastMessage.timestamp : 0;
    return bTime - aTime;
  });

  let html = '';
  
  if (filteredConversations.length === 0) {
    html = `
      <div class="no-conversations" style="text-align: center; padding: 40px 20px; color: #6c757d;">
        <i class="fas fa-search" style="font-size: 48px; margin-bottom: 20px; display: block; color: #dee2e6;"></i>
        <h3 style="margin-bottom: 10px; font-size: 18px;">No conversations found</h3>
        <p style="margin-bottom: 20px;">Try adjusting your search or filter criteria</p>
      </div>
    `;
  } else {
    filteredConversations.forEach(conversation => {
      const otherParticipantId = Object.keys(conversation.participants || {})
        .find(id => id !== currentUser.uid);
      const otherParticipant = users[otherParticipantId] || { 
        name: 'Unknown User', 
        avatar: '??',
        role: 'user'
      };
      
      const isUnread = conversation.lastMessage && 
                      conversation.lastMessage.senderId !== currentUser.uid && 
                      (!conversation.lastReadBy || !conversation.lastReadBy[currentUser.uid] ||
                       conversation.lastReadBy[currentUser.uid] < conversation.lastMessage.timestamp);
      
      const timeAgo = conversation.lastMessage ? formatTimeAgo(conversation.lastMessage.timestamp) : '';
      const preview = conversation.lastMessage ? 
        escapeHTML(conversation.lastMessage.content.substring(0, 50)) + (conversation.lastMessage.content.length > 50 ? '...' : '') : 
        'No messages yet';
      
      const isOnline = users[otherParticipantId] && users[otherParticipantId].isOnline;
      
      html += `
        <div class="conversation-item ${currentConversation === conversation.id ? 'active' : ''}" 
             onclick="selectConversation('${conversation.id}')"
             data-role="${escapeHTML(otherParticipant.role || 'user')}"
             data-conversation-id="${conversation.id}">
          <div class="conversation-avatar">
            ${escapeHTML(otherParticipant.avatar)}
            ${isOnline ? '<div class="online-indicator"></div>' : ''}
          </div>
          <div class="conversation-info">
            <div class="conversation-name">${escapeHTML(otherParticipant.name)}</div>
            <div class="conversation-preview">${preview}</div>
          </div>
          <div class="conversation-meta">
            <div class="conversation-time">${timeAgo}</div>
            ${isUnread ? '<div class="unread-badge">New</div>' : ''}
          </div>
        </div>
      `;
    });
  }
  
  conversationsList.innerHTML = html;
}

function showConnectionDetails() {
  const status = database ? 'Connected to Firebase' : 'Disconnected from Firebase';
  const userInfo = currentUser ? `Logged in as: ${currentUser.name}` : 'Not authenticated';
  const conversationCount = Object.keys(conversations).length;
  
  showToast(`${status}\n${userInfo}\nConversations: ${conversationCount}`, 'info');
}

// Add this function to update the unread count
function updateUnreadCount() {
  try {
    if (!unreadCount || !currentUser) return;
    
    let count = 0;
    Object.values(conversations).forEach(conversation => {
      if (conversation.lastMessage && 
          conversation.lastMessage.senderId !== currentUser.uid && 
          (!conversation.lastReadBy || !conversation.lastReadBy[currentUser.uid] ||
           conversation.lastReadBy[currentUser.uid] < conversation.lastMessage.timestamp)) {
        count++;
      }
    });
    
    unreadCount.textContent = count;
    unreadCount.style.display = count > 0 ? 'inline-block' : 'none';
    
    // Update page title with unread count
    document.title = count > 0 ? `(${count}) PregnaCare - Messages` : 'PregnaCare - Messages';
    
  } catch (error) {
    console.warn('⚠️ Error updating unread count:', error);
  }
}

// Update conversation last message with error handling
function updateConversationLastMessage(conversationId, message) {
  if (!database || !conversationId || !message) {
    return Promise.reject(new Error('Missing required parameters'));
  }
  
  const conversationRef = database.ref(`${DatabasePaths.CONVERSATIONS}/${conversationId}`);
  
  return conversationRef.update({
    lastMessage: {
      id: message.id,
      content: message.content,
      senderId: message.senderId,
      senderName: message.senderName,
      timestamp: message.timestamp,
      type: message.type
    },
    lastActivity: firebase.database.ServerValue.TIMESTAMP || Date.now()
  });
}

// Enhanced notification sending with error handling
function sendNotificationToParticipants(conversationId, message) {
  if (!database || !conversationId || !message) {
    return Promise.resolve();
  }
  
  const conversation = conversations[conversationId];
  if (!conversation || !conversation.participants) {
    return Promise.resolve();
  }
  
  const participantIds = Object.keys(conversation.participants)
    .filter(uid => uid !== currentUser.uid);
  
  const notificationPromises = participantIds.map(participantId => {
    const notificationRef = database.ref(`${DatabasePaths.NOTIFICATIONS}/${participantId}`).push();
    
    return notificationRef.set({
      type: 'new_message',
      title: `New message from ${currentUser.name}`,
      body: message.content,
      conversationId: conversationId,
      senderId: currentUser.uid,
      timestamp: firebase.database.ServerValue.TIMESTAMP || Date.now(),
      read: false,
      platform: 'web'
    }).catch(error => {
      console.warn(`Failed to send notification to ${participantId}:`, error);
    });
  });
  
  return Promise.allSettled(notificationPromises);
}

// Mark messages as read with better error handling
function markMessagesAsRead(conversationId, messages) {
  if (!database || !conversationId || !Array.isArray(messages) || !currentUser) return;
  
  const unreadMessages = messages.filter(msg => 
    msg && msg.senderId !== currentUser.uid && 
    (!msg.readBy || !msg.readBy[currentUser.uid])
  );
  
  if (unreadMessages.length === 0) return;
  
  const updates = {};
  const timestamp = Date.now();
  
  unreadMessages.forEach(message => {
    if (message && message.id) {
      updates[`${DatabasePaths.MESSAGES}/${conversationId}/${message.id}/readBy/${currentUser.uid}`] = timestamp;
    }
  });
  
  // Also update conversation read status
  updates[`${DatabasePaths.CONVERSATIONS}/${conversationId}/lastReadBy/${currentUser.uid}`] = timestamp;
  
  database.ref().update(updates).catch(error => {
    console.warn('⚠️ Failed to mark messages as read:', error);
  });
}

// Enhanced notifications setup with better error handling
function setupNotifications() {
  if (!messaging) {
    console.log('📵 Push messaging not supported');
    return;
  }
  
  // Request notification permission
  Notification.requestPermission().then((permission) => {
    notificationPermission = permission;
    console.log('🔔 Notification permission:', permission);
    
    if (permission === 'granted') {
      // Note: You'll need to add your VAPID key here
      const vapidKey = 'YOUR_VAPID_KEY_HERE';
      
      if (vapidKey !== 'YOUR_VAPID_KEY_HERE') {
        messaging.getToken({ vapidKey: vapidKey }).then((currentToken) => {
          if (currentToken) {
            console.log('🔑 FCM Token:', currentToken);
            
            // Save token to user profile
            if (database && currentUser) {
              database.ref(`${DatabasePaths.USERS}/${currentUser.uid}/fcmTokens/web`).set({
                token: currentToken,
                platform: 'web',
                updatedAt: firebase.database.ServerValue.TIMESTAMP || Date.now()
              }).catch(error => console.warn('Failed to save FCM token:', error));
            }
          }
        }).catch((err) => {
          console.warn('🚫 Unable to get FCM token:', err);
        });
      }
    }
  }).catch((err) => {
    console.warn('🚫 Notification permission request failed:', err);
  });
  
  // Handle foreground messages
  messaging.onMessage((payload) => {
    console.log('📨 Foreground message received:', payload);
    
    if (payload.notification) {
      showToast(payload.notification.body || 'New message received', 'info');
      playNotificationSound();
    }
  });
}

// Enhanced connection monitoring with better error handling
function monitorConnectionStatus() {
  if (!database) return;
  
  database.ref('.info/connected').on('value', (snapshot) => {
    try {
      if (snapshot.val() === true) {
        console.log('🟢 Connected to Firebase');
        updateConnectionStatus('connected');
        
        // Restore user presence
        if (presenceRef && currentUser) {
          presenceRef.set({
            isOnline: true,
            lastSeen: firebase.database.ServerValue.TIMESTAMP || Date.now(),
            platform: 'web'
          }).catch(error => console.warn('Failed to restore presence:', error));
        }
      } else {
        console.log('🔴 Disconnected from Firebase');
        updateConnectionStatus('disconnected');
      }
    } catch (error) {
      console.error('❌ Connection monitoring error:', error);
    }
  }, (error) => {
    console.error('❌ Connection monitoring failed:', error);
    updateConnectionStatus('disconnected');
  });
}

// Mark conversation as read with error handling
function markConversationAsRead(conversationId) {
  if (!currentUser || !conversationId || !database) return;
  
  const timestamp = Date.now();
  const updates = {};
  updates[`${DatabasePaths.CONVERSATIONS}/${conversationId}/lastReadBy/${currentUser.uid}`] = timestamp;
  
  database.ref().update(updates).catch(error => {
    console.warn('⚠️ Error marking conversation as read:', error);
  });
}

// Update user's active conversation with error handling
function updateUserActiveConversation(conversationId) {
  if (!currentUser || !database) return;
  
  database.ref(`${DatabasePaths.USERS}/${currentUser.uid}/activeConversation`).set({
    conversationId: conversationId,
    timestamp: firebase.database.ServerValue.TIMESTAMP || Date.now(),
    platform: 'web'
  }).catch(error => {
    console.warn('⚠️ Failed to update active conversation:', error);
  });
}

// Enhanced demo data initialization with better error handling
function initializeDemoData() {
  if (!database || !currentUser) return;
  
  console.log('🎭 Initializing demo data...');
  
  // Enhanced demo users with mobile-compatible structure
  const demoUsers = {
    'patient_001': {
      uid: 'patient_001',
      name: 'Maria Santos',
      email: 'maria.santos@example.com',
      role: 'patient',
      avatar: 'MS',
      isOnline: true,
      platform: 'mobile',
      lastSeen: Date.now() - 300000,
      profile: {
        age: 28,
        pregnancyWeek: 24,
        dueDate: '2024-08-15'
      }
    },
    'doctor_001': {
      uid: 'doctor_001',
      name: 'Dr. Juan Cruz',
      email: 'dr.cruz@pregnacare.com',
      role: 'doctor',
      avatar: 'JC',
      isOnline: false,
      platform: 'web',
      lastSeen: Date.now() - 3600000,
      profile: {
        specialization: 'Obstetrics & Gynecology',
        experience: 15,
        hospital: 'PregnaCare Medical Center'
      }
    },
    'patient_002': {
      uid: 'patient_002',
      name: 'Ana Reyes',
      email: 'ana.reyes@example.com',
      role: 'patient',
      avatar: 'AR',
      isOnline: true,
      platform: 'mobile',
      lastSeen: Date.now() - 60000,
      profile: {
        age: 32,
        pregnancyWeek: 16,
        dueDate: '2024-10-20'
      }
    },
    'nurse_001': {
      uid: 'nurse_001',
      name: 'Nurse Patricia',
      email: 'patricia@pregnacare.com',
      role: 'nurse',
      avatar: 'NP',
      isOnline: true,
      platform: 'web',
      lastSeen: Date.now() - 120000,
      profile: {
        department: 'Maternity Ward',
        shift: 'Morning',
        experience: 8
      }
    }
  };
  
  // Add demo users to database with error handling
  const userPromises = Object.keys(demoUsers).map(userId => {
    return database.ref(`${DatabasePaths.USERS}/${userId}`).update(demoUsers[userId])
      .catch(error => console.warn(`Failed to create demo user ${userId}:`, error));
  });
  
  Promise.allSettled(userPromises).then(() => {
    // Create demo conversation if none exist
    setTimeout(() => {
      database.ref(DatabasePaths.CONVERSATIONS).once('value', (snapshot) => {
        if (!snapshot.exists()) {
          createDemoConversation();
        }
      }).catch(error => {
        console.warn('⚠️ Could not check for existing conversations:', error);
      });
    }, 3000);
  });
}

// Create demo conversation with error handling
function createDemoConversation() {
  if (!database || !currentUser) return;
  
  console.log('🏗️ Creating demo conversation...');
  
  const conversationId = 'demo_conversation_001';
  const timestamp = Date.now();
  
  // Create conversation with Maria Santos
  database.ref(`${DatabasePaths.CONVERSATIONS}/${conversationId}`).set({
    id: conversationId,
    participants: {
      [currentUser.uid]: {
        role: currentUser.role,
        joinedAt: timestamp,
        name: currentUser.name,
        avatar: currentUser.avatar
      },
      'patient_001': {
        role: 'patient',
        joinedAt: timestamp,
        name: 'Maria Santos',
        avatar: 'MS'
      }
    },
    subject: 'Prenatal Care Questions',
    createdAt: timestamp,
    createdBy: 'patient_001',
    platform: 'mobile',
    type: 'direct',
    lastMessage: {
      content: 'Good morning! I wanted to ask about my prenatal vitamins and the upcoming ultrasound appointment.',
      senderId: 'patient_001',
      senderName: 'Maria Santos',
      timestamp: timestamp,
      type: 'text'
    },
    lastActivity: timestamp
  }).then(() => {
    // Add demo messages
    const messages = [
      {
        id: 'msg_001',
        content: 'Good morning! I wanted to ask about my prenatal vitamins and the upcoming ultrasound appointment.',
        senderId: 'patient_001',
        senderName: 'Maria Santos',
        senderAvatar: 'MS',
        timestamp: timestamp - 1800000,
        type: 'text',
        platform: 'mobile',
        delivered: true,
        readBy: {
          'patient_001': timestamp - 1800000
        }
      },
      {
        id: 'msg_002',
        content: 'Hello Maria! I hope you\'re feeling well. Regarding your prenatal vitamins, please continue taking them as prescribed. Your ultrasound is scheduled for this Friday at 2 PM.',
        senderId: currentUser.uid,
        senderName: currentUser.name,
        senderAvatar: currentUser.avatar,
        timestamp: timestamp - 1200000,
        type: 'text',
        platform: 'web',
        delivered: true,
        readBy: {
          [currentUser.uid]: timestamp - 1200000,
          'patient_001': timestamp - 900000
        }
      },
      {
        id: 'msg_003',
        content: 'Thank you so much! Should I prepare anything special for the ultrasound? Also, I\'ve been experiencing some mild back pain. Is this normal?',
        senderId: 'patient_001',
        senderName: 'Maria Santos',
        senderAvatar: 'MS',
        timestamp: timestamp - 300000,
        type: 'text',
        platform: 'mobile',
        delivered: true,
        readBy: {
          'patient_001': timestamp - 300000
        }
      }
    ];
    
    // Add messages to database
    const messagePromises = messages.map(message => {
      return database.ref(`${DatabasePaths.MESSAGES}/${conversationId}/${message.id}`).set(message)
        .catch(error => console.warn(`Failed to create demo message ${message.id}:`, error));
    });
    
    return Promise.allSettled(messagePromises);
  }).then(() => {
    // Update user conversation indexes
    const userConversationUpdates = {};
    userConversationUpdates[`${DatabasePaths.USER_CONVERSATIONS}/${currentUser.uid}/${conversationId}`] = {
      lastActivity: timestamp,
      otherParticipant: 'patient_001'
    };
    userConversationUpdates[`${DatabasePaths.USER_CONVERSATIONS}/patient_001/${conversationId}`] = {
      lastActivity: timestamp,
      otherParticipant: currentUser.uid
    };
    
    return database.ref().update(userConversationUpdates);
  }).then(() => {
    console.log('✅ Demo conversation created');
  }).catch(error => {
    console.error('❌ Error creating demo conversation:', error);
  });
}

// Handle navigation from other pages
function handlePageNavigation() {
  try {
    // Check if we should open compose modal
    if (sessionStorage.getItem('openComposeModal') === 'true') {
      sessionStorage.removeItem('openComposeModal');
      setTimeout(() => {
        openNewMessageModal();
      }, 1000);
    }
    
    // Check if we should open a specific message
    const messageId = sessionStorage.getItem('openMessageId');
    if (messageId) {
      sessionStorage.removeItem('openMessageId');
      setTimeout(() => {
        openSpecificMessage(messageId);
      }, 1500);
    }
  } catch (error) {
    console.warn('⚠️ Error handling page navigation:', error);
  }
}

// Open specific message/conversation with error handling
function openSpecificMessage(messageId) {
  if (!messageId || !database) return;
  
  const searchPromises = Object.keys(conversations).map(conversationId => {
    return database.ref(`${DatabasePaths.MESSAGES}/${conversationId}`)
      .orderByKey()
      .equalTo(messageId)
      .once('value')
      .then(snapshot => {
        if (snapshot.exists()) {
          selectConversation(conversationId);
          showToast('Message located', 'success');
          return true;
        }
        return false;
      })
      .catch(error => {
        console.warn(`Error searching in conversation ${conversationId}:`, error);
        return false;
      });
  });
  
  Promise.allSettled(searchPromises).then(results => {
    const found = results.some(result => result.status === 'fulfilled' && result.value === true);
    if (!found) {
      showToast('Message not found', 'error');
    }
  });
}

// Enhanced connection status update with error handling
function updateConnectionStatus(status) {
  try {
    if (connectionText) {
      connectionText.textContent = status === 'connected' ? 'Connected' : 
                                  status === 'connecting' ? 'Connecting...' : 'Disconnected';
    }
    
    if (connectionIndicator) {
      connectionIndicator.className = `connection-indicator ${status === 'connected' ? '' : status}`;
    }
    
    if (connectionIcon) {
      if (status === 'connected') {
        connectionIcon.className = 'fas fa-wifi';
      } else if (status === 'connecting') {
        connectionIcon.className = 'fas fa-spinner fa-spin';
      } else {
        connectionIcon.className = 'fas fa-wifi-slash';
      }
    }
  } catch (error) {
    console.warn('⚠️ Error updating connection status:', error);
  }
}

// Enhanced toast notifications with error handling
function showToast(message, type = 'success') {
  try {
    if (!toastContainer) {
      console.warn('⚠️ Toast container not found');
      return;
    }
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    const iconClass = type === 'success' ? 'check-circle' : 
                     type === 'error' ? 'exclamation-circle' : 'info-circle';
    
    toast.innerHTML = `
      <i class="fas fa-${iconClass}"></i>
      <span>${escapeHTML(message || 'Notification')}</span>
    `;
    
    toastContainer.appendChild(toast);
    
    setTimeout(() => {
      try {
        if (toast.parentNode) {
          toast.remove();
        }
      } catch (error) {
        console.warn('⚠️ Error removing toast:', error);
      }
    }, 3000);
  } catch (error) {
    console.warn('⚠️ Error showing toast:', error);
  }
}

// Enhanced Firebase error handling
function handleFirebaseError(error, operation) {
  console.error(`Firebase ${operation} error:`, error);
  
  let userMessage = 'An error occurred. Please try again.';
  
  if (error && error.code) {
    switch (error.code) {
      case 'permission-denied':
        userMessage = 'Permission denied. Please check your access rights.';
        break;
      case 'network-error':
        userMessage = 'Network error. Please check your connection.';
        break;
      case 'unavailable':
        userMessage = 'Service temporarily unavailable. Please try again later.';
        break;
      case 'quota-exceeded':
        userMessage = 'Storage quota exceeded. Please contact support.';
        break;
    }
  }
  
  showToast(userMessage, 'error');
}

// Chat Action Functions (placeholders for future features)
function initiateCall(userId) {
  console.log('📞 Initiating call with:', userId);
  showToast('Voice call feature will be available in the mobile app', 'info');
}

function initiateVideoCall(userId) {
  console.log('📹 Initiating video call with:', userId);
  showToast('Video call feature will be available in the mobile app', 'info');
}

function showChatOptions(conversationId) {
  console.log('⚙️ Showing chat options for:', conversationId);
  showToast('Additional chat options coming soon', 'info');
}

function attachFile() {
  console.log('📎 File attachment requested');
  showToast('File attachment feature will be available in the mobile app', 'info');
}

function showEmojiPicker() {
  console.log('😊 Emoji picker requested');
  showToast('Emoji picker coming soon', 'info');
}

// Enhanced notification sound with error handling
function playNotificationSound() {
  try {
    const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmAaADmT1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmAaADmT1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmAaAA==');
    audio.volume = 0.3;
    audio.play().catch(e => console.log('Could not play notification sound:', e));
  } catch (e) {
    console.log('Notification sound not available:', e);
  }
}

// Enhanced utility functions with better error handling
function formatTime(timestamp) {
  try {
    if (!timestamp) return '';
    const date = new Date(timestamp);
    
    // Validate date
    if (isNaN(date.getTime())) return '';
    
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    
    return date.toLocaleDateString();
  } catch (error) {
    console.warn('⚠️ Error formatting time:', error);
    return '';
  }
}

function formatTimeAgo(timestamp) {
  try {
    if (!timestamp) return '';
    const date = new Date(timestamp);
    
    // Validate date
    if (isNaN(date.getTime())) return '';
    
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 1) return 'now';
    if (diffMins < 60) return `${diffMins}m`;
    if (diffHours < 24) return `${diffHours}h`;
    if (diffDays < 7) return `${diffDays}d`;
    
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  } catch (error) {
    console.warn('⚠️ Error formatting time ago:', error);
    return '';
  }
}

function escapeHTML(str) {
  try {
    if (!str) return '';
    if (typeof str !== 'string') return String(str);
    
    return str.replace(/[&<>"'`=\/]/g, function (s) {
      return ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;',
        "'": '&#39;', '`': '&#96;', '=': '&#61;', '/': '&#47;'
      })[s];
    });
  } catch (error) {
    console.warn('⚠️ Error escaping HTML:', error);
    return '';
  }
}

function getAvatarFromName(name) {
  try {
    if (!name || typeof name !== 'string') return '??';
    
    const parts = name.trim().split(' ');
    if (parts.length >= 2) {
      return (parts[0][0] + parts[1][0]).toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
  } catch (error) {
    console.warn('⚠️ Error generating avatar from name:', error);
    return '??';
  }
}

// Enhanced cleanup functions
function cleanupAllListeners() {
  console.log('🧹 Cleaning up all listeners...');
  
  try {
    // Clean up message listeners
    Object.keys(messageListeners).forEach(conversationId => {
      cleanupMessageListener(conversationId);
    });
    
    // Clean up presence listener
    if (presenceRef) {
      presenceRef.off();
      presenceRef = null;
    }
    
    console.log('✅ All listeners cleaned up');
  } catch (error) {
    console.warn('⚠️ Error during cleanup:', error);
  }
}

// Enhanced message search functionality
function searchMessages(query, conversationId = null) {
  if (!query || !database) return Promise.resolve([]);
  
  const searchTerm = query.toLowerCase();
  const searchPromises = [];
  
  const conversationsToSearch = conversationId ? [conversationId] : Object.keys(conversations);
  
  conversationsToSearch.forEach(id => {
    const promise = database.ref(`${DatabasePaths.MESSAGES}/${id}`)
      .once('value')
      .then(snapshot => {
        const results = [];
        snapshot.forEach(messageSnapshot => {
          const message = messageSnapshot.val();
          if (message && message.content && message.content.toLowerCase().includes(searchTerm)) {
            results.push({
              ...message,
              conversationId: id,
              id: messageSnapshot.key
            });
          }
        });
        return results;
      })
      .catch(error => {
        console.warn(`Error searching messages in conversation ${id}:`, error);
        return [];
      });
    
    searchPromises.push(promise);
  });
  
  return Promise.allSettled(searchPromises).then(results => {
    const allResults = [];
    results.forEach(result => {
      if (result.status === 'fulfilled') {
        allResults.push(...result.value);
      }
    });
    
    // Sort by timestamp (newest first)
    return allResults.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
  });
}

// Enhanced validation functions
function validateMessage(content) {
  if (!content || typeof content !== 'string') {
    return { valid: false, error: 'Message content is required' };
  }
  
  const trimmed = content.trim();
  if (!trimmed) {
    return { valid: false, error: 'Message cannot be empty' };
  }
  
  if (trimmed.length > 10000) {
    return { valid: false, error: 'Message is too long (max 10,000 characters)' };
  }
  
  return { valid: true, content: trimmed };
}

function validateConversationData(recipientId, subject, content) {
  const errors = [];
  
  if (!recipientId) {
    errors.push('Recipient is required');
  } else if (!users[recipientId]) {
    errors.push('Selected recipient is not available');
  }
  
  if (!subject || !subject.trim()) {
    errors.push('Subject is required');
  } else if (subject.trim().length > 100) {
    errors.push('Subject is too long (max 100 characters)');
  }
  
  const messageValidation = validateMessage(content);
  if (!messageValidation.valid) {
    errors.push(messageValidation.error);
  }
  
  return {
    valid: errors.length === 0,
    errors: errors
  };
}

// Enhanced session management
function handleSessionExpiry() {
  console.warn('⚠️ Session expired, reinitializing...');
  
  // Clean up existing session
  cleanupAllListeners();
  
  // Reset state
  currentUser = null;
  currentConversation = null;
  conversations = {};
  users = {};
  
  // Show notification
  showToast('Session expired. Reconnecting...', 'info');
  
  // Attempt to reinitialize
  setTimeout(() => {
    initializeAuth();
  }, 2000);
}

// Enhanced offline handling
function handleOfflineMode() {
  console.log('📴 Entering offline mode...');
  updateConnectionStatus('disconnected');
  showToast('You are currently offline. Some features may not be available.', 'info');
  
  // Disable interactive elements that require connectivity
  const sendBtn = getElement('sendBtn');
  const newMessageBtn = getElement('newMessageBtn');
  const refreshBtn = getElement('refreshMessages');
  
  if (sendBtn) {
    sendBtn.disabled = true;
    sendBtn.title = 'Offline - Cannot send messages';
  }
  
  if (newMessageBtn) {
    newMessageBtn.disabled = true;
    newMessageBtn.title = 'Offline - Cannot create new conversations';
  }
  
  if (refreshBtn) {
    refreshBtn.disabled = true;
    refreshBtn.title = 'Offline - Cannot refresh';
  }
}

function handleOnlineMode() {
  console.log('🌐 Returning to online mode...');
  updateConnectionStatus('connected');
  showToast('Connection restored', 'success');
  
  // Re-enable interactive elements
  const sendBtn = getElement('sendBtn');
  const newMessageBtn = getElement('newMessageBtn');
  const refreshBtn = getElement('refreshMessages');
  
  if (sendBtn) {
    sendBtn.disabled = false;
    sendBtn.title = 'Send Message';
  }
  
  if (newMessageBtn) {
    newMessageBtn.disabled = false;
    newMessageBtn.title = 'New Message';
  }
  
  if (refreshBtn) {
    refreshBtn.disabled = false;
    refreshBtn.title = 'Refresh Messages';
  }
  
  // Refresh data
  if (currentUser) {
    loadConversations();
    loadUsers();
  }
}

// Enhanced error recovery
function attemptErrorRecovery(operation, maxRetries = 3) {
  return new Promise((resolve, reject) => {
    let retries = 0;
    
    const tryOperation = () => {
      operation()
        .then(resolve)
        .catch(error => {
          retries++;
          console.warn(`⚠️ Operation failed (attempt ${retries}/${maxRetries}):`, error);
          
          if (retries < maxRetries) {
            // Exponential backoff
            const delay = Math.pow(2, retries) * 1000;
            setTimeout(tryOperation, delay);
          } else {
            reject(error);
          }
        });
    };
    
    tryOperation();
  });
}

// Enhanced performance monitoring
function logPerformanceMetrics() {
  try {
    if (performance && performance.now) {
      const loadTime = performance.now();
      console.log(`📊 Page load time: ${loadTime.toFixed(2)}ms`);
      
      // Log memory usage if available
      if (performance.memory) {
        console.log(`💾 Memory usage: ${(performance.memory.usedJSHeapSize / 1024 / 1024).toFixed(2)}MB`);
      }
      
      // Log conversation count and message count
      const conversationCount = Object.keys(conversations).length;
      const userCount = Object.keys(users).length;
      console.log(`📈 Performance metrics: ${conversationCount} conversations, ${userCount} users`);
    }
  } catch (error) {
    console.warn('⚠️ Could not log performance metrics:', error);
  }
}

// Enhanced accessibility features
function enhanceAccessibility() {
  try {
    // Add ARIA labels to interactive elements
    const conversations = document.querySelectorAll('.conversation-item');
    conversations.forEach((item, index) => {
      item.setAttribute('role', 'button');
      item.setAttribute('tabindex', '0');
      item.setAttribute('aria-label', `Conversation ${index + 1}`);
      
      // Add keyboard support
      item.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          item.click();
        }
      });
    });
    
    // Add live region for announcements
    if (!document.getElementById('liveRegion')) {
      const liveRegion = document.createElement('div');
      liveRegion.id = 'liveRegion';
      liveRegion.setAttribute('aria-live', 'polite');
      liveRegion.setAttribute('aria-atomic', 'true');
      liveRegion.style.position = 'absolute';
      liveRegion.style.left = '-10000px';
      liveRegion.style.width = '1px';
      liveRegion.style.height = '1px';
      liveRegion.style.overflow = 'hidden';
      document.body.appendChild(liveRegion);
    }
    
    console.log('♿ Accessibility features enhanced');
  } catch (error) {
    console.warn('⚠️ Error enhancing accessibility:', error);
  }
}

// Announce to screen readers
function announceToScreenReaders(message) {
  try {
    const liveRegion = document.getElementById('liveRegion');
    if (liveRegion) {
      liveRegion.textContent = message;
    }
  } catch (error) {
    console.warn('⚠️ Error announcing to screen readers:', error);
  }
}

// Export functions for global access with error handling
try {
  window.selectConversation = selectConversation;
  window.openNewMessageModal = openNewMessageModal;
  window.initiateCall = initiateCall;
  window.initiateVideoCall = initiateVideoCall;
  window.showChatOptions = showChatOptions;
  window.attachFile = attachFile;
  window.showEmojiPicker = showEmojiPicker;
  window.closeModalHandler = closeModalHandler;
  window.searchMessages = searchMessages;
  
  // Export utility functions for debugging
  window.PregnaCareMsgDebug = {
    getCurrentUser: () => currentUser,
    getConversations: () => conversations,
    getUsers: () => users,
    getConnectionStatus: () => database ? 'connected' : 'disconnected',
    cleanupListeners: cleanupAllListeners,
    logMetrics: logPerformanceMetrics,
    testButtons: () => {
      const newBtn = document.getElementById('newMessageBtn');
      const refreshBtn = document.getElementById('refreshMessages');
      
      console.log('New Message Button:', newBtn ? 'Found' : 'NOT FOUND');
      console.log('Refresh Button:', refreshBtn ? 'Found' : 'NOT FOUND');
      
      if (newBtn) {
        console.log('New button has click listener:', newBtn.onclick !== null);
        console.log('New button event listeners count:', newBtn.getEventListeners ? Object.keys(newBtn.getEventListeners()).length : 'Cannot check');
      }
      if (refreshBtn) {
        console.log('Refresh button has click listener:', refreshBtn.onclick !== null);
        console.log('Refresh button event listeners count:', refreshBtn.getEventListeners ? Object.keys(refreshBtn.getEventListeners()).length : 'Cannot check');
      }
      
      console.log('Event listeners setup:', setupEventListeners ? 'Function exists' : 'Function missing');
      console.log('Current user:', currentUser ? currentUser.name : 'Not set');
      console.log('Database connection:', database ? 'Connected' : 'Not connected');
    }
  };
  
  console.log('✅ Global functions exported successfully');
} catch (error) {
  console.warn('⚠️ Error exporting global functions:', error);
}

// Enhanced page unload handling
window.addEventListener('beforeunload', () => {
  try {
    console.log('📤 Page unloading, cleaning up...');
    
    // Update user's last seen timestamp
    if (currentUser && database) {
      database.ref(`${DatabasePaths.USERS}/${currentUser.uid}/lastSeen`).set(Date.now());
      
      // Set offline status
      if (presenceRef) {
        presenceRef.set({
          isOnline: false,
          lastSeen: Date.now(),
          platform: 'web'
        });
      }
    }
    
    // Clean up listeners
    cleanupAllListeners();
  } catch (error) {
    console.warn('⚠️ Error during page unload cleanup:', error);
  }
});

// Enhanced online/offline detection
window.addEventListener('online', () => {
  console.log('🌐 Coming back online...');
  handleOnlineMode();
  
  // Reconnect to Firebase
  if (currentUser) {
    setTimeout(() => {
      initializeUserSession();
    }, 1000);
  }
});

window.addEventListener('offline', () => {
  console.log('📴 Going offline...');
  handleOfflineMode();
});

// Performance monitoring
window.addEventListener('load', () => {
  setTimeout(logPerformanceMetrics, 1000);
});

// Enhanced initialization complete
setTimeout(() => {
  if (isInitialized) {
    enhanceAccessibility();
    console.log('🎉 PregnaCare Messages System fully initialized and enhanced');
    
    // Announce successful initialization to screen readers
    announceToScreenReaders('Messaging system loaded successfully');
    
    // Test buttons for debugging
    if (window.PregnaCareMsgDebug) {
      window.PregnaCareMsgDebug.testButtons();
    }
  }
}, 3000);

console.log('✅ PregnaCare Messages System Loaded Successfully');