// Firebase Authentication Integration for PregnaCare Admin Portal
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js';
import { 
  getAuth, 
  signInWithEmailAndPassword,
  onAuthStateChanged,
  signOut
} from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js';
import { 
  getDatabase, 
  ref, 
  get,
  update,
  serverTimestamp,
  onValue
} from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-database.js';

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBGPYM5JHrSXOd9PWbQ4TzoqUtlf5qCwjs",
  authDomain: "pregnacare-web.firebaseapp.com",
  databaseURL: "https://pregnacare-web-default-rtdb.firebaseio.com",
  projectId: "pregnacare-web",
  storageBucket: "pregnacare-web.firebasestorage.app",
  messagingSenderId: "408625794290",
  appId: "1:408625794290:web:bb131c8b35869b31acd46b",
  measurementId: "G-HZB017TYX3"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const database = getDatabase(app);

// Expose Firebase instances globally for dashboard
window.firebaseAuth = auth;
window.firebaseRTDB = database;
window.firebaseDB = database; // Alias for compatibility

// Also expose the firebase database module functions
window.firebase = {
  database: {
    ref,
    get,
    update,
    onValue,
    serverTimestamp
  }
};

// PregnaCare Authentication Module
const pregnaCareAuth = {
  // Current user state
  currentUser: null,
  
  // Initialize authentication
  init() {
    onAuthStateChanged(auth, async (user) => {
      if (user) {
        this.currentUser = user;
        await this.updateLastLogin(user.uid);
        console.log('User authenticated:', user.email);
      } else {
        this.currentUser = null;
        console.log('User not authenticated');
      }
    });
  },
  
  // Sign in function
  async signIn(email, password) {
    try {
      // Attempt to sign in
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      
      // Check if user is an admin
      const adminData = await this.getAdminData(user.uid);
      
      if (!adminData) {
        // Not an admin user
        await signOut(auth);
        return {
          success: false,
          error: 'Access denied. This portal is for administrators only.'
        };
      }
      
      // Check if account is active
      if (adminData.isActive === false) {
        await signOut(auth);
        return {
          success: false,
          error: 'Your account has been deactivated. Please contact support.'
        };
      }
      
      // Update last login
      await this.updateLastLogin(user.uid);
      
      // Store user data in session
      const userData = {
        uid: user.uid,
        email: user.email,
        fullName: adminData.fullName,
        role: adminData.role,
        phone: adminData.phone
      };
      sessionStorage.setItem('pregnaCareAdmin', JSON.stringify(userData));
      
      // Also store in global variable for dashboard immediate access
      window.pregnacare_admin = userData;
      
      return {
        success: true,
        user: {
          uid: user.uid,
          email: user.email,
          fullName: adminData.fullName,
          role: adminData.role,
          emailVerified: user.emailVerified
        }
      };
      
    } catch (error) {
      console.error('Sign in error:', error);
      
      let errorMessage = 'Login failed. Please try again.';
      
      switch (error.code) {
        case 'auth/invalid-email':
          errorMessage = 'Invalid email address format.';
          break;
        case 'auth/user-disabled':
          errorMessage = 'This account has been disabled.';
          break;
        case 'auth/user-not-found':
          errorMessage = 'No account found with this email address.';
          break;
        case 'auth/wrong-password':
          errorMessage = 'Incorrect password. Please try again.';
          break;
        case 'auth/invalid-credential':
          errorMessage = 'Invalid email or password.';
          break;
        case 'auth/too-many-requests':
          errorMessage = 'Too many failed login attempts. Please try again later.';
          break;
        case 'auth/network-request-failed':
          errorMessage = 'Network error. Please check your internet connection.';
          break;
        default:
          errorMessage = error.message || 'An unexpected error occurred.';
      }
      
      return {
        success: false,
        error: errorMessage
      };
    }
  },
  
  // Get admin data from database
  async getAdminData(uid) {
    try {
      const adminRef = ref(database, `adminUsers/${uid}`);
      const snapshot = await get(adminRef);
      
      if (snapshot.exists()) {
        return snapshot.val();
      }
      
      return null;
    } catch (error) {
      console.error('Error fetching admin data:', error);
      return null;
    }
  },
  
  // Update last login timestamp
  async updateLastLogin(uid) {
    try {
      const updates = {
        lastLogin: new Date().toISOString(),
        lastLoginTimestamp: serverTimestamp()
      };
      
      await update(ref(database, `adminUsers/${uid}`), updates);
      console.log('Last login updated');
    } catch (error) {
      console.error('Error updating last login:', error);
    }
  },
  
  // Sign out function
  async signOut() {
    try {
      await signOut(auth);
      sessionStorage.removeItem('pregnaCareAdmin');
      window.pregnacare_admin = null;
      window.location.href = 'Admin login.html';
      return { success: true };
    } catch (error) {
      console.error('Sign out error:', error);
      return { 
        success: false, 
        error: error.message 
      };
    }
  },
  
  // Check if user is authenticated
  isAuthenticated() {
    return this.currentUser !== null;
  },
  
  // Get current user
  getCurrentUser() {
    if (this.currentUser) {
      const sessionData = sessionStorage.getItem('pregnaCareAdmin');
      if (sessionData) {
        return JSON.parse(sessionData);
      } else if (window.pregnacare_admin) {
        return window.pregnacare_admin;
      }
    }
    return null;
  },
  
  // Protected route check
  checkAuthState(redirectTo = 'Admin login.html') {
    onAuthStateChanged(auth, async (user) => {
      if (!user) {
        // Not authenticated, redirect to login
        window.location.href = redirectTo;
      } else {
        // Check if admin
        const adminData = await this.getAdminData(user.uid);
        if (!adminData || adminData.isActive === false) {
          await signOut(auth);
          window.location.href = redirectTo;
        }
      }
    });
  }
};

// Initialize authentication
pregnaCareAuth.init();

// Make available globally
window.pregnaCareAuth = pregnaCareAuth;

// Export for module usage
export default pregnaCareAuth;