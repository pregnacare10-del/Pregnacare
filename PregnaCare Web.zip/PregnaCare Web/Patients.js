// PregnaCare Patients System - Firebase Integration with Unified Notifications
// Author: Claude AI Assistant
// Date: January 2025

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBGPYM5JHrSXOd9PWbQ4TzoqUtlf5qCwjs",
  authDomain: "pregnacare-web.firebaseapp.com",
  databaseURL: "https://pregnacare-web-default-rtdb.firebaseio.com",
  projectId: "pregnacare-web",
  storageBucket: "pregnacare-web.firebasestorage.app",
  messagingSenderId: "408625794290",
  appId: "1:408625794290:web:bb131c8b35869b31acd46b",
  measurementId: "G-HZB017TYX3"
};

// Initialize Firebase
let db;
let isFirebaseConnected = false;
let firebaseModules = {};
let currentUser = { uid: 'patients-module', displayName: 'Patients System' };

// Try to load Firebase
async function initializeFirebase() {
  try {
    // Import Firebase modules
    const { initializeApp } = await import('https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js');
    const { getDatabase, ref, push, onValue, remove, set, update } = await import('https://www.gstatic.com/firebasejs/10.7.1/firebase-database.js');
    
    const app = initializeApp(firebaseConfig);
    db = getDatabase(app);
    
    // Store Firebase functions for global access
    firebaseModules = { ref, push, onValue, remove, set, update };
    
    isFirebaseConnected = true;
    updateFirebaseStatus();
    
    // Initialize notification system
    await initializeNotificationSystem();
    
    // Load patients after successful connection
    loadPatients();
    
    // Start monitoring patients
    startPatientMonitoring();
    
  } catch (error) {
    console.error(error);
    updateFirebaseStatus('error');
    loadDemoData();
  }
}

// Initialize Notification System
async function initializeNotificationSystem() {
  if (db && window.notificationSystem) {
    try {
      await window.notificationSystem.initialize(db, currentUser);
      console.log('✅ Notification system initialized for Patients');
    } catch (error) {
      console.error('Failed to initialize notification system:', error);
    }
  }
}

// Start monitoring patients for due dates and status changes
function startPatientMonitoring() {
  // Check approaching due dates daily
  checkApproachingDueDates();
  setInterval(() => {
    checkApproachingDueDates();
  }, 24 * 60 * 60 * 1000);
  
  // Check for overdue patients every hour
  setInterval(() => {
    checkOverduePatients();
  }, 60 * 60 * 1000);
}

// Check for approaching due dates
function checkApproachingDueDates() {
  const today = new Date();
  const oneWeekFromNow = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);
  const threeDaysFromNow = new Date(today.getTime() + 3 * 24 * 60 * 60 * 1000);
  
  Object.entries(patients).forEach(([key, patient]) => {
    const dueDate = new Date(patient.dueDate);
    
    // Skip if already completed
    if (patient.status === 'Completed') return;
    
    // 7-day warning
    if (dueDate > today && dueDate <= oneWeekFromNow) {
      const notificationKey = `patient_due_7d_${patient.patientId}`;
      if (!hasRecentNotification(notificationKey)) {
        if (window.NotificationIntegration && window.NotificationIntegration.patients) {
          window.NotificationIntegration.patients.notifyApproachingDueDate(patient);
        }
        markNotificationSent(notificationKey);
      }
    }
    
    // 3-day urgent warning
    if (dueDate > today && dueDate <= threeDaysFromNow) {
      const notificationKey = `patient_due_3d_${patient.patientId}`;
      if (!hasRecentNotification(notificationKey)) {
        window.notificationSystem.createNotification({
          title: '⚠️ Urgent: Due Date Approaching',
          message: `${patient.fullName} is due in 3 days or less! Due date: ${dueDate.toLocaleDateString()}`,
          type: 'warning',
          category: 'patients',
          priority: 'urgent',
          metadata: {
            patientId: patient.patientId,
            patientName: patient.fullName,
            dueDate: patient.dueDate
          },
          actionUrl: 'Patients.html',
          actionText: 'View Patient'
        });
        markNotificationSent(notificationKey);
      }
    }
  });
}

// Check for overdue patients
function checkOverduePatients() {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  Object.entries(patients).forEach(([key, patient]) => {
    const dueDate = new Date(patient.dueDate);
    dueDate.setHours(0, 0, 0, 0);
    
    // Check if overdue and not completed
    if (dueDate < today && patient.status !== 'Completed') {
      const notificationKey = `patient_overdue_${patient.patientId}`;
      const daysOverdue = Math.ceil((today - dueDate) / 86400000);
      
      if (!hasRecentNotification(notificationKey)) {
        window.notificationSystem.createNotification({
          title: '❗ Patient Overdue',
          message: `${patient.fullName} is ${daysOverdue} day${daysOverdue > 1 ? 's' : ''} overdue! Original due date: ${dueDate.toLocaleDateString()}`,
          type: 'error',
          category: 'patients',
          priority: 'urgent',
          metadata: {
            patientId: patient.patientId,
            patientName: patient.fullName,
            dueDate: patient.dueDate,
            daysOverdue: daysOverdue
          },
          actionUrl: 'Patients.html',
          actionText: 'Update Status Now'
        });
        markNotificationSent(notificationKey);
      }
    }
  });
}

// Check if notification was recently sent
function hasRecentNotification(key) {
  const sent = localStorage.getItem(`notif_sent_${key}`);
  if (!sent) return false;
  
  const sentTime = parseInt(sent);
  const hoursSince = (Date.now() - sentTime) / (1000 * 60 * 60);
  
  // Don't send same notification within 24 hours
  return hoursSince < 24;
}

// Mark notification as sent
function markNotificationSent(key) {
  localStorage.setItem(`notif_sent_${key}`, Date.now().toString());
}

// Global variables
const notifIcon = document.getElementById("notifIcon");
const helpIcon = document.getElementById("helpIcon");
const notifDropdown = document.getElementById("notifDropdown");
const helpDropdown = document.getElementById("helpDropdown");
const searchInput = document.getElementById("searchInput");
const form = document.getElementById("patientForm");
const tableBody = document.getElementById("patientTableBody");
const saveBtn = document.getElementById("saveBtn");

let patientCounter = 1;
let patients = {};

// Calculate age from birthdate
function calculateAge(birthdate) {
  const today = new Date();
  const birth = new Date(birthdate);
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
    age--;
  }
  
  return age;
}

// Format full name consistently
function formatFullName(lastName, firstName, middleName) {
  return `${lastName}, ${firstName}, ${middleName}`;
}

// ENHANCED: Normalize name for comparison (handles all edge cases)
function normalizeName(name) {
  if (!name || typeof name !== 'string') return '';
  
  return name
    .trim()
    .toLowerCase()
    .replace(/\s+/g, ' ') // Replace multiple spaces with single space
    .replace(/[^\w\s,]/g, '') // Remove special characters except letters, numbers, spaces, and commas
    .replace(/,\s+/g, ', ') // Normalize comma spacing
    .replace(/\s+,/g, ','); // Remove spaces before commas
}

// ENHANCED: More robust duplicate name checking
function checkDuplicateName(fullName, excludeKey = null) {
  if (!fullName) return false;
  
  const normalizedNewName = normalizeName(fullName);
  
  // Double check - if normalized name is empty, don't allow
  if (!normalizedNewName || normalizedNewName.length < 5) {
    return false;
  }
  
  for (const [key, patient] of Object.entries(patients)) {
    // Skip if we're excluding this key (for edit mode)
    if (excludeKey && key === excludeKey) continue;
    
    // Skip if patient doesn't have a fullName
    if (!patient || !patient.fullName) continue;
    
    const normalizedExistingName = normalizeName(patient.fullName);
    
    if (normalizedExistingName === normalizedNewName) {
      console.log('Duplicate found:', {
        existing: normalizedExistingName,
        new: normalizedNewName,
        patientId: patient.patientId
      });
      return true; // Duplicate found
    }
  }
  
  return false; // No duplicate
}

// ENHANCED: Get existing patient with better error handling
function getExistingPatientByName(fullName, excludeKey = null) {
  if (!fullName) return null;
  
  const normalizedNewName = normalizeName(fullName);
  
  for (const [key, patient] of Object.entries(patients)) {
    // Skip if we're excluding this key (for edit mode)
    if (excludeKey && key === excludeKey) continue;
    
    // Skip if patient doesn't have a fullName
    if (!patient || !patient.fullName) continue;
    
    const normalizedExistingName = normalizeName(patient.fullName);
    if (normalizedExistingName === normalizedNewName) {
      return { key, patient };
    }
  }
  
  return null;
}

// Firebase status indicator
function updateFirebaseStatus(status, message) {
  const statusEl = document.getElementById('firebaseStatus');
  if (!statusEl) return;
  
  if (status === 'connected') {
    setTimeout(() => {
      statusEl.style.opacity = '0';
      setTimeout(() => statusEl.style.display = 'none', 300);
    }, 3000);
  }
}

// Load patients from Firebase
function loadPatients() {
  if (!isFirebaseConnected) {
    renderNoData();
    return;
  }

  try {
    const patientsRef = firebaseModules.ref(db, 'patients');
    firebaseModules.onValue(patientsRef, (snapshot) => {
      const data = snapshot.val();
      patients = data || {};
      
      // Update counter based on existing patients
      updatePatientCounter();
      
      // Check and update patient statuses based on due dates
      checkAndUpdatePatientStatuses();
      
      renderPatients();
    }, (error) => {
      console.error('Error loading patients:', error);
      updateFirebaseStatus('error', 'Error loading data');
      renderNoData();
    });
  } catch (error) {
    console.error('Error setting up Firebase listener:', error);
    renderNoData();
  }
}

// Function to find the next highest patient number (never reuse)
function updatePatientCounter() {
  if (Object.keys(patients).length === 0) {
    patientCounter = 1;
    return;
  }
  
  // Extract all existing patient ID numbers and find the highest one
  const existingIds = Object.values(patients)
    .map(patient => {
      // Extract number from patient ID (e.g., "PT001" -> 1, "PT002" -> 2)
      const match = patient.patientId.match(/PT(\d+)/);
      return match ? parseInt(match[1], 10) : 0;
    })
    .filter(id => !isNaN(id) && id > 0);
  
  // Set counter to highest existing number + 1 (never reuse deleted numbers)
  if (existingIds.length > 0) {
    patientCounter = Math.max(...existingIds) + 1;
  } else {
    patientCounter = 1;
  }
  
  console.log('Patient counter updated to:', patientCounter);
  console.log('Existing IDs:', existingIds.sort((a, b) => a - b));
}

// Check and update patient statuses based on due dates
async function checkAndUpdatePatientStatuses() {
  const today = new Date();
  today.setHours(0, 0, 0, 0); // Set to start of day for accurate comparison
  
  let updatedCount = 0;
  const updates = [];

  for (const [key, patient] of Object.entries(patients)) {
    const dueDate = new Date(patient.dueDate);
    dueDate.setHours(0, 0, 0, 0); // Set to start of day
    
    // If due date has passed and status is not already "Completed"
    if (dueDate <= today && patient.status !== 'Completed') {
      // Update patient status to Completed
      const updatedPatient = {
        ...patient,
        status: 'Completed',
        updatedAt: Date.now(),
        autoUpdated: true // Flag to track auto-updates
      };
      
      if (isFirebaseConnected) {
        updates.push({
          key,
          patient: updatedPatient,
          oldStatus: patient.status
        });
      } else {
        // Update locally if Firebase is not available
        patients[key] = updatedPatient;
        updatedCount++;
      }
    }
  }

  // Process Firebase updates
  if (isFirebaseConnected && updates.length > 0) {
    try {
      for (const update of updates) {
        const patientRef = firebaseModules.ref(db, `patients/${update.key}`);
        await firebaseModules.set(patientRef, update.patient);
        updatedCount++;
        
        console.log(`Auto-updated ${update.patient.fullName} from ${update.oldStatus} to Completed`);
        
        // Send notification for status update
        if (window.NotificationIntegration && window.NotificationIntegration.patients) {
          window.NotificationIntegration.patients.notifyStatusUpdate({
            patientId: update.patient.patientId,
            fullName: update.patient.fullName,
            oldStatus: update.oldStatus,
            newStatus: 'Completed'
          });
        }
      }
      
      if (updatedCount > 0) {
        showNotification(
          `🎉 ${updatedCount} patient${updatedCount > 1 ? 's' : ''} automatically marked as completed!`, 
          'success'
        );
      }
    } catch (error) {
      console.error('Error auto-updating patient statuses:', error);
      showNotification('⚠️ Error updating patient statuses automatically', 'warning');
    }
  } else if (!isFirebaseConnected && updatedCount > 0) {
    showNotification(
      `🎉 ${updatedCount} patient${updatedCount > 1 ? 's' : ''} automatically marked as completed!`, 
      'success'
    );
  }
}

// Load demo data if Firebase is not available
function loadDemoData() {
  patients = {
    'demo1': {
      patientId: 'PT001',
      fullName: 'Santos, Maria, Cruz',
      lastName: 'Santos',
      firstName: 'Maria',
      middleName: 'Cruz',
      birthdate: '1996-07-08',
      age: 28,
      dueDate: '2025-07-12',
      status: 'Ongoing',
      createdAt: Date.now()
    },
    'demo2': {
      patientId: 'PT002',
      fullName: 'Dela Cruz, Anna, Mae',
      lastName: 'Dela Cruz',
      firstName: 'Anna',
      middleName: 'Mae',
      birthdate: '1992-03-15',
      age: 32,
      dueDate: '2025-08-03',
      status: 'Completed',
      createdAt: Date.now()
    },
    'demo3': {
      patientId: 'PT003',
      fullName: 'Lopez, Catherine, Rose',
      lastName: 'Lopez',
      firstName: 'Catherine',
      middleName: 'Rose',
      birthdate: '1999-11-22',
      age: 25,
      dueDate: '2025-09-18',
      status: 'Ongoing',
      createdAt: Date.now()
    }
  };
  updatePatientCounter();
  checkAndUpdatePatientStatuses();
  renderPatients();
}

// Render "No Data" state
function renderNoData() {
  tableBody.innerHTML = `
    <tr class="no-data-row">
      <td colspan="6" style="text-align: center; padding: 60px 20px; color: var(--gray-text);">
        <div style="display: flex; flex-direction: column; align-items: center; gap: 15px;">
          <i class="fas fa-users" style="font-size: 48px; color: var(--light-pink); margin-bottom: 10px;"></i>
          <h3 style="color: var(--deep-red); margin: 0; font-size: 18px;">No Patients Found</h3>
          <p style="margin: 0; font-size: 14px; max-width: 300px; line-height: 1.5;">
            ${isFirebaseConnected ? 
              'No patients have been added yet. Use the "Add New Patient" button above to get started.' : 
              'Unable to load patient data. Please check your connection and try again.'
            }
          </p>
          ${!isFirebaseConnected ? 
            '<button onclick="location.reload()" style="margin-top: 15px; background: linear-gradient(135deg, var(--heart-red), var(--deep-red)); color: white; border: none; padding: 12px 24px; border-radius: 20px; cursor: pointer; font-weight: 600; transition: all 0.3s ease;"><i class="fas fa-refresh"></i> Retry Connection</button>' : 
            ''
          }
        </div>
      </td>
    </tr>
  `;
}

// Render patients in table
function renderPatients() {
  if (!patients || Object.keys(patients).length === 0) {
    renderNoData();
    return;
  }

  tableBody.innerHTML = '';
  
  // Sort patients by creation date (newest first)
  const sortedPatients = Object.entries(patients).sort((a, b) => {
    return (b[1].createdAt || 0) - (a[1].createdAt || 0);
  });
  
  sortedPatients.forEach(([key, patient]) => {
    const row = createPatientRow(key, patient);
    tableBody.appendChild(row);
  });
}

// Create patient row
function createPatientRow(key, patient) {
  const row = document.createElement('tr');
  row.dataset.key = key;
  row.style.animation = 'fadeIn 0.3s ease-out';
  
  // Format due date
  const dueDate = new Date(patient.dueDate);
  const formattedDate = dueDate.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: '2-digit'
  });
  
  // Check if due date has passed
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const dueDateOnly = new Date(patient.dueDate);
  dueDateOnly.setHours(0, 0, 0, 0);
  const isPastDue = dueDateOnly <= today;
  
  // Add visual indicator for past due dates
  const dueDateDisplay = isPastDue && patient.status !== 'Completed' ? 
    `<span style="color: #e63946; font-weight: bold;">${formattedDate} ⚠️</span>` : 
    formattedDate;
  
  // Add indicator if patient was auto-updated
  const statusDisplay = patient.autoUpdated ? 
    `<span class="status ${patient.status.toLowerCase()}" title="Automatically updated on due date">
      ${patient.status} <i class="fas fa-robot" style="font-size: 10px; margin-left: 4px;"></i>
    </span>` :
    `<span class="status ${patient.status.toLowerCase()}">${patient.status}</span>`;
  
  // Display age calculated from birthdate
  const ageDisplay = patient.birthdate ? 
    `${calculateAge(patient.birthdate)} years` : 
    `${patient.age || 'N/A'} years`;
  
  row.innerHTML = `
    <td><strong>${patient.patientId}</strong></td>
    <td>
      <div style="display: flex; align-items: center; gap: 10px;">
        <div style="width: 32px; height: 32px; background: linear-gradient(135deg, var(--light-pink), var(--pale-pink)); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; color: var(--deep-red); font-size: 12px;">
          ${patient.fullName.charAt(0).toUpperCase()}
        </div>
        <span>${patient.fullName}</span>
      </div>
    </td>
    <td>${ageDisplay}</td>
    <td>${dueDateDisplay}</td>
    <td>${statusDisplay}</td>
    <td>
      <div class="actions">
        <button class="btn edit" onclick="editPatient('${key}')">Edit</button>
        <button class="btn delete" onclick="deletePatient('${key}')">Delete</button>
      </div>
    </td>
  `;
  
  return row;
}

// ENHANCED: Add patient with comprehensive duplicate checking
async function addPatient(patientData) {
  console.log('Attempting to add patient:', patientData);
  
  // Basic validation
  if (!patientData.fullName || !patientData.birthdate || !patientData.dueDate || !patientData.status) {
    throw new Error('All fields are required');
  }

  // ENHANCED: Multiple layers of duplicate checking
  const normalizedFullName = normalizeName(patientData.fullName);
  console.log('Normalized name for duplicate check:', normalizedFullName);
  
  // Check 1: Direct full name comparison
  if (checkDuplicateName(patientData.fullName)) {
    const existingPatient = getExistingPatientByName(patientData.fullName);
    if (existingPatient) {
      console.log('Duplicate found in Check 1:', existingPatient);
      throw new Error(`❌ DUPLICATE PATIENT DETECTED!\n\nPatient "${patientData.fullName}" already exists with ID: ${existingPatient.patient.patientId}\n\nPlease use a different name or update the existing patient record.`);
    }
  }
  
  // Check 2: Manual verification for additional safety
  for (const [key, existingPatient] of Object.entries(patients)) {
    if (!existingPatient || !existingPatient.fullName) continue;
    
    const existingNormalized = normalizeName(existingPatient.fullName);
    if (existingNormalized === normalizedFullName) {
      console.log('Duplicate found in Check 2:', existingPatient);
      throw new Error(`❌ DUPLICATE PATIENT DETECTED!\n\nPatient "${existingPatient.fullName}" already exists with ID: ${existingPatient.patientId}\n\nCannot add duplicate patient to the system.`);
    }
    
    // Check 3: Also check individual name components for extra safety
    const existingLastName = normalizeName(existingPatient.lastName || '');
    const existingFirstName = normalizeName(existingPatient.firstName || '');
    const existingMiddleName = normalizeName(existingPatient.middleName || '');
    
    const newLastName = normalizeName(patientData.lastName || '');
    const newFirstName = normalizeName(patientData.firstName || '');
    const newMiddleName = normalizeName(patientData.middleName || '');
    
    if (existingLastName === newLastName && 
        existingFirstName === newFirstName && 
        existingMiddleName === newMiddleName &&
        existingLastName && existingFirstName && existingMiddleName) {
      console.log('Duplicate found in Check 3:', existingPatient);
      throw new Error(`❌ DUPLICATE PATIENT DETECTED!\n\nA patient with the same name already exists:\n${existingPatient.fullName} (ID: ${existingPatient.patientId})\n\nCannot add duplicate patient.`);
    }
  }

  console.log('No duplicates found, proceeding to add patient...');

  if (isFirebaseConnected) {
    try {
      showNotification('💾 Saving patient to database...', 'info', 'patients');
      
      const patientsRef = firebaseModules.ref(db, 'patients');
      const newPatientRef = await firebaseModules.push(patientsRef, {
        ...patientData,
        createdAt: Date.now(),
        updatedAt: Date.now()
      });
      
      console.log('Patient added successfully with ID:', newPatientRef.key);
      
      // Send notification for new patient
      if (window.NotificationIntegration && window.NotificationIntegration.patients) {
        window.NotificationIntegration.patients.notifyNewPatient(patientData);
      }
      
      // Check if initial appointment needs to be scheduled
      window.notificationSystem.createNotification({
        title: 'Schedule Initial Appointment',
        message: `New patient ${patientData.fullName} has been registered. Would you like to schedule their initial appointment?`,
        type: 'info',
        category: 'appointments',
        priority: 'normal',
        metadata: {
          patientId: patientData.patientId,
          patientName: patientData.fullName,
          triggerModule: 'patients'
        },
        actionUrl: 'Appointments.html',
        actionText: 'Schedule Appointment'
      });
      
      showNotification(`✅ ${patientData.fullName} added successfully!`, 'success', 'patients');
      
      return newPatientRef.key;
    } catch (error) {
      console.error('Error adding patient to Firebase:', error);
      showNotification(`❌ Error adding patient: ${error.message}`, 'error', 'patients');
      throw error;
    }
  } else {
    // Fallback: Add to local storage if Firebase is not available
    const key = `local_${Date.now()}`;
    patients[key] = {
      ...patientData,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    updatePatientCounter(); // Update counter after adding locally
    renderPatients();
    showNotification('⚠️ Patient added locally (Firebase unavailable)', 'warning', 'patients');
    return key;
  }
}

// Update existing patient
async function updatePatient(key, patientData) {
  // ENHANCED: Check for duplicates when updating (excluding current patient)
  if (checkDuplicateName(patientData.fullName, key)) {
    const existingPatient = getExistingPatientByName(patientData.fullName, key);
    if (existingPatient) {
      showNotification(`❌ Cannot update: Patient "${patientData.fullName}" already exists with ID ${existingPatient.patient.patientId}`, 'error', 'patients');
      return;
    }
  }
  
  const oldPatient = patients[key];
  const statusChanged = oldPatient && oldPatient.status !== patientData.status;
  
  const updatedPatient = {
    ...patientData,
    updatedAt: Date.now()
  };
  
  if (isFirebaseConnected) {
    try {
      const patientRef = firebaseModules.ref(db, `patients/${key}`);
      await firebaseModules.update(patientRef, updatedPatient);
      
      // Send notification for status change
      if (statusChanged && window.NotificationIntegration && window.NotificationIntegration.patients) {
        window.NotificationIntegration.patients.notifyStatusUpdate({
          patientId: patientData.patientId,
          fullName: patientData.fullName,
          oldStatus: oldPatient.status,
          newStatus: patientData.status
        });
      }
      
      showNotification('✅ Patient updated successfully!', 'success', 'patients');
      closeModal('patientDetailsModal');
    } catch (error) {
      console.error('Error updating patient:', error);
      showNotification('❌ Error updating patient. Please try again.', 'error', 'patients');
    }
  } else {
    // Fallback to local storage
    if (patients[key]) {
      patients[key] = { ...patients[key], ...updatedPatient };
      renderPatients();
      showNotification('⚠️ Patient updated locally (Firebase unavailable)', 'warning', 'patients');
      closeModal('patientDetailsModal');
    }
  }
}

// Delete patient from Firebase
async function deletePatient(key) {
  const patient = patients[key];
  if (!patient) {
    showNotification('❌ Patient not found', 'error', 'patients');
    return;
  }

  const confirmMessage = `⚠️ Delete Patient Confirmation\n\n` +
                        `Patient: ${patient.fullName}\n` +
                        `ID: ${patient.patientId}\n\n` +
                        `This action cannot be undone. Are you sure?`;

  if (confirm(confirmMessage)) {
    if (isFirebaseConnected) {
      try {
        showNotification('🗑️ Deleting patient...', 'info', 'patients');
        
        const patientRef = firebaseModules.ref(db, `patients/${key}`);
        await firebaseModules.remove(patientRef);
        
        showNotification(`✅ ${patient.fullName} deleted successfully!`, 'success', 'patients');
      } catch (error) {
        console.error('Error deleting patient:', error);
        showNotification(`❌ Error deleting patient: ${error.message}`, 'error', 'patients');
      }
    } else {
      // Delete from local storage if Firebase is not available
      delete patients[key];
      updatePatientCounter(); // Update counter after deletion
      renderPatients();
      showNotification('⚠️ Patient deleted locally (Firebase unavailable)', 'warning', 'patients');
    }
  }
}

// Edit patient function
function editPatient(key) {
  const patient = patients[key];
  if (!patient) return;
  
  showPatientModal({
    ...patient,
    key: key,
    action: 'edit'
  });
}

// Show patient modal - Updated to only handle edit
function showPatientModal(data) {
  let modal = document.getElementById('patientDetailsModal');
  
  if (!modal) {
    modal = createPatientDetailsModal();
  }
  
  const modalContent = modal.querySelector('.modal-content');
  
  // Only handle edit action now
  if (data.action === 'edit') {
    modalContent.innerHTML = `
      <span class="close">&times;</span>
      <h2>Edit Patient</h2>
      <form id="editPatientForm">
        <div class="form-group">
          <label>Patient ID:</label>
          <input type="text" id="editPatientId" value="${data.patientId}" readonly style="background-color: #f5f5f5; cursor: not-allowed;">
        </div>
        <div class="form-group">
          <label>Last Name:</label>
          <input type="text" id="editLastName" value="${data.lastName || ''}" required placeholder="Enter last name">
        </div>
        <div class="form-group">
          <label>First Name:</label>
          <input type="text" id="editFirstName" value="${data.firstName || ''}" required placeholder="Enter first name">
        </div>
        <div class="form-group">
          <label>Middle Name:</label>
          <input type="text" id="editMiddleName" value="${data.middleName || ''}" required placeholder="Enter middle name">
        </div>
        <div class="form-group">
          <label>Birthday:</label>
          <input type="date" id="editBirthdate" value="${data.birthdate || ''}" required>
          <small id="editAgeDisplay" style="color: #666; margin-top: 5px; display: block;"></small>
        </div>
        <div class="form-group">
          <label>Due Date:</label>
          <input type="date" id="editDueDate" value="${data.dueDate}" required>
        </div>
        <div class="form-group">
          <label>Status:</label>
          <select id="editStatus" required>
            <option value="Ongoing" ${data.status === 'Ongoing' ? 'selected' : ''}>Ongoing</option>
            <option value="Completed" ${data.status === 'Completed' ? 'selected' : ''}>Completed</option>
          </select>
        </div>
        <div class="form-buttons">
          <button type="button" class="form-btn secondary" onclick="closeModal('patientDetailsModal')">Cancel</button>
          <button type="submit" class="form-btn primary">Save Changes</button>
        </div>
      </form>
    `;
    
    // Setup birthdate change listener for age calculation
    const birthdateInput = document.getElementById('editBirthdate');
    const ageDisplay = document.getElementById('editAgeDisplay');
    
    function updateAgeDisplay() {
      if (birthdateInput.value) {
        const age = calculateAge(birthdateInput.value);
        ageDisplay.textContent = `Age: ${age} years`;
        ageDisplay.style.color = age >= 10 && age <= 50 ? '#10b981' : '#e63946';
      } else {
        ageDisplay.textContent = '';
      }
    }
    
    birthdateInput.addEventListener('change', updateAgeDisplay);
    updateAgeDisplay(); // Initial calculation
    
    // Setup form submission
    const form = document.getElementById('editPatientForm');
    form.onsubmit = async function(e) {
      e.preventDefault();

      const lastName = document.getElementById('editLastName').value.trim();
      const firstName = document.getElementById('editFirstName').value.trim();
      const middleName = document.getElementById('editMiddleName').value.trim();
      const birthdate = document.getElementById('editBirthdate').value;
      const dueDate = document.getElementById('editDueDate').value;
      const status = document.getElementById('editStatus').value;
      
      // Validate
      const errors = [];
      const fullName = formatFullName(lastName, firstName, middleName);

      if (!lastName || lastName.length < 2) {
        errors.push('Last name must be at least 2 characters long');
      }
      
      if (!firstName || firstName.length < 2) {
        errors.push('First name must be at least 2 characters long');
      }
      
      if (!middleName || middleName.length < 2) {
        errors.push('Middle name must be at least 2 characters long');
      }

      // ENHANCED: Check for duplicate names (excluding current patient)
      if (fullName && checkDuplicateName(fullName, data.key)) {
        const existingPatient = getExistingPatientByName(fullName, data.key);
        if (existingPatient) {
          errors.push(`Patient "${fullName}" already exists with ID ${existingPatient.patient.patientId}`);
        }
      }

      if (!birthdate) {
        errors.push('Birthday is required');
      } else {
        const age = calculateAge(birthdate);
        if (age < 10 || age > 50) {
          errors.push('Age must be between 10 and 50 years');
        }
      }
      
      if (!dueDate) {
        errors.push('Due date is required');
      }
      
      if (errors.length > 0) {
        showNotification(`❌ ${errors.join('\n')}`, 'error', 'patients');
        return;
      }
      
      const age = calculateAge(birthdate);
      
      const updatedData = {
        patientId: data.patientId, // Keep original ID
        fullName,
        lastName,
        firstName,
        middleName,
        birthdate,
        age,
        dueDate,
        status,
        createdAt: data.createdAt // Preserve creation date
      };
      
      await updatePatient(data.key, updatedData);
    };
    
    // Set minimum date to today for due date
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('editDueDate').min = today;
    
    // Set maximum birthdate to today and minimum to 100 years ago
    const maxBirthdate = new Date().toISOString().split('T')[0];
    const minBirthdate = new Date();
    minBirthdate.setFullYear(minBirthdate.getFullYear() - 100);
    birthdateInput.max = maxBirthdate;
    birthdateInput.min = minBirthdate.toISOString().split('T')[0];
    
    // ENHANCED: Real-time duplicate checking for edit form
    const editLastNameInput = document.getElementById('editLastName');
    const editFirstNameInput = document.getElementById('editFirstName');
    const editMiddleNameInput = document.getElementById('editMiddleName');
    
    function checkForDuplicateEdit() {
      const lastName = editLastNameInput.value.trim();
      const firstName = editFirstNameInput.value.trim();
      const middleName = editMiddleNameInput.value.trim();
      
      // Remove any existing duplicate warning
      const existingWarning = document.querySelector('.duplicate-warning');
      if (existingWarning) {
        existingWarning.remove();
      }

      // Only check if all fields have sufficient length
      if (lastName.length >= 2 && firstName.length >= 2 && middleName.length >= 2) {
        const fullName = formatFullName(lastName, firstName, middleName);
        
        if (checkDuplicateName(fullName, data.key)) {
          const existingPatient = getExistingPatientByName(fullName, data.key);
          if (existingPatient) {
            // Create warning element
            const warning = document.createElement('div');
            warning.className = 'duplicate-warning';
            warning.style.cssText = `
              color: #e63946;
              font-size: 12px;
              margin-top: 5px;
              padding: 8px 12px;
              background: rgba(230, 57, 70, 0.1);
              border: 1px solid rgba(230, 57, 70, 0.2);
              border-radius: 6px;
              display: flex;
              align-items: center;
              gap: 8px;
            `;
            warning.innerHTML = `
              <i class="fas fa-exclamation-triangle"></i>
              <span>⚠️ Patient "${fullName}" already exists with ID ${existingPatient.patient.patientId}</span>
            `;
            
            // Insert warning after the middle name input
            editMiddleNameInput.parentNode.appendChild(warning);
          }
        }
      }
    }
    
    editLastNameInput.addEventListener('input', checkForDuplicateEdit);
    editFirstNameInput.addEventListener('input', checkForDuplicateEdit);
    editMiddleNameInput.addEventListener('input', checkForDuplicateEdit);
  }
  
  modal.style.display = 'block';
  setupModalEvents();
}

// Create patient details modal
function createPatientDetailsModal() {
  const modal = document.createElement('div');
  modal.id = 'patientDetailsModal';
  modal.className = 'modal';
  modal.innerHTML = '<div class="modal-content"></div>';
  document.body.appendChild(modal);
  return modal;
}

// Setup modal events
function setupModalEvents() {
  // Close button functionality
  document.querySelectorAll('.close').forEach(closeBtn => {
    closeBtn.onclick = function() {
      const modal = this.closest('.modal');
      if (modal) {
        modal.style.display = 'none';
      }
    };
  });
  
  // Click outside modal to close
  document.querySelectorAll('.modal').forEach(modal => {
    modal.onclick = function(e) {
      if (e.target === modal) {
        modal.style.display = 'none';
      }
    };
  });
}

// Updated notification function to use unified system
function showNotification(message, type = 'info', category = 'patients') {
  // Use unified notification system if available
  if (window.showNotification) {
    window.showNotification(message, type, category);
  } else {
    // Fallback to old notification system
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.custom-notification');
    existingNotifications.forEach(notif => notif.remove());

    const notification = document.createElement('div');
    notification.className = 'custom-notification';
    
    const colors = {
      success: '#10b981',
      error: '#e63946',
      warning: '#f59e0b',
      info: '#3b82f6'
    };

    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: ${colors[type] || colors.info};
      color: white;
      padding: 15px 20px;
      border-radius: 12px;
      font-weight: 600;
      z-index: 10000;
      box-shadow: 0 8px 32px rgba(0,0,0,0.2);
      max-width: 400px;
      animation: slideIn 0.4s ease-out;
      font-size: 14px;
      border-left: 4px solid rgba(255,255,255,0.3);
      white-space: pre-line;
    `;
    
    notification.textContent = message;
    document.body.appendChild(notification);

    // Auto-hide notification
    setTimeout(() => {
      notification.style.animation = 'slideOut 0.3s ease-in';
      setTimeout(() => notification.remove(), 300);
    }, type === 'error' ? 7000 : 4000); // Show errors longer

    // Click to dismiss
    notification.addEventListener('click', () => {
      notification.style.animation = 'slideOut 0.3s ease-in';
      setTimeout(() => notification.remove(), 300);
    });
  }
}

// Modal functions
function openModal() {
  const modal = document.getElementById('patientModal');
  modal.style.display = 'block';
  
  // Set minimum date to today
  const today = new Date().toISOString().split('T')[0];
  document.getElementById('dueDate').min = today;
  
  // Set maximum birthdate to today and minimum to 100 years ago
  const birthdateInput = document.getElementById('birthdate');
  if (birthdateInput) {
    const maxBirthdate = new Date().toISOString().split('T')[0];
    const minBirthdate = new Date();
    minBirthdate.setFullYear(minBirthdate.getFullYear() - 100);
    birthdateInput.max = maxBirthdate;
    birthdateInput.min = minBirthdate.toISOString().split('T')[0];
  }
  
  // Focus on first input
  setTimeout(() => {
    document.getElementById('lastName').focus();
  }, 100);
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId || 'patientModal');
  if (modal) {
    modal.style.display = 'none';
    
    // Reset form if it's the add patient modal
    if (modalId === 'patientModal' || !modalId) {
      form.reset();
      
      // Reset button state
      saveBtn.innerHTML = '<i class="fas fa-save"></i> Save Patient';
      saveBtn.disabled = false;
      
      // Clear age display
      const ageDisplay = document.getElementById('ageDisplay');
      if (ageDisplay) {
        ageDisplay.textContent = '';
      }
      
      // Clear any duplicate warnings
      const duplicateWarnings = document.querySelectorAll('.duplicate-warning');
      duplicateWarnings.forEach(warning => warning.remove());
    }
  }
}

// ENHANCED: Input validation with comprehensive duplicate checking
function validateForm() {
  const lastName = document.getElementById('lastName').value.trim();
  const firstName = document.getElementById('firstName').value.trim();
  const middleName = document.getElementById('middleName').value.trim();
  const birthdate = document.getElementById('birthdate').value;
  const dueDate = document.getElementById('dueDate').value;
  const status = document.getElementById('status').value;

  const errors = [];

  // Name validation
  if (!lastName || lastName.length < 2) {
    errors.push('Last name must be at least 2 characters long');
  }
  if (!firstName || firstName.length < 2) {
    errors.push('First name must be at least 2 characters long');
  }
  if (!middleName || middleName.length < 2) {
    errors.push('Middle name must be at least 2 characters long');
  }

  // ENHANCED: Comprehensive duplicate checking
  if (lastName && firstName && middleName) {
    const fullName = formatFullName(lastName, firstName, middleName);
    console.log('Validating full name:', fullName);
    
    if (checkDuplicateName(fullName)) {
      const existingPatient = getExistingPatientByName(fullName);
      if (existingPatient) {
        console.log('Duplicate detected during validation:', existingPatient);
        errors.push(`❌ DUPLICATE PATIENT: "${existingPatient.patient.fullName}" already exists with ID ${existingPatient.patient.patientId}. Cannot add duplicate patients.`);
      }
    }
  }

  // Birthdate validation
  if (!birthdate) {
    errors.push('Birthday is required');
  } else {
    const age = calculateAge(birthdate);
    if (age < 10 || age > 50) {
      errors.push('Age must be between 10 and 50 years');
    }
  }

  // Due date validation
  if (!dueDate) {
    errors.push('Due date is required');
  } else {
    const selectedDate = new Date(dueDate);
    const today = new Date();
    const maxDate = new Date();
    maxDate.setFullYear(today.getFullYear() + 1);

    if (selectedDate <= today) {
      errors.push('Due date must be in the future');
    } else if (selectedDate > maxDate) {
      errors.push('Due date cannot be more than 1 year from now');
    }
  }

  // Status validation
  if (!status) {
    errors.push('Please select a status');
  }

  return errors;
}

// Event listeners
document.addEventListener('DOMContentLoaded', function() {
  // Initialize Firebase
  initializeFirebase();

  // Notification dropdown
  if (notifIcon) {
    notifIcon.addEventListener('click', function(e) {
      e.stopPropagation();
      notifDropdown?.classList.toggle('show');
      helpDropdown?.classList.remove('show');
    });
  }

  // Help dropdown
  if (helpIcon) {
    helpIcon.addEventListener('click', function(e) {
      e.stopPropagation();
      helpDropdown?.classList.toggle('show');
      notifDropdown?.classList.remove('show');
    });
  }

  // Close dropdowns when clicking outside
  document.addEventListener('click', function() {
    notifDropdown?.classList.remove('show');
    helpDropdown?.classList.remove('show');
  });

  // Enhanced search functionality
  if (searchInput) {
    searchInput.addEventListener('input', function() {
      const searchTerm = this.value.toLowerCase().trim();
      const rows = tableBody.querySelectorAll('tr:not(.no-data-row)');
      
      let visibleCount = 0;
      rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        const isVisible = text.includes(searchTerm);
        row.style.display = isVisible ? '' : 'none';
        if (isVisible) visibleCount++;
      });

      // Show "no results" message if searching and no results
      if (searchTerm && visibleCount === 0 && rows.length > 0) {
        const noResultsRow = document.createElement('tr');
        noResultsRow.className = 'no-results-row';
        noResultsRow.innerHTML = `
          <td colspan="6" style="text-align: center; padding: 40px 20px; color: var(--gray-text);">
            <i class="fas fa-search" style="font-size: 24px; margin-bottom: 10px; color: var(--light-pink);"></i>
            <p>No patients found matching "${searchTerm}"</p>
          </td>
        `;
        
        // Remove existing no-results row
        const existingNoResults = tableBody.querySelector('.no-results-row');
        if (existingNoResults) existingNoResults.remove();
        
        tableBody.appendChild(noResultsRow);
      } else {
        const noResultsRow = tableBody.querySelector('.no-results-row');
        if (noResultsRow) noResultsRow.remove();
      }
    });
  }

  // Setup birthdate change listener for age calculation in add form
  const birthdateInput = document.getElementById('birthdate');
  const ageDisplay = document.getElementById('ageDisplay');
  
  if (birthdateInput && ageDisplay) {
    birthdateInput.addEventListener('change', function() {
      if (this.value) {
        const age = calculateAge(this.value);
        ageDisplay.textContent = `Age: ${age} years`;
        ageDisplay.style.color = age >= 10 && age <= 50 ? '#10b981' : '#e63946';
      } else {
        ageDisplay.textContent = '';
      }
    });
  }

  // ENHANCED: Real-time duplicate name checking with immediate feedback
  const lastNameInput = document.getElementById('lastName');
  const firstNameInput = document.getElementById('firstName');
  const middleNameInput = document.getElementById('middleName');

  if (lastNameInput && firstNameInput && middleNameInput) {
    function checkForDuplicate() {
      const lastName = lastNameInput.value.trim();
      const firstName = firstNameInput.value.trim();
      const middleName = middleNameInput.value.trim();
      
      // Remove any existing duplicate warning
      const existingWarning = document.querySelector('.duplicate-warning');
      if (existingWarning) {
        existingWarning.remove();
      }

      // Only check if all fields have sufficient length
      if (lastName.length >= 2 && firstName.length >= 2 && middleName.length >= 2) {
        const fullName = formatFullName(lastName, firstName, middleName);
        console.log('Real-time duplicate check for:', fullName);
        
        if (checkDuplicateName(fullName)) {
          const existingPatient = getExistingPatientByName(fullName);
          if (existingPatient) {
            console.log('Real-time duplicate found:', existingPatient);
            
            // Create warning element
            const warning = document.createElement('div');
            warning.className = 'duplicate-warning';
            warning.style.cssText = `
              color: #e63946;
              font-size: 12px;
              margin-top: 5px;
              padding: 12px 15px;
              background: rgba(230, 57, 70, 0.15);
              border: 2px solid rgba(230, 57, 70, 0.3);
              border-radius: 8px;
              display: flex;
              align-items: center;
              gap: 10px;
              font-weight: 600;
            `;
            warning.innerHTML = `
              <i class="fas fa-exclamation-triangle" style="color: #e63946; font-size: 14px;"></i>
              <span>⚠️ DUPLICATE: "${fullName}" already exists with ID ${existingPatient.patient.patientId}</span>
            `;
            
            // Insert warning after the middle name input
            middleNameInput.parentNode.appendChild(warning);
          }
        }
      }
    }
    
    // Add event listeners with debouncing for better performance
    let debounceTimer;
    function debouncedCheck() {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(checkForDuplicate, 300);
    }
    
    lastNameInput.addEventListener('input', debouncedCheck);
    firstNameInput.addEventListener('input', debouncedCheck);
    middleNameInput.addEventListener('input', debouncedCheck);
  }

  // ENHANCED: Form submission with comprehensive validation
  if (form) {
    form.addEventListener('submit', async function(e) {
      e.preventDefault();
      
      console.log('Form submission started...');
      
      // Validate form
      const validationErrors = validateForm();
      if (validationErrors.length > 0) {
        console.log('Validation errors found:', validationErrors);
        showNotification(`❌ VALIDATION ERRORS:\n\n${validationErrors.join('\n')}`, 'error', 'patients');
        return;
      }

      const lastName = document.getElementById('lastName').value.trim();
      const firstName = document.getElementById('firstName').value.trim();
      const middleName = document.getElementById('middleName').value.trim();
      const birthdate = document.getElementById('birthdate').value;
      const dueDate = document.getElementById('dueDate').value;
      const status = document.getElementById('status').value;

      // Show loading state
      saveBtn.innerHTML = '<div class="loading"></div> Checking for duplicates...';
      saveBtn.disabled = true;

      const age = calculateAge(birthdate);
      const fullName = formatFullName(lastName, firstName, middleName);

      // Final duplicate check before submission
      console.log('Final duplicate check before submission...');
      if (checkDuplicateName(fullName)) {
        const existingPatient = getExistingPatientByName(fullName);
        if (existingPatient) {
          console.log('Final duplicate check failed:', existingPatient);
          showNotification(`❌ SUBMISSION BLOCKED!\n\nPatient "${fullName}" already exists with ID ${existingPatient.patient.patientId}.\n\nCannot add duplicate patients to the system.`, 'error', 'patients');
          saveBtn.innerHTML = '<i class="fas fa-save"></i> Save Patient';
          saveBtn.disabled = false;
          return;
        }
      }

      // Generate patient data
      const patientData = {
        patientId: `PT${String(patientCounter).padStart(3, '0')}`,
        fullName,
        lastName,
        firstName,
        middleName,
        birthdate,
        age,
        dueDate,
        status
      };

      console.log('Attempting to add patient:', patientData);
      saveBtn.innerHTML = '<div class="loading"></div> Saving Patient...';

      try {
        await addPatient(patientData);
        patientCounter++; // Increment counter after successful addition
        closeModal();
        console.log('Patient added successfully!');
      } catch (error) {
        console.error('Error saving patient:', error);
        showNotification(`❌ FAILED TO SAVE PATIENT:\n\n${error.message}`, 'error', 'patients');
      } finally {
        saveBtn.innerHTML = '<i class="fas fa-save"></i> Save Patient';
        saveBtn.disabled = false;
      }
    });
  }

  // Close modal when clicking outside
  window.addEventListener('click', function(e) {
    const modal = document.getElementById('patientModal');
    const detailsModal = document.getElementById('patientDetailsModal');
    
    if (e.target === modal) {
      closeModal();
    } else if (e.target === detailsModal) {
      closeModal('patientDetailsModal');
    }
  });

  // Escape key to close modal
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
      const modal = document.getElementById('patientModal');
      const detailsModal = document.getElementById('patientDetailsModal');
      
      if (detailsModal && detailsModal.style.display === 'block') {
        closeModal('patientDetailsModal');
      } else if (modal && modal.style.display === 'block') {
        closeModal();
      }
    }
  });

  // Real-time connection status monitoring
  if (isFirebaseConnected) {
    const connectedRef = firebaseModules.ref(db, '.info/connected');
    firebaseModules.onValue(connectedRef, (snapshot) => {
      if (snapshot.val() === true) {
        updateFirebaseStatus('connected');
      } else {
        updateFirebaseStatus('disconnected');
      }
    });
  }
});

// Add CSS for animations and modal styles
const style = document.createElement('style');
style.textContent = `
  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
  
  @keyframes slideIn {
    from {
      transform: translateX(100%);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }
  
  @keyframes slideOut {
    from {
      transform: translateX(0);
      opacity: 1;
    }
    to {
      transform: translateX(100%);
      opacity: 0;
    }
  }
  
  .no-data-row td button:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 25px rgba(250, 49, 74, 0.4);
  }
  
  .duplicate-warning {
    animation: slideDown 0.3s ease-out;
  }
  
  @keyframes slideDown {
    from { 
      opacity: 0; 
      transform: translateY(-10px); 
      max-height: 0;
    }
    to { 
      opacity: 1; 
      transform: translateY(0); 
      max-height: 100px;
    }
  }
  
  /* Modal content styling to match Lab Results */
  .modal-content {
    background: rgb(255, 209, 209);
    padding: 30px;
    border-radius: 15px;
    max-width: 600px;
    margin: 50px auto;
    position: relative;
    animation: modalSlideIn 0.3s ease-out;
  }
  
  @keyframes modalSlideIn {
    from {
      transform: translateY(-50px);
      opacity: 0;
    }
    to {
      transform: translateY(0);
      opacity: 1;
    }
  }
  
  .view-details {
    padding: 20px 0;
  }
  
  .view-details p {
    margin: 12px 0;
    font-size: 16px;
    color: #333;
  }
  
  .view-details strong {
    color: var(--deep-red);
    font-weight: 600;
    margin-right: 10px;
  }
  
  .form-buttons {
    display: flex;
    gap: 10px;
    margin-top: 25px;
    justify-content: flex-end;
  }
  
  .form-btn {
    padding: 10px 20px;
    border: none;
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
  }
  
  .form-btn.primary {
    background: linear-gradient(135deg, var(--heart-red), var(--deep-red));
    color: white;
  }
  
  .form-btn.primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(230, 57, 70, 0.3);
  }
  
  .form-btn.secondary {
    background: #f0f0f0;
    color: #666;
  }
  
  .form-btn.secondary:hover {
    background: #e0e0e0;
  }

  /* Action buttons styling to match Lab Results exactly */
  .actions {
    display: flex;
    gap: 8px;
    justify-content: flex-start;
  }

  .btn {
    padding: 6px 12px;
    border: none;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s ease;
    text-transform: capitalize;
    min-width: 50px;
  }

  .btn.edit {
    background-color: #f48fb1;
    color: white;
  }

  .btn.edit:hover {
    background-color: #e91e63;
  }

  .btn.delete {
    background-color: #ffcdd2;
    color: #c62828;
  }

  .btn.delete:hover {
    background-color: #ef5350;
    color: white;
  }
  
  /* Loading animation */
  .loading {
    display: inline-block;
    width: 16px;
    height: 16px;
    border: 2px solid rgba(255,255,255,0.3);
    border-radius: 50%;
    border-top-color: white;
    animation: spin 1s ease-in-out infinite;
  }
  
  @keyframes spin {
    to { transform: rotate(360deg); }
  }

  /* Enhanced duplicate warning styling */
  .duplicate-warning {
    animation: slideDown 0.3s ease-out, pulse 2s infinite;
  }
  
  @keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.8; }
  }

  /* Enhanced notification styling */
  .custom-notification {
    cursor: pointer;
    user-select: none;
  }
  
  .custom-notification:hover {
    transform: translateX(-5px);
  }
`;
document.head.appendChild(style);

// Make functions globally available
window.openModal = openModal;
window.closeModal = closeModal;
window.editPatient = editPatient;
window.deletePatient = deletePatient;