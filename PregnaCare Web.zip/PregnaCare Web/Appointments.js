// PregnaCare Appointments System - Firebase Realtime Database Integration with Unified Notifications
// Author: Claude AI Assistant
// Date: January 2025

// Load Firebase SDKs dynamically
function loadFirebaseSDKs() {
  return new Promise((resolve, reject) => {
    // Load Firebase App SDK
    const appScript = document.createElement('script');
    appScript.src = 'https://www.gstatic.com/firebasejs/8.10.1/firebase-app.js';
    appScript.onload = () => {
      // Load Firebase Database SDK after App SDK loads
      const dbScript = document.createElement('script');
      dbScript.src = 'https://www.gstatic.com/firebasejs/8.10.1/firebase-database.js';
      dbScript.onload = () => resolve();
      dbScript.onerror = () => reject(new Error('Failed to load Firebase Database SDK'));
      document.head.appendChild(dbScript);
    };
    appScript.onerror = () => reject(new Error('Failed to load Firebase App SDK'));
    document.head.appendChild(appScript);
  });
}

// Firebase Configuration
const firebaseConfig = {
    apiKey: "AIzaSyBGPYM5JHrSXOd9PWbQ4TzoqUtlf5qCwjs",
    authDomain: "pregnacare-web.firebaseapp.com",
    databaseURL: "https://pregnacare-web-default-rtdb.firebaseio.com",
    projectId: "pregnacare-web",
    storageBucket: "pregnacare-web.firebasestorage.app",
    messagingSenderId: "408625794290",
    appId: "1:408625794290:web:bb131c8b35869b31acd46b",
    measurementId: "G-HZB017TYX3"
};

// Global Variables
let database;
let appointmentsRef;
let patientsRef;
let appointments = [];
let filteredAppointments = [];
let patientsData = {};
let currentUser = { uid: 'appointments-module', displayName: 'Appointments System' };

// DOM Elements
const modal = document.getElementById("modal");
const openModalBtn = document.getElementById("openModal");
const closeModalBtn = document.getElementById("closeModal");
const form = document.getElementById("appointmentForm");
const appointmentCards = document.getElementById("appointmentCards");
const appointmentsBody = document.getElementById("appointmentsBody");
const tableSearch = document.getElementById("tableSearch");
const searchBar = document.querySelector('.search input');

// Auto-Hide Topbar Variables
let lastScrollTop = 0;
let scrollDelta = 5;
let navbarHeight = 80;
let didScroll = false;
let scrollTimer = null;
let autoHideEnabled = true;

// Initialize Firebase and Notification System
async function initializeFirebase() {
  try {
    await loadFirebaseSDKs();
    
    if (typeof firebase !== 'undefined' && firebase.database) {
      firebase.initializeApp(firebaseConfig);
      database = firebase.database();
      appointmentsRef = database.ref('appointments');
      patientsRef = database.ref('patients');
      
      console.log("Firebase Realtime Database initialized");
      updateConnectionStatus("connected");
      
      // Initialize notification system
      await initializeNotificationSystem();
      
      setupRealtimeListener();
      monitorConnection();
      initializePatientDropdown();
      
      // Start appointment monitoring
      startAppointmentMonitoring();
      
    } else {
      throw new Error("Firebase SDK not available");
    }
  } catch (error) {
    console.error("Error initializing Firebase:", error);
    updateConnectionStatus("disconnected");
    showFirebaseError("Failed to connect to database");
    initializeLocalStorage();
    initializePatientDropdown();
  }
}

// Initialize Notification System
async function initializeNotificationSystem() {
  if (database && window.notificationSystem) {
    try {
      await window.notificationSystem.initialize(database, currentUser);
      console.log('✅ Notification system initialized for Appointments');
    } catch (error) {
      console.error('Failed to initialize notification system:', error);
    }
  }
}

// Start monitoring appointments for notifications
function startAppointmentMonitoring() {
  // Initial check
  checkUpcomingAppointments();
  
  // Check every 30 minutes
  setInterval(() => {
    checkUpcomingAppointments();
  }, 30 * 60 * 1000);
}

// Check for upcoming appointments and send notifications
function checkUpcomingAppointments() {
  const now = new Date();
  const twoHoursFromNow = new Date(now.getTime() + 2 * 60 * 60 * 1000);
  const tomorrow = new Date(now.getTime() + 24 * 60 * 60 * 1000);
  
  appointments.forEach(appointment => {
    const appointmentTime = new Date(appointment.time);
    
    // Skip past appointments
    if (appointmentTime < now) {
      // Check if appointment was missed
      if (appointment.status === 'Pending') {
        if (window.NotificationIntegration && window.NotificationIntegration.appointments) {
          window.NotificationIntegration.appointments.notifyMissedAppointment(appointment);
        }
        // Update status to missed
        updateAppointmentInDatabase(appointment.id, { status: 'Missed' });
      }
      return;
    }
    
    // 2-hour reminder
    if (appointmentTime <= twoHoursFromNow && appointmentTime > now) {
      const notificationKey = `appointment_2hr_${appointment.id}`;
      if (!hasRecentNotification(notificationKey)) {
        if (window.NotificationIntegration && window.NotificationIntegration.appointments) {
          window.NotificationIntegration.appointments.notifyUpcomingAppointment(appointment);
        }
        markNotificationSent(notificationKey);
      }
    }
    
    // 24-hour reminder
    if (appointmentTime <= tomorrow && appointmentTime > twoHoursFromNow) {
      const notificationKey = `appointment_24hr_${appointment.id}`;
      if (!hasRecentNotification(notificationKey)) {
        window.notificationSystem.createNotification({
          title: 'Appointment Tomorrow',
          message: `Reminder: ${appointment.name} has an appointment tomorrow at ${appointmentTime.toLocaleTimeString()}`,
          type: 'info',
          category: 'appointments',
          priority: 'normal',
          metadata: {
            appointmentId: appointment.id,
            patientName: appointment.name,
            appointmentTime: appointment.time
          },
          actionUrl: 'Appointments.html',
          actionText: 'View Details'
        });
        markNotificationSent(notificationKey);
      }
    }
  });
}

// Check if notification was recently sent
function hasRecentNotification(key) {
  const sent = localStorage.getItem(`notif_sent_${key}`);
  if (!sent) return false;
  
  const sentTime = parseInt(sent);
  const hoursSince = (Date.now() - sentTime) / (1000 * 60 * 60);
  
  // Don't send same notification within 24 hours
  return hoursSince < 24;
}

// Mark notification as sent
function markNotificationSent(key) {
  localStorage.setItem(`notif_sent_${key}`, Date.now().toString());
}

// Initialize patient data loading
async function initializePatientDropdown() {
  if (database && patientsRef) {
    try {
      patientsRef.on('value', (snapshot) => {
        const data = snapshot.val();
        patientsData = data || {};
        
        console.log(`Loaded ${Object.keys(patientsData).length} patients for dropdown`);
        populatePatientDropdown();
      }, (error) => {
        console.error("Error loading patients for dropdown:", error);
        showNotification("Error loading patients list", "error");
        populatePatientDropdown();
      });
    } catch (error) {
      console.error("Error setting up patient dropdown:", error);
      populatePatientDropdown();
    }
  } else {
    populatePatientDropdown();
  }
}

// Populate the patient dropdown
function populatePatientDropdown() {
  const patientSelect = document.getElementById("patientName");
  
  if (!patientSelect) {
    console.error("Patient select element not found");
    return;
  }

  patientSelect.innerHTML = '<option value="">Select a patient...</option>';

  if (!patientsData || Object.keys(patientsData).length === 0) {
    if (database) {
      patientSelect.innerHTML = `
        <option value="">No patients found</option>
        <option value="" disabled>─────────────────────</option>
        <option value="" disabled>Add patients in the Patients page first</option>
      `;
    } else {
      patientSelect.innerHTML = `
        <option value="">Loading patients...</option>
        <option value="" disabled>─────────────────────</option>
        <option value="" disabled>Firebase connection required</option>
      `;
    }
    patientSelect.disabled = true;
    return;
  }

  patientSelect.disabled = false;

  const sortedPatients = Object.entries(patientsData).sort((a, b) => {
    return a[1].fullName.localeCompare(b[1].fullName);
  });

  const activePatients = sortedPatients.filter(([key, patient]) => 
    patient.status === 'Ongoing' || patient.status === 'Scheduled'
  );
  
  const otherPatients = sortedPatients.filter(([key, patient]) => 
    patient.status !== 'Ongoing' && patient.status !== 'Scheduled'
  );

  if (activePatients.length > 0) {
    const activeGroup = document.createElement('optgroup');
    activeGroup.label = 'Active Patients';
    
    activePatients.forEach(([key, patient]) => {
      const option = document.createElement('option');
      option.value = patient.fullName;
      option.textContent = `${patient.fullName} (ID: ${patient.patientId})`;
      option.dataset.patientId = patient.patientId;
      option.dataset.patientKey = key;
      option.dataset.age = patient.age;
      option.dataset.dueDate = patient.dueDate;
      option.dataset.status = patient.status;
      activeGroup.appendChild(option);
    });
    
    patientSelect.appendChild(activeGroup);
  }

  if (otherPatients.length > 0) {
    const otherGroup = document.createElement('optgroup');
    otherGroup.label = 'Other Patients';
    
    otherPatients.forEach(([key, patient]) => {
      const option = document.createElement('option');
      option.value = patient.fullName;
      option.textContent = `${patient.fullName} (ID: ${patient.patientId})`;
      option.dataset.patientId = patient.patientId;
      option.dataset.patientKey = key;
      option.dataset.age = patient.age;
      option.dataset.dueDate = patient.dueDate;
      option.dataset.status = patient.status;
      otherGroup.appendChild(option);
    });
    
    patientSelect.appendChild(otherGroup);
  }

  const summaryOption = document.createElement('option');
  summaryOption.value = '';
  summaryOption.disabled = true;
  summaryOption.textContent = `─────────────────────`;
  patientSelect.appendChild(summaryOption);

  const countOption = document.createElement('option');
  countOption.value = '';
  countOption.disabled = true;
  countOption.textContent = `Total: ${Object.keys(patientsData).length} patients`;
  patientSelect.appendChild(countOption);
}

// Handle patient selection change
function handlePatientSelection() {
  const patientSelect = document.getElementById("patientName");
  const selectedOption = patientSelect.options[patientSelect.selectedIndex];
  
  if (selectedOption && selectedOption.dataset.patientId) {
    console.log("Selected patient:", {
      name: selectedOption.value,
      id: selectedOption.dataset.patientId,
      age: selectedOption.dataset.age,
      dueDate: selectedOption.dataset.dueDate,
      status: selectedOption.dataset.status
    });
    
    showPatientInfo(selectedOption);
  }
}

// Show selected patient information
function showPatientInfo(selectedOption) {
  const existingInfo = document.querySelector('.patient-info-display');
  if (existingInfo) {
    existingInfo.remove();
  }

  if (selectedOption && selectedOption.dataset.patientId) {
    const patientSelect = document.getElementById("patientName");
    const infoDiv = document.createElement('div');
    infoDiv.className = 'patient-info-display';
    
    infoDiv.innerHTML = `
      <i class="fas fa-user-circle" style="color: #4a90e2;"></i>
      <span><strong>Patient ID:</strong> ${selectedOption.dataset.patientId}</span>
      <span><strong>Age:</strong> ${selectedOption.dataset.age || 'N/A'}</span>
      <span><strong>Status:</strong> ${selectedOption.dataset.status || 'N/A'}</span>
    `;
    
    patientSelect.parentNode.insertBefore(infoDiv, patientSelect.nextSibling);
  }
}

// Real-time listener for appointments
function setupRealtimeListener() {
  if (!appointmentsRef) {
    console.error("Database reference not initialized");
    return;
  }

  appointmentsRef.on('value', (snapshot) => {
    appointments = [];
    const data = snapshot.val();
    
    if (data) {
      Object.keys(data).forEach(key => {
        const appointment = data[key];
        appointments.push({
          id: key,
          name: appointment.name,
          time: new Date(appointment.time),
          purpose: appointment.purpose,
          provider: appointment.provider,
          status: appointment.status,
          createdAt: appointment.createdAt ? new Date(appointment.createdAt) : new Date(),
          updatedAt: appointment.updatedAt ? new Date(appointment.updatedAt) : new Date()
        });
      });
    }
    
    appointments.sort((a, b) => b.createdAt - a.createdAt);
    console.log(`Loaded ${appointments.length} appointments from database`);
    updateAppointments();
    updateSyncStatus('synced');
    hideRefreshIndicator();
    
  }, (error) => {
    console.error("Error listening to appointments:", error);
    showNotification("Error loading appointments from database", "error");
    updateSyncStatus('error');
    initializeLocalStorage();
  });
}

// Fallback local storage implementation
function initializeLocalStorage() {
  console.log("Using localStorage as fallback");
  loadAppointmentsFromStorage();
}

function loadAppointmentsFromStorage() {
  const stored = localStorage.getItem('pregnacare_appointments');
  if (stored) {
    try {
      const parsed = JSON.parse(stored);
      appointments = parsed.map(app => ({
        ...app,
        time: new Date(app.time),
        createdAt: app.createdAt ? new Date(app.createdAt) : new Date(),
        updatedAt: app.updatedAt ? new Date(app.updatedAt) : new Date()
      }));
    } catch (error) {
      console.error("Error parsing stored appointments:", error);
      appointments = [];
    }
  } else {
    appointments = [];
  }
  updateAppointments();
}

function saveAppointmentsToStorage() {
  try {
    localStorage.setItem('pregnacare_appointments', JSON.stringify(appointments));
  } catch (error) {
    console.error("Error saving appointments to storage:", error);
  }
}

// Database operations
async function addAppointmentToDatabase(appointmentData) {
  showRefreshIndicator();
  updateSyncStatus('syncing');
  
  if (appointmentsRef) {
    try {
      const newAppointmentRef = appointmentsRef.push();
      const appointmentWithTimestamps = {
        ...appointmentData,
        time: appointmentData.time.toISOString(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      await newAppointmentRef.set(appointmentWithTimestamps);
      
      console.log("Appointment added with ID: ", newAppointmentRef.key);
      
      // Send notification for new appointment
      if (window.NotificationIntegration && window.NotificationIntegration.appointments) {
        window.NotificationIntegration.appointments.notifyAppointmentScheduled({
          id: newAppointmentRef.key,
          name: appointmentData.name,
          time: appointmentData.time,
          purpose: appointmentData.purpose,
          provider: appointmentData.provider
        });
      }
      
      showNotification("Appointment scheduled successfully!", "success", "appointments");
      updateSyncStatus('synced');
      return newAppointmentRef.key;
    } catch (error) {
      console.error("Error adding appointment:", error);
      showNotification("Error scheduling appointment", "error", "appointments");
      updateSyncStatus('error');
      throw error;
    }
  } else {
    const appointment = {
      ...appointmentData,
      id: Date.now().toString(),
      createdAt: new Date(),
      updatedAt: new Date()
    };
    appointments.push(appointment);
    saveAppointmentsToStorage();
    updateAppointments();
    showNotification("Appointment scheduled successfully!", "success", "appointments");
    return appointment.id;
  }
}

async function updateAppointmentInDatabase(id, updates) {
  showRefreshIndicator();
  updateSyncStatus('syncing');
  
  if (appointmentsRef) {
    try {
      const appointmentRef = appointmentsRef.child(id);
      const updateData = {
        ...updates,
        updatedAt: new Date().toISOString()
      };
      
      await appointmentRef.update(updateData);
      
      console.log("Appointment updated: ", id);
      showNotification("Appointment updated successfully!", "success", "appointments");
      updateSyncStatus('synced');
    } catch (error) {
      console.error("Error updating appointment:", error);
      showNotification("Error updating appointment", "error", "appointments");
      updateSyncStatus('error');
      throw error;
    }
  } else {
    const appointmentIndex = appointments.findIndex(app => app.id === id);
    if (appointmentIndex !== -1) {
      appointments[appointmentIndex] = {
        ...appointments[appointmentIndex],
        ...updates,
        updatedAt: new Date()
      };
      saveAppointmentsToStorage();
      updateAppointments();
      showNotification("Appointment updated successfully!", "success", "appointments");
    }
  }
}

async function deleteAppointmentFromDatabase(id) {
  showRefreshIndicator();
  updateSyncStatus('syncing');
  
  if (appointmentsRef) {
    try {
      await appointmentsRef.child(id).remove();
      console.log("Appointment deleted: ", id);
      showNotification("Appointment deleted successfully!", "success", "appointments");
      updateSyncStatus('synced');
    } catch (error) {
      console.error("Error deleting appointment:", error);
      showNotification("Error deleting appointment", "error", "appointments");
      updateSyncStatus('error');
      throw error;
    }
  } else {
    appointments = appointments.filter(app => app.id !== id);
    saveAppointmentsToStorage();
    updateAppointments();
    showNotification("Appointment deleted successfully!", "success", "appointments");
  }
}

// Auto-Hide Topbar Functionality
function initializeAutoHideTopbar() {
  const searchHeader = document.querySelector('.search-header');
  const mainContent = document.querySelector('.main');
  
  if (!searchHeader) return;
  
  window.addEventListener('scroll', function() {
    if (!autoHideEnabled) return;
    
    didScroll = true;
    
    if (scrollTimer) {
      clearTimeout(scrollTimer);
    }
    
    scrollTimer = setTimeout(function() {
      if (didScroll) {
        handleScroll();
        didScroll = false;
      }
    }, 100);
  });
  
  function handleScroll() {
    const currentScrollTop = window.pageYOffset || document.documentElement.scrollTop;
    
    if (Math.abs(lastScrollTop - currentScrollTop) <= scrollDelta) {
      return;
    }
    
    if (shouldDisableAutoHide()) {
      return;
    }
    
    if (currentScrollTop > lastScrollTop && currentScrollTop > navbarHeight) {
      hideTopbar();
    } else {
      if (currentScrollTop + window.innerHeight < document.documentElement.scrollHeight) {
        showTopbar();
      }
    }
    
    lastScrollTop = currentScrollTop;
  }
  
  function hideTopbar() {
    searchHeader.classList.add('header-hidden');
    searchHeader.classList.remove('header-visible');
    searchHeader.classList.add('scrolling-down');
    searchHeader.classList.remove('scrolling-up');
    
    if (mainContent) {
      mainContent.classList.add('header-hidden');
    }
  }
  
  function showTopbar() {
    searchHeader.classList.remove('header-hidden');
    searchHeader.classList.add('header-visible');
    searchHeader.classList.remove('scrolling-down');
    searchHeader.classList.add('scrolling-up');
    
    if (mainContent) {
      mainContent.classList.remove('header-hidden');
    }
  }
  
  function handleTopOfPage() {
    const currentScrollTop = window.pageYOffset || document.documentElement.scrollTop;
    
    if (currentScrollTop <= 0) {
      showTopbar();
    }
  }
  
  window.addEventListener('scroll', handleTopOfPage);
  
  // Touch event support for mobile
  let touchStartY = 0;
  let touchEndY = 0;
  
  document.addEventListener('touchstart', function(e) {
    touchStartY = e.changedTouches[0].screenY;
  });
  
  document.addEventListener('touchend', function(e) {
    touchEndY = e.changedTouches[0].screenY;
    handleTouchGesture();
  });
  
  function handleTouchGesture() {
    if (!autoHideEnabled) return;
    
    const currentScrollTop = window.pageYOffset || document.documentElement.scrollTop;
    
    if (touchEndY > touchStartY && currentScrollTop > navbarHeight) {
      showTopbar();
    } else if (touchEndY < touchStartY && currentScrollTop > navbarHeight) {
      hideTopbar();
    }
  }
}

// Enhanced scroll behavior
function initializeEnhancedScrollBehavior() {
  let scrollTimeout;
  
  window.addEventListener('scroll', function() {
    document.body.classList.add('is-scrolling');
    
    window.clearTimeout(scrollTimeout);
    
    scrollTimeout = setTimeout(function() {
      document.body.classList.remove('is-scrolling');
    }, 100);
  });
}

// Check if auto-hide should be disabled
function shouldDisableAutoHide() {
  const modal = document.getElementById('modal');
  if (modal && !modal.classList.contains('hidden')) {
    return true;
  }
  
  const openDropdowns = document.querySelectorAll('.dropdown.show');
  if (openDropdowns.length > 0) {
    return true;
  }
  
  if (window.innerHeight < 600) {
    return true;
  }
  
  return false;
}

// Respect user's motion preferences
function respectsReducedMotion() {
  return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

// Initialize auto-hide with preferences
function initializeAutoHideWithPreferences() {
  if (respectsReducedMotion()) {
    console.log('Auto-hide disabled due to user motion preferences');
    return;
  }
  
  initializeAutoHideTopbar();
  initializeEnhancedScrollBehavior();
}

// Manual toggle for auto-hide feature
function initializeManualToggle() {
  const toggleButton = document.getElementById('toggleAutoHide');
  
  if (toggleButton) {
    toggleButton.addEventListener('click', function() {
      autoHideEnabled = !autoHideEnabled;
      
      if (autoHideEnabled) {
        toggleButton.title = 'Disable auto-hide topbar';
        showNotification('Auto-hide enabled', 'info', 'appointments');
      } else {
        toggleButton.title = 'Enable auto-hide topbar';
        
        const searchHeader = document.querySelector('.search-header');
        const mainContent = document.querySelector('.main');
        if (searchHeader) {
          searchHeader.classList.remove('header-hidden', 'scrolling-down');
          searchHeader.classList.add('header-visible');
        }
        if (mainContent) {
          mainContent.classList.remove('header-hidden');
        }
        showNotification('Auto-hide disabled', 'info', 'appointments');
      }
    });
  }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
  initializeEventListeners();
  initializeFirebase();
  setDateTimeConstraints();
  initializeAutoHideWithPreferences();
  initializeManualToggle();
  initializeDropdowns();
});

// Event Listeners
function initializeEventListeners() {
  if (openModalBtn) openModalBtn.addEventListener("click", openModal);
  if (closeModalBtn) closeModalBtn.addEventListener("click", closeModal);
  if (form) form.addEventListener("submit", handleFormSubmission);
  if (tableSearch) tableSearch.addEventListener("input", handleTableSearch);
  if (searchBar) searchBar.addEventListener("input", handleGlobalSearch);
  
  const patientSelect = document.getElementById("patientName");
  if (patientSelect) {
    patientSelect.addEventListener("change", handlePatientSelection);
  }
  
  window.addEventListener("keydown", handleKeyPress);
  window.addEventListener("click", handleWindowClick);
}

// Initialize dropdowns
function initializeDropdowns() {
  const notifIcon = document.getElementById('notifIcon');
  const helpIcon = document.getElementById('helpIcon');
  const notifDropdown = document.getElementById('notifDropdown');
  const helpDropdown = document.getElementById('helpDropdown');

  if (notifIcon && notifDropdown) {
    notifIcon.addEventListener('click', function(e) {
      e.stopPropagation();
      notifDropdown.classList.toggle('show');
      if (helpDropdown) helpDropdown.classList.remove('show');
    });
  }

  if (helpIcon && helpDropdown) {
    helpIcon.addEventListener('click', function(e) {
      e.stopPropagation();
      helpDropdown.classList.toggle('show');
      if (notifDropdown) notifDropdown.classList.remove('show');
    });
  }

  document.addEventListener('click', function() {
    if (notifDropdown) notifDropdown.classList.remove('show');
    if (helpDropdown) helpDropdown.classList.remove('show');
  });
}

// Date and Time Validation
function validateAppointmentDateTime(appointmentDate, existingAppointmentId = null, patientName = '') {
  const now = new Date();
  const currentDateTime = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours(), now.getMinutes());
  
  // Ensure we have a valid date object
  if (isNaN(appointmentDate.getTime())) {
    return "Please enter a valid date and time.";
  }
  
  if (appointmentDate < currentDateTime) {
    return "Cannot schedule appointments in the past. Please select a future date and time.";
  }
  
  const oneYearFromNow = new Date();
  oneYearFromNow.setFullYear(oneYearFromNow.getFullYear() + 1);
  if (appointmentDate > oneYearFromNow) {
    return "Cannot schedule appointments more than 1 year in advance.";
  }
  
  const hours = appointmentDate.getHours();
  if (hours < 8 || hours >= 18) {
    return "Appointments must be scheduled between 8:00 AM and 6:00 PM.";
  }
  
  const dayOfWeek = appointmentDate.getDay();
  if (dayOfWeek === 0 || dayOfWeek === 6) {
    const dayName = dayOfWeek === 0 ? 'Sunday' : 'Saturday';
    return `Appointments cannot be scheduled on ${dayName}. Please select a weekday.`;
  }
  
  // Check for conflicts (existing function)
  const conflictingAppointment = checkForConflicts(appointmentDate, existingAppointmentId, patientName);
  if (conflictingAppointment) {
    return conflictingAppointment;
  }
  
  const twoHoursFromNow = new Date();
  twoHoursFromNow.setHours(twoHoursFromNow.getHours() + 2);
  if (appointmentDate < twoHoursFromNow) {
    return "Appointments must be scheduled at least 2 hours in advance.";
  }
  
  return null;
}

// Check for scheduling conflicts
function checkForConflicts(appointmentDate, existingAppointmentId = null, patientName = '') {
  const APPOINTMENT_DURATION = 30;
  
  const appointmentStart = new Date(appointmentDate);
  const appointmentEnd = new Date(appointmentDate);
  appointmentEnd.setMinutes(appointmentEnd.getMinutes() + APPOINTMENT_DURATION);
  
  const conflicts = appointments.filter(app => {
    if (existingAppointmentId && app.id === existingAppointmentId) {
      return false;
    }
    
    const existingStart = new Date(app.time);
    const existingEnd = new Date(app.time);
    existingEnd.setMinutes(existingEnd.getMinutes() + APPOINTMENT_DURATION);
    
    const hasOverlap = (appointmentStart < existingEnd) && (appointmentEnd > existingStart);
    
    return hasOverlap;
  });
  
  if (conflicts.length > 0) {
    const conflictDetails = conflicts.map(app => 
      `${app.name} at ${app.time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
    ).join(', ');
    
    return `Time slot conflicts with existing appointment(s): ${conflictDetails}. Please choose a different time.`;
  }
  
  if (patientName) {
    const sameDay = appointments.filter(app => {
      if (existingAppointmentId && app.id === existingAppointmentId) {
        return false;
      }
      return app.name === patientName && 
             app.time.toDateString() === appointmentDate.toDateString();
    });
    
    if (sameDay.length > 0) {
      return `${patientName} already has an appointment scheduled on ${appointmentDate.toLocaleDateString()}. Are you sure you want to schedule another?`;
    }
  }
  
  return null;
}

// Format date for datetime-local input
function formatDateForInput(date) {
  const d = new Date(date);
  
  // Ensure we have a valid date
  if (isNaN(d.getTime())) {
    console.error("Invalid date passed to formatDateForInput:", date);
    return '';
  }
  
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  const hours = String(d.getHours()).padStart(2, '0');
  const minutes = String(d.getMinutes()).padStart(2, '0');
  
  return `${year}-${month}-${day}T${hours}:${minutes}`;
}

// Set date/time constraints
function setDateTimeConstraints() {
  const appointmentTimeInput = document.getElementById("appointmentTime");
  if (!appointmentTimeInput) return;
  
  const now = new Date();
  now.setMinutes(now.getMinutes() + 120);
  appointmentTimeInput.min = formatDateForInput(now);
  
  const maxDate = new Date();
  maxDate.setFullYear(maxDate.getFullYear() + 1);
  appointmentTimeInput.max = formatDateForInput(maxDate);
  
  appointmentTimeInput.step = 60;
}

// Modal Functions
function openModal() {
  if (modal) {
    modal.classList.remove("hidden");
    const patientNameField = document.getElementById("patientName");
    if (patientNameField) patientNameField.focus();
    
    setDateTimeConstraints();
    setDefaultAppointmentTime();
  }
}

function setDefaultAppointmentTime() {
  const appointmentTimeInput = document.getElementById("appointmentTime");
  if (!appointmentTimeInput) return;
  
  const now = new Date();
  now.setHours(now.getHours() + 2);
  
  const minutes = now.getMinutes();
  now.setMinutes(minutes);
  now.setSeconds(0);
  now.setMilliseconds(0);
  
  // Business hours validation
  if (now.getHours() >= 18) {
    now.setDate(now.getDate() + 1);
    now.setHours(8, 0, 0, 0);
  } else if (now.getHours() < 8) {
    now.setHours(8, 0, 0, 0);
  }
  
  // Weekend validation
  while (now.getDay() === 0 || now.getDay() === 6) {
    now.setDate(now.getDate() + 1);
  }
  
  appointmentTimeInput.value = formatDateForInput(now);
}

function closeModal() {
  if (modal) {
    modal.classList.add("hidden");
    if (form) form.reset();
    
    const existingInfo = document.querySelector('.patient-info-display');
    if (existingInfo) {
      existingInfo.remove();
    }
  }
}

// Event Handlers
function handleKeyPress(e) {
  if (e.key === "Escape") closeModal();
}

function handleWindowClick(e) {
  if (e.target === modal) closeModal();
}

async function handleFormSubmission(e) {
  e.preventDefault();
  
  const name = document.getElementById("patientName")?.value.trim();
  const timeValue = document.getElementById("appointmentTime")?.value;
  const purpose = document.getElementById("purpose")?.value.trim();
  const provider = document.getElementById("provider")?.value.trim();
  const status = document.getElementById("status")?.value;

  if (!name || !timeValue || !purpose || !provider) {
    alert("Please fill in all required fields.");
    return;
  }

  const appointmentDateTime = new Date(timeValue);
  
  // Check if date is valid
  if (isNaN(appointmentDateTime.getTime())) {
    showNotification("Please enter a valid date and time.", "error", "appointments");
    return;
  }

  const validationError = validateAppointmentDateTime(appointmentDateTime, null, name);
  
  if (validationError) {
    showNotification(validationError, "error", "appointments");
    return;
  }

  const appointmentData = {
    name,
    time: appointmentDateTime,
    purpose,
    provider,
    status
  };

  try {
    const submitBtn = form.querySelector('button[type="submit"]');
    if (submitBtn) {
      submitBtn.classList.add('loading');
      submitBtn.disabled = true;

      await addAppointmentToDatabase(appointmentData);
      closeModal();
      
      submitBtn.classList.remove('loading');
      submitBtn.disabled = false;
    }
  } catch (error) {
    console.error("Error scheduling appointment:", error);
    const submitBtn = form.querySelector('button[type="submit"]');
    if (submitBtn) {
      submitBtn.classList.remove('loading');
      submitBtn.disabled = false;
    }
  }
}

function handleTableSearch(e) {
  const searchTerm = e.target.value.toLowerCase();
  filteredAppointments = appointments.filter(app => 
    app.name.toLowerCase().includes(searchTerm) ||
    app.purpose.toLowerCase().includes(searchTerm) ||
    app.provider.toLowerCase().includes(searchTerm) ||
    app.status.toLowerCase().includes(searchTerm)
  );
  updateTable();
}

function handleGlobalSearch(e) {
  const searchTerm = e.target.value.toLowerCase();
  if (searchTerm === '') {
    filteredAppointments = [...appointments];
  } else {
    filteredAppointments = appointments.filter(app => 
      app.name.toLowerCase().includes(searchTerm) ||
      app.purpose.toLowerCase().includes(searchTerm) ||
      app.provider.toLowerCase().includes(searchTerm)
    );
  }
  updateTable();
  updateCards();
}

// Main Update Functions
function updateAppointments() {
  filteredAppointments = [...appointments];
  updateStats();
  updateCards();
  updateTable();
}

function updateStats() {
  const today = new Date().toDateString();
  const todayApps = appointments.filter(app => app.time.toDateString() === today);
  const pendingApps = appointments.filter(app => app.status === "Pending");
  const completedApps = appointments.filter(app => 
    app.status === "Completed" && app.time.toDateString() === today
  );

  const todayCountEl = document.getElementById("todayCount");
  const totalCountEl = document.getElementById("totalCount");
  const pendingCountEl = document.getElementById("pendingCount");
  const completedCountEl = document.getElementById("completedCount");

  if (todayCountEl) {
    animateCounterUpdate(todayCountEl, parseInt(todayCountEl.textContent) || 0, todayApps.length);
  }
  if (totalCountEl) {
    animateCounterUpdate(totalCountEl, parseInt(totalCountEl.textContent) || 0, appointments.length);
  }
  if (pendingCountEl) {
    animateCounterUpdate(pendingCountEl, parseInt(pendingCountEl.textContent) || 0, pendingApps.length);
  }
  if (completedCountEl) {
    animateCounterUpdate(completedCountEl, parseInt(completedCountEl.textContent) || 0, completedApps.length);
  }
}

function animateCounterUpdate(element, fromValue, toValue) {
  const duration = 500;
  const startTime = performance.now();
  
  function updateCounter(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    
    const currentValue = Math.round(fromValue + (toValue - fromValue) * progress);
    element.textContent = currentValue;
    
    if (progress < 1) {
      requestAnimationFrame(updateCounter);
    }
  }
  
  requestAnimationFrame(updateCounter);
}

function updateCards() {
  if (!appointmentCards) return;
  
  appointmentCards.innerHTML = "";
  const today = new Date().toDateString();
  const todayAppointments = filteredAppointments
    .filter(app => app.time.toDateString() === today)
    .sort((a, b) => a.time - b.time);

  if (todayAppointments.length === 0) {
    appointmentCards.innerHTML = `
      <div class="cards-empty-state">
        <i class="fas fa-calendar-xmark"></i>
        <div class="message">No appointments scheduled for today</div>
        <div class="submessage">All appointments will appear here</div>
      </div>
    `;
    return;
  }

  todayAppointments.forEach(app => {
    const card = document.createElement("div");
    card.className = "card new-data";
    card.innerHTML = `
      <h4>${app.time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</h4>
      <p><strong>${app.name}</strong></p>
      <p>${app.purpose}</p>
      <p style="font-size: 12px; margin-top: 4px; color: var(--gray-text);">${app.provider}</p>
      <span class="status status-${app.status.toLowerCase().replace(/\s+/g, '-')}">${app.status}</span>
    `;
    appointmentCards.appendChild(card);
  });
}

function updateTable() {
  if (!appointmentsBody) return;
  
  appointmentsBody.innerHTML = "";

  if (filteredAppointments.length === 0) {
    appointmentsBody.innerHTML = `
      <tr>
        <td colspan="6" class="no-data">
          <i class="fas fa-search"></i>
          <div class="message">No appointments found</div>
          <div class="submessage">Try adjusting your search terms</div>
        </td>
      </tr>
    `;
    return;
  }

  const sortedAppointments = [...filteredAppointments].sort((a, b) => a.time - b.time);

  sortedAppointments.forEach(app => {
    const dateTimeStr = `${app.time.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    })} ${app.time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

    const row = document.createElement("tr");
    row.className = "new-data";
    row.innerHTML = `
      <td><strong>${app.name}</strong></td>
      <td>${dateTimeStr}</td>
      <td>${app.purpose}</td>
      <td>${app.provider}</td>
      <td><span class="status status-${app.status.toLowerCase().replace(/\s+/g, '-')}">${app.status}</span></td>
      <td>
        <button onclick="deleteAppointment('${app.id}')" 
                class="btn-danger"
                style="margin-right: 4px;"
                title="Delete appointment">
          <i>Delete</i>
        </button>
        <button onclick="editStatus('${app.id}')" 
                class="btn-info"
                title="Edit status">
          <i>Edit</i>
        </button>
        <button onclick="editAppointmentDateTime('${app.id}')" 
                class="btn-warning"
                style="margin-left: 4px;"
                title="Reschedule appointment">
          <i>Reschedule</i>
        </button>
      </td>
    `;
    appointmentsBody.appendChild(row);
  });
}

// Appointment Management Functions
async function deleteAppointment(id) {
  if (confirm("Are you sure you want to delete this appointment?")) {
    try {
      await deleteAppointmentFromDatabase(id);
    } catch (error) {
      console.error("Error deleting appointment:", error);
    }
  }
}

async function editStatus(id) {
  const appointment = appointments.find(app => app.id === id);
  if (!appointment) {
    showNotification("Appointment not found", "error", "appointments");
    return;
  }

  const statusOptions = ['Pending', 'Completed', 'Cancelled', 'No Show'];
  const currentIndex = statusOptions.indexOf(appointment.status);
  
  const newStatus = prompt(
    `Current status: ${appointment.status}\n\nSelect New Status:\n` +
    statusOptions.map((status, index) => `${index + 1}. ${status}${index === currentIndex ? ' (current)' : ''}`).join('\n') +
    '\n\nEnter number (1-4):'
  );

  if (newStatus === null) return;

  const statusIndex = parseInt(newStatus) - 1;
  if (statusIndex >= 0 && statusIndex < statusOptions.length) {
    if (statusOptions[statusIndex] === appointment.status) {
      showNotification("Status unchanged", "info", "appointments");
      return;
    }
    
    try {
      await updateAppointmentInDatabase(id, { status: statusOptions[statusIndex] });
    } catch (error) {
      console.error("Error updating appointment status:", error);
    }
  } else {
    showNotification("Invalid selection", "error", "appointments");
  }
}

async function editAppointmentDateTime(id) {
  const appointment = appointments.find(app => app.id === id);
  if (!appointment) {
    showNotification("Appointment not found", "error", "appointments");
    return;
  }

  const currentDateTime = formatDateForInput(appointment.time);
  const newDateTime = prompt(
    `Current appointment: ${appointment.time.toLocaleString()}\n\n` +
    `Enter new date and time (Year-Month-Day Hour:Minute):`,
    currentDateTime
  );

  if (newDateTime === null) return;

  const newDate = new Date(newDateTime);
  if (isNaN(newDate.getTime())) {
    showNotification("Please use Year-Month-Day Hour:Minute format.", "error", "appointments");
    return;
  }

  const validationError = validateAppointmentDateTime(newDate, id, appointment.name);
  
  if (validationError) {
    showNotification(validationError, "error", "appointments");
    return;
  }

  try {
    await updateAppointmentInDatabase(id, { time: newDate });
    showNotification("Appointment rescheduled successfully!", "success", "appointments");
  } catch (error) {
    console.error("Error updating appointment date/time:", error);
    showNotification("Failed to reschedule appointment", "error", "appointments");
  }
}

function removeStepValidation() {
  const appointmentTimeInput = document.getElementById("appointmentTime");
  if (appointmentTimeInput) {
    appointmentTimeInput.removeAttribute('step');
  }
}

// Updated notification function to use unified system
function showNotification(message, type = "info", category = "appointments") {
  // Use unified notification system if available
  if (window.showNotification) {
    window.showNotification(message, type, category);
  } else {
    // Fallback to old notification system
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notif => notif.remove());

    const notification = document.createElement("div");
    notification.className = `notification ${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
      notification.style.animation = "slideOut 0.3s ease forwards";
      setTimeout(() => {
        if (notification.parentNode) {
          notification.parentNode.removeChild(notification);
        }
      }, 300);
    }, 4000);
  }
}

// Connection status monitoring
function monitorConnection() {
  if (database) {
    const connectedRef = database.ref(".info/connected");
    connectedRef.on("value", (snap) => {
      if (snap.val() === true) {
        console.log("Connected to Firebase");
        updateConnectionStatus("connected");
        hideFirebaseError();
      } else {
        console.log("Disconnected from Firebase");
        updateConnectionStatus("disconnected");
        showFirebaseError("Connection to database lost");
      }
    });
  }
}

function updateConnectionStatus(status) {
  const statusElement = document.getElementById('firebaseStatus');
  if (statusElement) {
    statusElement.className = `firebase-status ${status}`;
    
    const indicator = statusElement.querySelector('.status-indicator');
    const text = statusElement.querySelector('span');
    
    switch(status) {
      case 'connected':
        if (text) text.textContent = 'Connected';
        break;
      case 'connecting':
        if (text) text.textContent = 'Connecting...';
        break;
      case 'disconnected':
        if (text) text.textContent = 'Disconnected';
        break;
    }
  }
  
  console.log(`Connection status: ${status}`);
}

function showFirebaseError(message) {
  const errorBanner = document.getElementById('firebaseErrorBanner');
  if (errorBanner) {
    errorBanner.querySelector('span').textContent = message;
    errorBanner.classList.add('show');
  }
}

function hideFirebaseError() {
  const errorBanner = document.getElementById('firebaseErrorBanner');
  if (errorBanner) {
    errorBanner.classList.remove('show');
  }
}

function closeErrorBanner() {
  hideFirebaseError();
}

function updateSyncStatus(status) {
  const syncElements = document.querySelectorAll('.sync-status');
  
  syncElements.forEach(element => {
    element.className = `sync-status ${status}`;
    
    const icon = element.querySelector('i');
    const text = element.lastChild;
    
    switch(status) {
      case 'synced':
        if (icon) icon.className = 'fas fa-check';
        if (text) text.textContent = ' Synced';
        break;
      case 'syncing':
        if (icon) icon.className = 'fas fa-sync';
        if (text) text.textContent = ' Syncing...';
        break;
      case 'error':
        if (icon) icon.className = 'fas fa-exclamation-triangle';
        if (text) text.textContent = ' Error';
        break;
    }
  });
}

function showRefreshIndicator() {
  const indicator = document.getElementById('refreshIndicator');
  if (indicator) {
    indicator.classList.add('show');
  }
}

function hideRefreshIndicator() {
  const indicator = document.getElementById('refreshIndicator');
  if (indicator) {
    indicator.classList.remove('show');
  }
}

// Cleanup on page unload
window.addEventListener('beforeunload', function() {
  if (appointmentsRef) {
    appointmentsRef.off();
  }
  if (patientsRef) {
    patientsRef.off();
  }
});

// Export functions for global access
window.deleteAppointment = deleteAppointment;
window.editStatus = editStatus;
window.editAppointmentDateTime = editAppointmentDateTime;
window.closeErrorBanner = closeErrorBanner;
window.handlePatientSelection = handlePatientSelection;