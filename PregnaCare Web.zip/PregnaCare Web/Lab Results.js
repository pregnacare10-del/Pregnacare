// PregnaCare Lab Results System - Firebase Integration with Unified Notifications
// Author: Claude AI Assistant
// Date: January 2025

// Firebase Configuration
const firebaseConfig = {
    apiKey: "AIzaSyBGPYM5JHrSXOd9PWbQ4TzoqUtlf5qCwjs",
    authDomain: "pregnacare-web.firebaseapp.com",
    databaseURL: "https://pregnacare-web-default-rtdb.firebaseio.com",
    projectId: "pregnacare-web",
    storageBucket: "pregnacare-web.firebasestorage.app",
    messagingSenderId: "408625794290",
    appId: "1:408625794290:web:bb131c8b35869b31acd46b",
    measurementId: "G-HZB017TYX3"
};

// Initialize Firebase (assuming Firebase is loaded via CDN)
let database;
let labResultsRef;
let patientsRef;
let currentUser = { uid: 'lab-system', displayName: 'Lab Results System' };

// Global variables
let currentPage = 1;
let recordsPerPage = 8;
let filteredResults = [];
let allResults = [];
let allPatients = {}; // Store all patients data

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeFirebase();
    initializeApp();
    setupEventListeners();
});

// Initialize Firebase
async function initializeFirebase() {
    try {
        // Initialize Firebase
        firebase.initializeApp(firebaseConfig);
        database = firebase.database();
        labResultsRef = database.ref('labResults');
        patientsRef = database.ref('patients'); // Initialize patients reference
        
        console.log('Firebase initialized successfully');
        
        // Initialize notification system
        await initializeNotificationSystem();
        
        setupRealtimeListeners();
        loadPatients(); // Load patients data
        loadLabResults();
        
        // Start monitoring for abnormal results
        startAbnormalResultsMonitoring();
        
    } catch (error) {
        console.error('Firebase initialization error:', error);
        // Fallback to local storage if Firebase fails
        initializeLocalStorage();
    }
}

// Initialize Notification System
async function initializeNotificationSystem() {
    if (database && window.notificationSystem) {
        try {
            await window.notificationSystem.initialize(database, currentUser);
            console.log('✅ Notification system initialized for Lab Results');
        } catch (error) {
            console.error('Failed to initialize notification system:', error);
        }
    }
}

// Start monitoring for abnormal results
function startAbnormalResultsMonitoring() {
    // Check for abnormal results every 15 minutes
    setInterval(() => {
        checkForCriticalResults();
    }, 15 * 60 * 1000);
    
    // Initial check after 5 seconds
    setTimeout(() => {
        checkForCriticalResults();
    }, 5000);
}

// Check for critical/abnormal results that need attention
function checkForCriticalResults() {
    const criticalResults = allResults.filter(result => 
        result.status === 'abnormal' && !result.acknowledged
    );
    
    criticalResults.forEach(result => {
        // Check if we've already notified about this result
        const notificationKey = `lab_critical_${result.id}`;
        if (!hasRecentNotification(notificationKey)) {
            // Send urgent notification
            if (window.NotificationIntegration && window.NotificationIntegration.labResults) {
                window.NotificationIntegration.labResults.notifyAbnormalResult(result);
            }
            
            // If it's a critical drug level, trigger medication review
            if (result.test && result.test.toLowerCase().includes('drug level')) {
                triggerMedicationReview(result);
            }
            
            markNotificationSent(notificationKey);
        }
    });
}

// Trigger cross-module medication review
function triggerMedicationReview(labResult) {
    if (window.notificationSystem) {
        window.notificationSystem.createNotification({
            title: 'Medication Review Required',
            message: `Abnormal drug levels detected for ${labResult.patientName}. Please review current medications immediately.`,
            type: 'warning',
            category: 'medications',
            priority: 'urgent',
            metadata: {
                patientId: labResult.patientId,
                labResultId: labResult.id,
                testType: labResult.test,
                triggerModule: 'lab-results'
            },
            actionUrl: 'Medications.html',
            actionText: 'Review Medications Now'
        });
    }
}

// Check if notification was recently sent
function hasRecentNotification(key) {
    const sent = localStorage.getItem(`notif_sent_${key}`);
    if (!sent) return false;
    
    const sentTime = parseInt(sent);
    const hoursSince = (Date.now() - sentTime) / (1000 * 60 * 60);
    
    // Don't send same notification within 24 hours
    return hoursSince < 24;
}

// Mark notification as sent
function markNotificationSent(key) {
    localStorage.setItem(`notif_sent_${key}`, Date.now().toString());
}

// Load patients from Firebase
async function loadPatients() {
    console.log('📚 Loading patients from Firebase...');
    
    try {
        patientsRef.on('value', (snapshot) => {
            console.log('👥 Patients data received. Exists:', snapshot.exists());
            
            if (snapshot.exists()) {
                const data = snapshot.val();
                allPatients = Object.entries(data).map(([key, value]) => ({
                    key: key,
                    id: value.patientId,
                    fullName: value.fullName,
                    firstName: value.firstName,
                    lastName: value.lastName,
                    middleName: value.middleName,
                    age: value.age,
                    status: value.status,
                    birthdate: value.birthdate,
                    dueDate: value.dueDate,
                    ...value
                }));
                
                // Sort patients by patient ID for dropdown
                allPatients.sort((a, b) => {
                    const aNum = parseInt(a.id.replace('PT', ''));
                    const bNum = parseInt(b.id.replace('PT', ''));
                    return aNum - bNum;
                });
                
                console.log(`✅ Loaded ${allPatients.length} patients`);
            } else {
                allPatients = [];
                console.log('📭 No patients found in database');
            }
            
            populatePatientDropdown();
            
        }, (error) => {
            console.error('❌ Firebase patients database error:', error);
            allPatients = [];
            populatePatientDropdown();
        });
    } catch (error) {
        console.error('❌ Error setting up patients Firebase listener:', error);
        allPatients = [];
    }
}

// Update patient dropdown
function updatePatientDropdown() {
    const patientSelect = document.getElementById('patientSelect');
    if (!patientSelect) return;
    
    // Clear existing options
    patientSelect.innerHTML = '<option value="">Select a patient...</option>';
    
    if (allPatients.length === 0) {
        const noPatientOption = document.createElement('option');
        noPatientOption.value = '';
        noPatientOption.textContent = 'No patients available - Add patients first';
        noPatientOption.disabled = true;
        patientSelect.appendChild(noPatientOption);
        return;
    }

    // Add patients to dropdown
    allPatients.forEach(patient => {
        if (patient.id) {
            const option = document.createElement('option');
            option.value = patient.id;
            option.textContent = patient.id;
            option.dataset.fullName = patient.fullName || 'Unknown';
            option.dataset.patientKey = patient.key;
            option.dataset.age = patient.age || 'N/A';
            option.dataset.status = patient.status || 'Unknown';
            
            patientSelect.appendChild(option);
        }
    });
}

// Fallback to local storage if Firebase is not available
function initializeLocalStorage() {
    console.log('Using localStorage as fallback');
    loadFromLocalStorage();
}

// Setup realtime listeners
function setupRealtimeListeners() {
    if (!labResultsRef) return;
    
    // Listen for data changes
    labResultsRef.on('value', (snapshot) => {
        const data = snapshot.val();
        allResults = [];
        
        if (data) {
            Object.keys(data).forEach(key => {
                allResults.push({
                    id: key,
                    ...data[key]
                });
            });
        }
        
        filteredResults = [...allResults];
        renderTable();
        updatePagination();
        updateAbnormalCount();
    });
    
    // Listen for individual changes for better performance
    labResultsRef.on('child_added', (snapshot) => {
        console.log('New lab result added:', snapshot.key);
        
        // Send notification for new result
        const result = snapshot.val();
        if (result && window.NotificationIntegration && window.NotificationIntegration.labResults) {
            window.NotificationIntegration.labResults.notifyNewLabResult({
                id: snapshot.key,
                ...result
            });
            
            // Special notification for abnormal results
            if (result.status === 'abnormal') {
                window.NotificationIntegration.labResults.notifyAbnormalResult({
                    id: snapshot.key,
                    ...result
                });
            }
        }
    });
    
    labResultsRef.on('child_changed', (snapshot) => {
        console.log('Lab result updated:', snapshot.key);
        
        // Check if status changed to abnormal
        const updatedResult = snapshot.val();
        if (updatedResult && updatedResult.status === 'abnormal') {
            const notificationKey = `lab_status_change_${snapshot.key}`;
            if (!hasRecentNotification(notificationKey)) {
                if (window.NotificationIntegration && window.NotificationIntegration.labResults) {
                    window.NotificationIntegration.labResults.notifyAbnormalResult({
                        id: snapshot.key,
                        ...updatedResult
                    });
                }
                markNotificationSent(notificationKey);
            }
        }
    });
    
    labResultsRef.on('child_removed', (snapshot) => {
        console.log('Lab result removed:', snapshot.key);
    });
}

// Initialize application
function initializeApp() {
    console.log('PregnaCare Lab Results System Initialized');
    // Clear existing table data
    clearTableData();
}

// Clear existing hardcoded table data
function clearTableData() {
    const tableBody = document.getElementById('labTableBody');
    if (tableBody) {
        tableBody.innerHTML = '';
    }
}

// Load lab results from database
function loadLabResults() {
    if (labResultsRef) {
        // Firebase will handle this through the realtime listener
        return;
    } else {
        // Fallback to local storage
        loadFromLocalStorage();
    }
}

// Load from local storage (fallback)
function loadFromLocalStorage() {
    const stored = localStorage.getItem('labResults');
    if (stored) {
        allResults = JSON.parse(stored);
    } else {
        // Initialize with empty array or sample data
        allResults = [];
        saveToLocalStorage();
    }
    
    // Also load patients from local storage
    const storedPatients = localStorage.getItem('patients');
    if (storedPatients) {
        allPatients = JSON.parse(storedPatients);
    }
    
    filteredResults = [...allResults];
    renderTable();
    updatePagination();
    updateAbnormalCount();
}

// Save to local storage (fallback)
function saveToLocalStorage() {
    localStorage.setItem('labResults', JSON.stringify(allResults));
}

// Render table with current data
function renderTable() {
    const tableBody = document.getElementById('labTableBody');
    if (!tableBody) return;
    
    // Clear existing rows
    tableBody.innerHTML = '';
    
    // Calculate pagination
    const startIndex = (currentPage - 1) * recordsPerPage;
    const endIndex = startIndex + recordsPerPage;
    const pageResults = filteredResults.slice(startIndex, endIndex);
    
    // Render rows
    pageResults.forEach(result => {
        const row = createTableRow(result);
        tableBody.appendChild(row);
    });
    
    // Show "No results" message if empty
    if (filteredResults.length === 0) {
        const emptyRow = document.createElement('tr');
        emptyRow.innerHTML = `
            <td colspan="6" style="text-align: center; padding: 40px; color: #666;">
                <i class="fas fa-flask" style="font-size: 48px; margin-bottom: 10px; opacity: 0.3;"></i>
                <br>No lab results found
                <br><small>Add a new lab result to get started</small>
            </td>
        `;
        tableBody.appendChild(emptyRow);
    }
}

// Create table row element
function createTableRow(result) {
    const row = document.createElement('tr');
    row.dataset.resultId = result.id;
    
    // Generate initials
    const initials = result.patientName
        ? result.patientName.split(' ').map(name => name.charAt(0)).join('').toUpperCase()
        : 'N/A';
    
    row.innerHTML = `
        <td>
            <div class="patient-info">
                <div class="patient-details">
                    <span class="patient-name">${result.patientName || 'Unknown'}</span>
                    <span class="patient-id">ID: ${result.patientId || 'N/A'}</span>
                </div>
            </div>
        </td>
        <td>${result.test || 'N/A'}</td>
        <td><span class="status ${(result.status || 'pending').toLowerCase()}">${result.status || 'Pending'}</span></td>
        <td>
            <div class="results-value ${(result.status || 'pending').toLowerCase()}">
                ${result.results || 'Results pending...'}
                ${result.notes ? `<br><small>${result.notes}</small>` : ''}
            </div>
        </td>
        <td>${result.date || 'N/A'}</td>
        <td>
            <div class="actions">
                <button class="btn view" onclick="viewResult('${result.id}')">View</button>
                <button class="btn edit" onclick="editResult('${result.id}')">Edit</button>
                <button class="btn delete" onclick="deleteResult('${result.id}')">Delete</button>
            </div>
        </td>
    `;
    
    return row;
}

// Add new lab result to database
async function addLabResult(resultData) {
    const newResult = {
        patientName: resultData.patientName,
        patientId: resultData.patientId,
        test: resultData.test,
        status: resultData.status,
        results: resultData.results,
        notes: resultData.notes || '',
        date: resultData.date,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        acknowledged: false // For tracking if abnormal results have been reviewed
    };
    
    if (labResultsRef) {
        // Add to Firebase
        labResultsRef.push(newResult)
            .then(() => {
                showMessage('Lab result added successfully!', 'success');
                closeModal('addLabModal');
            })
            .catch((error) => {
                console.error('Error adding lab result:', error);
                showMessage('Error adding lab result. Please try again.', 'error');
            });
    } else {
        // Fallback to local storage
        newResult.id = Date.now().toString();
        allResults.push(newResult);
        saveToLocalStorage();
        loadFromLocalStorage();
        showMessage('Lab result added successfully!', 'success');
        closeModal('addLabModal');
    }
}

// Update existing lab result
async function updateLabResult(id, resultData) {
    const updatedResult = {
        ...resultData,
        updatedAt: new Date().toISOString()
    };
    
    if (labResultsRef) {
        // Update in Firebase
        labResultsRef.child(id).update(updatedResult)
            .then(() => {
                showMessage('Lab result updated successfully!', 'success');
                closeModal('resultModal');
            })
            .catch((error) => {
                console.error('Error updating lab result:', error);
                showMessage('Error updating lab result. Please try again.', 'error');
            });
    } else {
        // Fallback to local storage
        const index = allResults.findIndex(result => result.id === id);
        if (index !== -1) {
            allResults[index] = { ...allResults[index], ...updatedResult };
            saveToLocalStorage();
            loadFromLocalStorage();
            showMessage('Lab result updated successfully!', 'success');
            closeModal('resultModal');
        }
    }
}

// Delete lab result from database
async function deleteLabResult(id) {
    if (!confirm('Are you sure you want to delete this lab result? This action cannot be undone.')) {
        return;
    }
    
    if (labResultsRef) {
        // Delete from Firebase
        labResultsRef.child(id).remove()
            .then(() => {
                showMessage('Lab result deleted successfully!', 'success');
            })
            .catch((error) => {
                console.error('Error deleting lab result:', error);
                showMessage('Error deleting lab result. Please try again.', 'error');
            });
    } else {
        // Fallback to local storage
        allResults = allResults.filter(result => result.id !== id);
        saveToLocalStorage();
        loadFromLocalStorage();
        showMessage('Lab result deleted successfully!', 'success');
    }
}

// Setup event listeners - Fixed for icons
function setupEventListeners() {
    // Search functionality
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', handleSearch);
    }

    // Add lab result button
    const addLabBtn = document.getElementById('addLabBtn');
    if (addLabBtn) {
        addLabBtn.addEventListener('click', showAddLabModal);
    }

    // View abnormal results button
    const viewAbnormalBtn = document.getElementById('viewAbnormalBtn');
    if (viewAbnormalBtn) {
        viewAbnormalBtn.addEventListener('click', showAbnormalResults);
    }

    // Icon button event listeners
    const messageIcon = document.getElementById('messageIcon');
    const notifIcon = document.getElementById('notifIcon');
    const helpIcon = document.getElementById('helpIcon');

    if (messageIcon) {
        messageIcon.addEventListener('click', function(e) {
            e.stopPropagation();
            toggleDropdown('messageDropdown');
        });
    }

    if (notifIcon) {
        notifIcon.addEventListener('click', function(e) {
            e.stopPropagation();
            toggleDropdown('notifDropdown');
        });
    }

    if (helpIcon) {
        helpIcon.addEventListener('click', function(e) {
            e.stopPropagation();
            toggleDropdown('helpDropdown');
        });
    }

    // Close dropdowns when clicking outside
    document.addEventListener('click', function() {
        closeAllDropdowns();
    });

    // Prevent dropdown from closing when clicking inside
    document.querySelectorAll('.dropdown').forEach(dropdown => {
        dropdown.addEventListener('click', function(e) {
            e.stopPropagation();
        });
    });

    // Modal close functionality
    setupModalEvents();
}

// Handle search functionality
function handleSearch(e) {
    const searchTerm = e.target.value.toLowerCase();
    
    if (searchTerm === '') {
        filteredResults = [...allResults];
    } else {
        filteredResults = allResults.filter(result => 
            (result.patientName && result.patientName.toLowerCase().includes(searchTerm)) ||
            (result.patientId && result.patientId.toLowerCase().includes(searchTerm)) ||
            (result.test && result.test.toLowerCase().includes(searchTerm)) ||
            (result.status && result.status.toLowerCase().includes(searchTerm))
        );
    }
    
    currentPage = 1;
    renderTable();
    updatePagination();
}

// View result function
function viewResult(id) {
    const result = allResults.find(r => r.id === id);
    if (!result) return;
    
    showResultModal({
        ...result,
        action: 'view'
    });
}

// Edit result function
function editResult(id) {
    const result = allResults.find(r => r.id === id);
    if (!result) return;
    
    showResultModal({
        ...result,
        action: 'edit'
    });
}

// Delete result function
function deleteResult(id) {
    deleteLabResult(id);
}

// Show result modal
function showResultModal(data) {
    let modal = document.getElementById('resultModal');
    
    if (!modal) {
        modal = createResultModal();
    }
    
    const modalContent = modal.querySelector('.modal-content');
    
    if (data.action === 'view') {
        modalContent.innerHTML = `
            <span class="close">&times;</span>
            <h2>Lab Result Details</h2>
            <div class="detail-section">
                <h3>Patient Information</h3>
                <div class="detail-item">
                    <span class="detail-label">Name:</span>
                    <span class="detail-value">${data.patientName || 'N/A'}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Patient ID:</span>
                    <span class="detail-value">${data.patientId || 'N/A'}</span>
                </div>
            </div>
            <div class="detail-section">
                <h3>Test Information</h3>
                <div class="detail-item">
                    <span class="detail-label">Test Type:</span>
                    <span class="detail-value">${data.test || 'N/A'}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Status:</span>
                    <span class="detail-value">
                        <span class="status ${(data.status || 'pending').toLowerCase()}">${data.status || 'Pending'}</span>
                    </span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Date:</span>
                    <span class="detail-value">${data.date || 'N/A'}</span>
                </div>
            </div>
            <div class="detail-section">
                <h3>Results</h3>
                <div class="detail-item">
                    <div class="detail-value">${data.results || 'No results available'}</div>
                </div>
                ${data.notes ? `
                <div class="detail-item">
                    <span class="detail-label">Notes:</span>
                    <div class="detail-value">${data.notes}</div>
                </div>
                ` : ''}
            </div>
            <div class="detail-section">
                <h3>Timestamps</h3>
                <div class="detail-item">
                    <span class="detail-label">Created:</span>
                    <span class="detail-value">${data.createdAt ? new Date(data.createdAt).toLocaleString() : 'N/A'}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Last Updated:</span>
                    <span class="detail-value">${data.updatedAt ? new Date(data.updatedAt).toLocaleString() : 'N/A'}</span>
                </div>
            </div>
            ${data.status === 'abnormal' && !data.acknowledged ? `
            <div class="detail-section">
                <button class="form-btn primary" onclick="acknowledgeAbnormalResult('${data.id}')">
                    <i class="fas fa-check-circle"></i> Acknowledge Abnormal Result
                </button>
            </div>
            ` : ''}
        `;
    } else if (data.action === 'edit') {
        modalContent.innerHTML = `
            <span class="close">&times;</span>
            <h2>Edit Lab Result</h2>
            <form id="editResultForm">
                <div class="form-group">
                    <label>Patient ID:</label>
                    <select id="editPatientSelect" required>
                        <option value="">Select Patient ID</option>
                    </select>
                </div>
                <div class="form-group" id="editPatientNameGroup">
                    <label>Patient Name:</label>
                    <div style="position: relative;">
                        <input type="text" id="editPatientName" readonly style="background-color: #f5f5f5; cursor: not-allowed;">
                        <small style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); color: #10b981; font-size: 11px; font-weight: 600;">
                            <i class="fas fa-check-circle"></i>
                        </small>
                    </div>
                </div>
                <div class="form-group" style="display: none;">
                    <label>Patient ID:</label>
                    <input type="text" id="editPatientId" readonly>
                </div>
                <div class="form-group">
                    <label>Test Type:</label>
                    <input type="text" id="editTest" value="${data.test || ''}" required placeholder="Enter test type">
                </div>
                <div class="form-group">
                    <label>Status:</label>
                    <select id="editStatus" required>
                        <option value="pending" ${(data.status || 'pending') === 'pending' ? 'selected' : ''}>Pending</option>
                        <option value="normal" ${data.status === 'normal' ? 'selected' : ''}>Normal</option>
                        <option value="abnormal" ${data.status === 'abnormal' ? 'selected' : ''}>Abnormal</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Results:</label>
                    <textarea id="editResults" rows="4" required>${data.results || ''}</textarea>
                </div>
                <div class="form-group">
                    <label>Notes:</label>
                    <textarea id="editNotes" rows="2">${data.notes || ''}</textarea>
                </div>
                <div class="form-group">
                    <label>Date:</label>
                    <input type="date" id="editDate" value="${data.date || ''}" required>
                </div>
                <div class="form-buttons">
                    <button type="button" class="form-btn secondary" onclick="closeModal('resultModal')">Cancel</button>
                    <button type="submit" class="form-btn primary">Save Changes</button>
                </div>
            </form>
        `;
        
        // Populate patient dropdown for edit
        const editPatientSelect = document.getElementById('editPatientSelect');
        if (editPatientSelect) {
            // Add patients to dropdown - showing only Patient ID
            const sortedPatients = Object.entries(allPatients).sort((a, b) => {
                return a[1].patientId.localeCompare(b[1].patientId);
            });
            
            sortedPatients.forEach(([key, patient]) => {
                const option = document.createElement('option');
                option.value = key;
                option.textContent = patient.patientId;
                option.dataset.patientName = patient.fullName;
                option.dataset.patientId = patient.patientId;
                editPatientSelect.appendChild(option);
            });
            
            // Find and select current patient
            const currentPatientEntry = Object.entries(allPatients).find(([key, patient]) => 
                patient.patientId === data.patientId || patient.fullName === data.patientName
            );
            
            if (currentPatientEntry) {
                editPatientSelect.value = currentPatientEntry[0];
                document.getElementById('editPatientName').value = currentPatientEntry[1].fullName;
                document.getElementById('editPatientId').value = currentPatientEntry[1].patientId;
                // Show patient name field if patient is found
                const editPatientNameGroup = document.getElementById('editPatientNameGroup');
                if (editPatientNameGroup) {
                    editPatientNameGroup.style.display = 'block';
                }
            }
            
            // Handle patient selection change
            editPatientSelect.addEventListener('change', function() {
                const selected = this.options[this.selectedIndex];
                const editPatientNameGroup = document.getElementById('editPatientNameGroup');
                if (selected.value) {
                    document.getElementById('editPatientName').value = selected.dataset.patientName;
                    document.getElementById('editPatientId').value = selected.dataset.patientId;
                    if (editPatientNameGroup) {
                        editPatientNameGroup.style.display = 'block';
                        // Flash the auto-filled indicator
                        const autoFilledIndicator = editPatientNameGroup.querySelector('small');
                        if (autoFilledIndicator) {
                            autoFilledIndicator.style.animation = 'pulse 0.5s ease-out';
                            setTimeout(() => {
                                autoFilledIndicator.style.animation = '';
                            }, 500);
                        }
                    }
                } else {
                    document.getElementById('editPatientName').value = '';
                    document.getElementById('editPatientId').value = '';
                    if (editPatientNameGroup) {
                        editPatientNameGroup.style.display = 'none';
                    }
                }
            });
        }
        
        // Setup form submission
        const form = document.getElementById('editResultForm');
        form.onsubmit = function(e) {
            e.preventDefault();
            const updatedData = {
                patientName: document.getElementById('editPatientName').value,
                patientId: document.getElementById('editPatientId').value,
                test: document.getElementById('editTest').value,
                status: document.getElementById('editStatus').value,
                results: document.getElementById('editResults').value,
                notes: document.getElementById('editNotes').value,
                date: document.getElementById('editDate').value
            };
            updateLabResult(data.id, updatedData);
        };
    }
    
    modal.style.display = 'block';
    setupModalEvents();
}

// Acknowledge abnormal result
async function acknowledgeAbnormalResult(id) {
    if (labResultsRef) {
        labResultsRef.child(id).update({
            acknowledged: true,
            acknowledgedAt: new Date().toISOString(),
            acknowledgedBy: currentUser.displayName
        }).then(() => {
            showMessage('Abnormal result acknowledged', 'success');
            closeModal('resultModal');
        }).catch((error) => {
            console.error('Error acknowledging result:', error);
            showMessage('Error acknowledging result', 'error');
        });
    }
}

// Create result modal
function createResultModal() {
    const modal = document.createElement('div');
    modal.id = 'resultModal';
    modal.className = 'modal';
    modal.innerHTML = '<div class="modal-content"></div>';
    document.body.appendChild(modal);
    return modal;
}

// Show add lab modal
function showAddLabModal() {
    let modal = document.getElementById('addLabModal');
    
    if (!modal) {
        modal = createAddLabModal();
    }
    
    // Set today's date as default
    const today = new Date().toISOString().split('T')[0];
    const dateInput = modal.querySelector('#addDate');
    if (dateInput) {
        dateInput.value = today;
    }
    
    // Update patient dropdown
    updatePatientDropdown();
    
    modal.style.display = 'block';
    setupModalEvents();
}

// Populate patient dropdown
function populatePatientDropdown() {
    const patientSelect = document.getElementById('patientSelect');
    
    if (!patientSelect) {
        return;
    }

    // Clear existing options except the first placeholder
    patientSelect.innerHTML = '<option value="">Select Patient ID</option>';

    if (allPatients.length === 0) {
        const noPatientOption = document.createElement('option');
        noPatientOption.value = '';
        noPatientOption.textContent = 'No patients available - Add patients first';
        noPatientOption.disabled = true;
        patientSelect.appendChild(noPatientOption);
        return;
    }

    // Add patients to dropdown
    allPatients.forEach(patient => {
        if (patient.id) {
            const option = document.createElement('option');
            option.value = patient.id;
            option.textContent = patient.id;
            option.dataset.fullName = patient.fullName || 'Unknown';
            option.dataset.patientKey = patient.key;
            option.dataset.age = patient.age || 'N/A';
            option.dataset.status = patient.status || 'Unknown';
            
            patientSelect.appendChild(option);
        }
    });
}

// Create add lab modal
function createAddLabModal() {
    const modal = document.createElement('div');
    modal.id = 'addLabModal';
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Add New Lab Result</h2>
            <form id="addLabForm">
                <div class="form-group">
                    <label>Patient ID:</label>
                    <select id="patientSelect" required>
                        <option value="" style="color: #999;">Select Patient ID</option>
                    </select>
                </div>
                <div class="form-group" id="patientNameGroup" style="display: none;">
                    <label>Patient Name:</label>
                    <div style="position: relative;">
                        <input type="text" id="addPatientName" readonly style="background-color: #f5f5f5; cursor: not-allowed;">
                        <small style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); color: #10b981; font-size: 11px; font-weight: 600;">
                            <i class="fas fa-check-circle"></i>
                        </small>
                    </div>
                </div>
                <div class="form-group" style="display: none;">
                    <label>Patient ID:</label>
                    <input type="text" id="addPatientId" readonly>
                </div>
                <div class="form-group">
                    <label>Test Type:</label>
                    <input type="text" id="addTestType" required placeholder="e.g., Blood Test, Ultrasound, Glucose Test">
                </div>
                <div class="form-group">
                    <label>Status:</label>
                    <select id="addStatus" required>
                        <option value="pending">Pending</option>
                        <option value="normal">Normal</option>
                        <option value="abnormal">Abnormal</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Results:</label>
                    <textarea id="addResults" rows="4" placeholder="Enter test results..."></textarea>
                </div>
                <div class="form-group">
                    <label>Notes:</label>
                    <textarea id="addNotes" rows="2" placeholder="Additional notes (optional)..."></textarea>
                </div>
                <div class="form-group">
                    <label>Date:</label>
                    <input type="date" id="addDate" required>
                </div>
                <div class="patient-preview" id="patientPreview" style="display: none; margin: 15px 0; padding: 15px; background: #f8f9fa; border-radius: 8px; border: 1px solid #dee2e6;">
                    <h4 style="margin: 0 0 10px 0; color: #495057;">Selected Patient Details:</h4>
                    <div id="previewContent"></div>
                </div>
                <div class="form-buttons">
                    <button type="button" class="form-btn secondary" onclick="closeModal('addLabModal')">Cancel</button>
                    <button type="submit" class="form-btn primary">Add Result</button>
                </div>
            </form>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Setup patient selection
    const patientSelect = document.getElementById('patientSelect');
    patientSelect.addEventListener('change', function() {
        const selected = this.options[this.selectedIndex];
        const patientNameInput = document.getElementById('addPatientName');
        const patientIdInput = document.getElementById('addPatientId');
        const patientNameGroup = document.getElementById('patientNameGroup');
        const patientPreview = document.getElementById('patientPreview');
        const previewContent = document.getElementById('previewContent');
        
        if (selected.value) {
            // Find patient data
            const patient = allPatients.find(p => p.id === selected.value);
            
            if (patient) {
                // Update fields
                patientNameInput.value = patient.fullName;
                patientIdInput.value = patient.id;
                
                // Show patient name field with animation
                patientNameGroup.style.display = 'block';
                
                // Flash the auto-filled indicator
                const autoFilledIndicator = patientNameGroup.querySelector('small');
                if (autoFilledIndicator) {
                    autoFilledIndicator.style.animation = 'pulse 0.5s ease-out';
                    setTimeout(() => {
                        autoFilledIndicator.style.animation = '';
                    }, 500);
                }
                
                // Show patient preview
                previewContent.innerHTML = `
                    <div style="display: grid; grid-template-columns: auto 1fr; gap: 8px; font-size: 14px;">
                        <strong>Name:</strong> <span>${patient.fullName}</span>
                        <strong>ID:</strong> <span>${patient.id}</span>
                        <strong>Age:</strong> <span>${patient.age} years</span>
                        <strong>Due Date:</strong> <span>${new Date(patient.dueDate).toLocaleDateString()}</span>
                        <strong>Status:</strong> <span class="status ${patient.status.toLowerCase()}" style="font-size: 12px;">${patient.status}</span>
                    </div>
                `;
                patientPreview.style.display = 'block';
            }
        } else {
            // Clear fields and hide patient name
            patientNameInput.value = '';
            patientIdInput.value = '';
            patientNameGroup.style.display = 'none';
            patientPreview.style.display = 'none';
        }
    });
    
    // Setup form submission
    const form = document.getElementById('addLabForm');
    form.onsubmit = function(e) {
        e.preventDefault();
        
        const patientName = document.getElementById('addPatientName').value;
        const patientId = document.getElementById('addPatientId').value;
        
        if (!patientName || !patientId) {
            showMessage('Please select a patient ID from the dropdown', 'error');
            return;
        }
        
        const resultData = {
            patientName: patientName,
            patientId: patientId,
            test: document.getElementById('addTestType').value,
            status: document.getElementById('addStatus').value,
            results: document.getElementById('addResults').value,
            notes: document.getElementById('addNotes').value,
            date: document.getElementById('addDate').value
        };
        addLabResult(resultData);
        
        // Reset form
        form.reset();
        document.getElementById('patientNameGroup').style.display = 'none';
        document.getElementById('patientPreview').style.display = 'none';
    };
    
    return modal;
}

// Toggle dropdown visibility
function toggleDropdown(dropdownId) {
    const dropdown = document.getElementById(dropdownId);
    if (!dropdown) return;
    
    // Close all other dropdowns
    document.querySelectorAll('.dropdown').forEach(d => {
        if (d.id !== dropdownId) {
            d.classList.remove('show');
        }
    });
    
    // Toggle current dropdown
    dropdown.classList.toggle('show');
}

// Close all dropdowns
function closeAllDropdowns() {
    const dropdowns = document.querySelectorAll('.dropdown');
    dropdowns.forEach(dropdown => {
        dropdown.classList.remove('show');
    });
}

// Update pagination controls
function updatePagination() {
    const totalRecords = filteredResults.length;
    const totalPages = Math.ceil(totalRecords / recordsPerPage);
    
    // Update pagination info
    const paginationInfo = document.getElementById('paginationInfo');
    if (paginationInfo) {
        const startRecord = totalRecords === 0 ? 0 : ((currentPage - 1) * recordsPerPage) + 1;
        const endRecord = Math.min(currentPage * recordsPerPage, totalRecords);
        paginationInfo.textContent = `Showing ${startRecord}-${endRecord} of ${totalRecords} entries`;
    }

    // Update pagination controls
    updatePaginationButtons(totalPages);
}

// Update pagination buttons
function updatePaginationButtons(totalPages) {
    const paginationControls = document.querySelector('.pagination-controls');
    if (!paginationControls) return;

    paginationControls.innerHTML = `
        <button class="pagination-btn" onclick="changePage(-1)" ${currentPage === 1 || totalPages === 0 ? 'disabled' : ''}>‹</button>
        <button class="pagination-btn active" onclick="goToPage(${currentPage})">${currentPage}</button>
        <button class="pagination-btn" onclick="changePage(1)" ${currentPage === totalPages || totalPages === 0 ? 'disabled' : ''}>›</button>
    `;
}

// Change page function
function changePage(direction) {
    const totalPages = Math.ceil(filteredResults.length / recordsPerPage);
    const newPage = currentPage + direction;
    
    if (newPage >= 1 && newPage <= totalPages) {
        currentPage = newPage;
        renderTable();
        updatePagination();
    }
}

// Go to specific page
function goToPage(page) {
    const totalPages = Math.ceil(filteredResults.length / recordsPerPage);
    
    if (page >= 1 && page <= totalPages) {
        currentPage = page;
        renderTable();
        updatePagination();
    }
}

// Show abnormal results
function showAbnormalResults() {
    const abnormalResults = allResults.filter(result => 
        result.status && result.status.toLowerCase() === 'abnormal'
    );
    
    if (abnormalResults.length === 0) {
        showMessage('No abnormal results found.', 'success');
        return;
    }
    
    // Filter to show only abnormal results
    filteredResults = abnormalResults;
    currentPage = 1;
    renderTable();
    updatePagination();
    
    // Highlight the table
    const tableContainer = document.querySelector('.table-container');
    if (tableContainer) {
        tableContainer.style.border = '2px solid #e91e63';
        setTimeout(() => {
            tableContainer.style.border = '';
        }, 3000);
    }
    
    showMessage(`Found ${abnormalResults.length} abnormal result(s)`, 'success');
}

// Update abnormal count
function updateAbnormalCount() {
    const abnormalCount = allResults.filter(result => 
        result.status && result.status.toLowerCase() === 'abnormal'
    ).length;
    
    const abnormalCountElement = document.getElementById('abnormalCount');
    if (abnormalCountElement) {
        abnormalCountElement.textContent = `${abnormalCount} abnormal lab results require immediate review`;
    }
    
    // Update alert visibility
    const alert = document.querySelector('.alert');
    if (alert) {
        alert.style.display = abnormalCount > 0 ? 'flex' : 'none';
    }
}

// Setup modal events
function setupModalEvents() {
    // Close button functionality
    document.querySelectorAll('.close').forEach(closeBtn => {
        closeBtn.onclick = function() {
            const modal = this.closest('.modal');
            if (modal) {
                modal.style.display = 'none';
            }
        };
    });
    
    // Click outside modal to close
    document.querySelectorAll('.modal').forEach(modal => {
        modal.onclick = function(e) {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        };
    });
}

// Close modal function
function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
    }
}

// Updated show message function to use unified notification system
function showMessage(message, type = 'success') {
    // Use unified notification system if available
    if (window.showNotification) {
        window.showNotification(message, type, 'lab-results');
    } else {
        // Fallback to old system
        // Remove existing messages
        const existingMessages = document.querySelectorAll('.success-message, .error-message');
        existingMessages.forEach(msg => msg.remove());
        
        // Create new message
        const messageDiv = document.createElement('div');
        messageDiv.className = type === 'success' ? 'success-message' : 'error-message';
        messageDiv.textContent = message;
        
        // Insert after search header
        const searchHeader = document.querySelector('.search-header');
        if (searchHeader) {
            searchHeader.insertAdjacentElement('afterend', messageDiv);
            
            // Auto remove after 5 seconds
            setTimeout(() => {
                messageDiv.remove();
            }, 5000);
        }
    }
}

// Add custom styles for patient selection
const style = document.createElement('style');
style.textContent = `
    #patientSelect, #editPatientSelect {
        width: 100%;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 14px;
        background-color: white;
        cursor: pointer;
        font-family: monospace;
        font-weight: 600;
    }
    
    #patientSelect:focus, #editPatientSelect:focus {
        outline: none;
        border-color: #e91e63;
    }
    
    #addPatientName, #editPatientName {
        font-weight: 600;
        color: #333;
        padding-right: 100px;
    }
    
    #patientNameGroup, #editPatientNameGroup {
        animation: slideDown 0.3s ease-out;
    }
    
    .patient-preview {
        animation: slideDown 0.3s ease-out;
    }
    
    @keyframes slideDown {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.1); }
        100% { transform: scale(1); }
    }
    
    .status {
        display: flex;
        flex-direction: row;
        margin-left: -5px;
        margin-top: -5px;
        border-radius: 12px;
        width: fit-content;
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
    }
    
    .status.ongoing {
        background-color: #fff3cd;
        color: #856404;
    }
    
    .status.completed {
        background-color: #d4edda;
        color: #155724;
    }
    
    .status.pending {
        background-color: #f8d7da;
        color: #721c24;
    }
    
    .status.normal {
        background-color: #d1ecf1;
        color: #0c5460;
    }
    
    .status.abnormal {
        background-color: #f8d7da;
        color: #721c24;
    }
`;
document.head.appendChild(style);

// Export functions for global access
window.viewResult = viewResult;
window.editResult = editResult;
window.deleteResult = deleteResult;
window.changePage = changePage;
window.goToPage = goToPage;
window.closeModal = closeModal;
window.toggleDropdown = toggleDropdown;
window.acknowledgeAbnormalResult = acknowledgeAbnormalResult;