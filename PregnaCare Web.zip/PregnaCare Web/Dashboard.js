// PregnaCare Dashboard - Complete Version with Accurate Data Fetching
// Version: 2.0.0
// Date: January 2025
// Features: Complete Firebase integration, real-time data fetching, enhanced UI updates

// Firebase Configuration
const firebaseConfig = {
    apiKey: "AIzaSyBGPYM5JHrSXOd9PWbQ4TzoqUtlf5qCwjs",
    authDomain: "pregnacare-web.firebaseapp.com",
    databaseURL: "https://pregnacare-web-default-rtdb.firebaseio.com",
    projectId: "pregnacare-web",
    storageBucket: "pregnacare-web.firebasestorage.app",
    messagingSenderId: "408625794290",
    appId: "1:408625794290:web:bb131c8b35869b31acd46b",
    measurementId: "G-HZB017TYX3"
};

class PregnaCareApp {
    constructor() {
        this.searchTimeout = null;
        this.listeners = new Map();
        this.dropdowns = new Map();
        this.firebaseListeners = {}; // Store Firebase listeners for cleanup
        this.dashboardData = {
            patients: {},
            appointments: {},
            labResults: {},
            medications: {},
            notifications: {}
        };
        
        // Loading states for each data type
        this.loadingStates = {
            patients: true,
            appointments: true,
            labResults: true,
            medications: true
        };
        
        // Auto-hide topbar configuration
        this.topBarConfig = {
            lastScrollY: 0,
            hideOffset: 80,
            scrollThreshold: 5,
            isHidden: false,
            ticking: false,
            initialized: false,
            enabled: true
        };
        
        this.elements = {};
        this.notificationSystem = window.notificationSystem;
        this.dataManager = null;
        this.firebaseManager = window.firebaseManager;
        this.currentUser = null;
        
        // Cache for performance
        this.dataCache = {
            lastUpdate: {},
            updateInterval: 30000 // 30 seconds
        };
        
        // Inject CSS for enhanced features
        this.injectEnhancedCSS();
        
        // Wait for Firebase to be ready
        this.waitForFirebase();
    }

    // Enhanced CSS with all dashboard features
    injectEnhancedCSS() {
        const existingStyle = document.getElementById('dashboard-enhanced-css');
        if (existingStyle) return;

        console.log('Dashboard: Adding enhanced CSS...');
        
        const style = document.createElement('style');
        style.id = 'dashboard-enhanced-css';
        style.textContent = `
            /* Auto-hide functionality */
            .topbar-autohide {
                transition: transform 0.3s ease !important;
                will-change: transform;
            }
            
            .topbar-autohide.header-hidden {
                transform: translateY(-100%) !important;
            }
            
            .topbar-autohide.header-visible {
                transform: translateY(0) !important;
            }
            
            /* Smooth scroll behavior */
            html {
                scroll-behavior: smooth;
            }
            
            /* Loading states */
            .data-loading {
                position: relative;
                min-height: 100px;
            }
            
            .data-loading::after {
                content: '';
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                width: 40px;
                height: 40px;
                border: 3px solid #f3f3f3;
                border-top: 3px solid var(--heart-red);
                border-radius: 50%;
                animation: spin 1s linear infinite;
            }
            
            @keyframes spin {
                0% { transform: translate(-50%, -50%) rotate(0deg); }
                100% { transform: translate(-50%, -50%) rotate(360deg); }
            }
            
            /* Enhanced Dashboard Components */
            .dashboard-alerts {
                background: linear-gradient(135deg, #fff5f5, #ffe0e0);
                border: 1px solid rgba(230, 57, 70, 0.2);
                border-radius: 15px;
                padding: 20px;
                margin-bottom: 25px;
                box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
                animation: slideIn 0.5s ease-out;
            }
            
            .alerts-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 15px;
            }
            
            .alerts-header h3 {
                margin: 0;
                color: var(--deep-red);
                font-size: 18px;
                display: flex;
                align-items: center;
                gap: 10px;
            }
            
            .alert-count {
                background: var(--heart-red);
                color: white;
                padding: 4px 12px;
                border-radius: 20px;
                font-size: 14px;
                font-weight: 600;
            }
            
            .alerts-list {
                display: flex;
                flex-direction: column;
                gap: 10px;
            }
            
            .alert-item {
                display: flex;
                align-items: center;
                gap: 15px;
                padding: 12px 16px;
                background: white;
                border-radius: 10px;
                border-left: 4px solid;
                transition: all 0.3s ease;
                cursor: pointer;
            }
            
            .alert-item:hover {
                transform: translateX(5px);
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            }
            
            .alert-warning {
                border-left-color: #f59e0b;
            }
            
            .alert-danger {
                border-left-color: #e63946;
            }
            
            .alert-info {
                border-left-color: #3b82f6;
            }
            
            .alert-message {
                flex: 1;
                font-weight: 500;
            }
            
            .alert-action {
                color: var(--heart-red);
                text-decoration: none;
                font-weight: 600;
                font-size: 14px;
            }
            
            .alert-action:hover {
                text-decoration: underline;
            }
            
            /* Enhanced Summary Widgets */
            .summary-widget {
                background: white;
                border-radius: 15px;
                padding: 20px;
                box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
                margin-bottom: 20px;
            }
            
            .widget-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 15px;
                padding-bottom: 10px;
                border-bottom: 1px solid #eee;
            }
            
            .widget-header h3 {
                margin: 0;
                color: var(--deep-red);
                font-size: 18px;
                display: flex;
                align-items: center;
                gap: 10px;
            }
            
            .view-all {
                color: var(--heart-red);
                text-decoration: none;
                font-weight: 600;
                font-size: 14px;
            }
            
            .view-all:hover {
                text-decoration: underline;
            }
            
            .summary-stats {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(80px, 1fr));
                gap: 15px;
                margin-bottom: 15px;
            }
            
            .stat-item {
                text-align: center;
                padding: 15px 10px;
                background: #f8f9fa;
                border-radius: 10px;
                transition: all 0.3s ease;
            }
            
            .stat-item.alert {
                background: rgba(230, 57, 70, 0.1);
                border: 1px solid rgba(230, 57, 70, 0.2);
                animation: pulse 2s infinite;
            }
            
            .stat-item.warning {
                background: rgba(245, 158, 11, 0.1);
                border: 1px solid rgba(245, 158, 11, 0.2);
            }
            
            .stat-number {
                font-size: 24px;
                font-weight: 700;
                color: var(--deep-red);
                margin-bottom: 5px;
            }
            
            .stat-label {
                font-size: 12px;
                color: #666;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }
            
            /* Enhanced Patient Display */
            .patient-info-enhanced {
                display: flex;
                flex-direction: column;
                gap: 3px;
            }
            
            .patient-meta {
                font-size: 11px;
                color: #999;
                display: flex;
                gap: 8px;
            }
            
            .patient-indicator {
                display: inline-block;
                width: 6px;
                height: 6px;
                border-radius: 50%;
                margin-right: 4px;
            }
            
            .indicator-high-risk {
                background: #e63946;
                animation: pulse 1.5s infinite;
            }
            
            .indicator-due-soon {
                background: #f59e0b;
            }
            
            .indicator-normal {
                background: #10b981;
            }
            
            /* Enhanced Actions */
            .actions-enhanced {
                display: flex;
                gap: 8px;
                align-items: center;
            }
            
            .action-btn {
                background: none;
                border: none;
                cursor: pointer;
                color: var(--heart-red);
                font-size: 14px;
                padding: 4px 8px;
                border-radius: 4px;
                transition: all 0.2s ease;
                display: flex;
                align-items: center;
                gap: 4px;
            }
            
            .action-btn:hover {
                background: rgba(230, 57, 70, 0.1);
                transform: scale(1.05);
            }
            
            .action-btn.urgent {
                color: #e63946;
                animation: pulse 1s infinite;
            }
            
            /* Status Badges */
            .status-badge {
                padding: 4px 8px;
                border-radius: 12px;
                font-size: 11px;
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }
            
            .status-badge.status-active,
            .status-badge.status-Ongoing {
                background: rgba(16, 185, 129, 0.2);
                color: #059669;
                border: 1px solid rgba(16, 185, 129, 0.3);
            }
            
            .status-badge.status-high-risk {
                background: rgba(230, 57, 70, 0.2);
                color: #c53030;
                border: 1px solid rgba(230, 57, 70, 0.3);
            }
            
            .status-badge.status-Completed {
                background: rgba(59, 130, 246, 0.2);
                color: #2563eb;
                border: 1px solid rgba(59, 130, 246, 0.3);
            }
            
            .status-badge.high-risk {
                background: rgba(230, 57, 70, 0.2);
                color: #c53030;
                border: 1px solid rgba(230, 57, 70, 0.3);
            }
            
            .status-badge.due-soon {
                background: rgba(245, 158, 11, 0.2);
                color: #d69e2e;
                border: 1px solid rgba(245, 158, 11, 0.3);
            }
            
            /* Animations */
            @keyframes slideIn {
                from {
                    opacity: 0;
                    transform: translateY(-10px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            
            @keyframes pulse {
                0%, 100% { opacity: 1; }
                50% { opacity: 0.7; }
            }
            
            @keyframes fadeIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }
            
            /* Responsive Design */
            @media (max-width: 768px) {
                .dashboard-alerts {
                    padding: 15px;
                }
                
                .summary-stats {
                    grid-template-columns: repeat(2, 1fr);
                    gap: 10px;
                }
                
                .alerts-header {
                    flex-direction: column;
                    align-items: flex-start;
                    gap: 10px;
                }
                
                .alert-item {
                    flex-direction: column;
                    align-items: flex-start;
                    gap: 8px;
                }
            }
            
            /* Loading States */
            .loading-shimmer {
                background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
                background-size: 200% 100%;
                animation: shimmer 1.5s infinite;
            }
            
            @keyframes shimmer {
                0% { background-position: -200% 0; }
                100% { background-position: 200% 0; }
            }
            
            /* Data error states */
            .data-error {
                text-align: center;
                padding: 20px;
                color: #e63946;
            }
            
            .data-error i {
                font-size: 48px;
                margin-bottom: 10px;
                display: block;
            }
            
            /* Empty states */
            .empty-state {
                text-align: center;
                padding: 40px 20px;
                color: #666;
            }
            
            .empty-state i {
                font-size: 48px;
                color: #ddd;
                margin-bottom: 15px;
                display: block;
            }
        `;
        
        document.head.appendChild(style);
    }

    // Wait for Firebase to be ready
    async waitForFirebase() {
        console.log('Dashboard: Initializing Firebase...');
        
        try {
            // Initialize Firebase directly if not already initialized
            if (!window.firebase?.apps?.length) {
                // Check if Firebase SDK is loaded
                if (typeof firebase !== 'undefined') {
                    firebase.initializeApp(firebaseConfig);
                    console.log('Dashboard: Firebase initialized directly');
                } else {
                    console.error('Dashboard: Firebase SDK not loaded');
                    this.initializeWithoutFirebase();
                    return;
                }
            }
            
            // Get Firebase instances
            this.auth = firebase.auth();
            this.rtdb = firebase.database();
            this.db = firebase.database();
            this.firebase = window.firebase;
            
            console.log('Dashboard: Firebase ready, initializing dashboard...');
            this.setupAuthStateListener();
            this.initializeDOMWhenReady();
            
        } catch (error) {
            console.error('Dashboard: Firebase initialization error:', error);
            this.initializeWithoutFirebase();
        }
    }

    async initializeWithFirebase(firebaseInstances) {
        this.auth = firebaseInstances.auth;
        this.rtdb = firebaseInstances.database;
        this.db = firebaseInstances.database;
        this.firebase = window.firebase;
        
        this.setupAuthStateListener();
        this.initializeDOMWhenReady();
    }

    initializeWithoutFirebase() {
        console.log('Dashboard: Initializing without Firebase (local mode)');
        this.initializeDOMWhenReady();
        
        this.currentUser = { 
            uid: 'demo-user', 
            email: 'demo@pregnacare.com',
            displayName: 'Demo Administrator'
        };
        
        // Update user display with demo data
        this.updateUserDisplay({
            email: this.currentUser.email,
            fullName: this.currentUser.displayName,
            role: 'Administrator (Demo Mode)'
        });
    }

    initializeDOMWhenReady() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                setTimeout(() => this.onDOMReady(), 150);
            });
        } else {
            setTimeout(() => this.onDOMReady(), 150);
        }
    }

    setupAuthStateListener() {
        if (!this.auth) return;
        
        this.auth.onAuthStateChanged(async (user) => {
            if (user) {
                console.log('Dashboard: User authenticated:', user.email);
                this.currentUser = user;
                
                // Initial user display update
                this.updateUserDisplay({
                    email: user.email,
                    fullName: user.displayName || user.email.split('@')[0],
                    role: 'Administrator',
                    uid: user.uid
                });
                
                // Initialize notification system
                if (window.NotificationIntegration && this.rtdb) {
                    await window.NotificationIntegration.initialize(window.notificationSystem);
                    console.log('Dashboard: Notification integration initialized');
                }
                
                try {
                    if (window.pregnacare_admin) {
                        this.userProfile = window.pregnacare_admin;
                        this.updateUserDisplay(this.userProfile);
                    } else {
                        await this.loadUserProfile(user.uid);
                    }
                } catch (error) {
                    console.log('Dashboard: Using basic auth info only', error);
                }
                
                await this.initializeDashboard();
            } else {
                // If no user is authenticated, still try to load data
                console.log('Dashboard: No authenticated user, attempting to load data anyway...');
                this.currentUser = { 
                    uid: 'dashboard-anonymous', 
                    email: 'dashboard@pregnacare.com',
                    displayName: 'Dashboard User'
                };
                await this.initializeDashboard();
            }
        });
    }

    async loadUserProfile(uid) {
        try {
            const { ref, onValue, get } = this.firebase.database;
            const userRef = ref(this.rtdb, `admins/${uid}`);
            const snapshot = await get(userRef);
            
            if (snapshot.exists()) {
                this.userProfile = snapshot.val();
                if (this.currentUser && this.currentUser.email) {
                    this.userProfile.email = this.userProfile.email || this.currentUser.email;
                }
                this.updateUserDisplay(this.userProfile);
                console.log('Dashboard: User profile loaded:', this.userProfile);
                
                // Set up real-time listener for profile updates
                onValue(userRef, (snapshot) => {
                    if (snapshot.exists()) {
                        this.userProfile = snapshot.val();
                        if (this.currentUser && this.currentUser.email) {
                            this.userProfile.email = this.userProfile.email || this.currentUser.email;
                        }
                        this.updateUserDisplay(this.userProfile);
                    }
                });
                
                return this.userProfile;
            } else {
                console.log('Dashboard: No profile in database, using auth data');
                this.userProfile = {
                    email: this.currentUser.email,
                    uid: this.currentUser.uid,
                    role: 'Administrator',
                    createdAt: new Date().toISOString()
                };
                this.updateUserDisplay(this.userProfile);
                return this.userProfile;
            }
        } catch (error) {
            console.error('Dashboard: Error loading user profile:', error);
            if (this.currentUser) {
                this.updateUserDisplay({
                    email: this.currentUser.email,
                    role: 'Administrator'
                });
            }
            this.showError('Failed to load complete user profile');
        }
    }

    onDOMReady() {
        console.log('Dashboard: DOM Ready - Setting up components...');
        
        this.setupEventListeners();
        this.updateCurrentDate();
        this.setupAutoHideOnExistingTopbar();
        this.loadInitialData();
        
        console.log('Dashboard: All components initialized successfully');
    }

    setupAutoHideOnExistingTopbar() {
        console.log('Dashboard: Setting up auto-hide on existing topbar...');
        
        let topbar = null;
        const topbarSelectors = [
            '.topbar',
            '.header',
            '.search-header', 
            '.top-header',
            '.navbar',
            '.main-header',
            'header',
            '.dashboard-header'
        ];
        
        for (const selector of topbarSelectors) {
            topbar = document.querySelector(selector);
            if (topbar) {
                console.log(`Dashboard: Found topbar with selector: ${selector}`);
                break;
            }
        }
        
        if (!topbar) {
            const searchInput = document.querySelector('input[placeholder*="Search"], input[placeholder*="search"]');
            if (searchInput) {
                let parent = searchInput.parentElement;
                while (parent && parent !== document.body) {
                    const rect = parent.getBoundingClientRect();
                    if (rect.top <= 50 && rect.width > window.innerWidth * 0.7) {
                        topbar = parent;
                        console.log('Dashboard: Found topbar by search input location');
                        break;
                    }
                    parent = parent.parentElement;
                }
            }
        }
        
        if (!topbar) {
            console.warn('Dashboard: Could not find existing topbar. Auto-hide not enabled.');
            return;
        }
        
        this.elements.searchHeader = topbar;
        topbar.classList.add('topbar-autohide');
        
        const currentPosition = window.getComputedStyle(topbar).position;
        if (currentPosition !== 'fixed' && currentPosition !== 'sticky') {
            console.log('Dashboard: Making topbar fixed for auto-hide functionality');
            topbar.style.position = 'fixed';
            topbar.style.top = '0';
            topbar.style.left = '0';
            topbar.style.right = '0';
            topbar.style.zIndex = '1000';
        }
        
        this.topBarConfig.lastScrollY = window.pageYOffset || document.documentElement.scrollTop;
        this.topBarConfig.isHidden = false;
        this.topBarConfig.initialized = true;
        
        topbar.classList.remove('header-hidden');
        topbar.classList.add('header-visible');
        
        this.createScrollProgressBar();
        
        this.handleScroll = this.handleScrollPreserveDesign.bind(this);
        this.throttledScroll = this.throttledScrollPreserveDesign.bind(this);
        
        window.addEventListener('scroll', this.throttledScroll, { passive: true });
        this.updateScrollProgress();
        
        console.log('Dashboard: Auto-hide successfully added to existing topbar');
        
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.key === 'h') {
                e.preventDefault();
                this.toggleSearchHeader();
            }
        });
        
        console.log('Dashboard: Added Ctrl+H keyboard shortcut for manual toggle');
    }

    createScrollProgressBar() {
        let progressBar = document.querySelector('.scroll-progress-bar');
        if (!progressBar) {
            progressBar = document.createElement('div');
            progressBar.className = 'scroll-progress-bar';
            progressBar.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                width: 0%;
                height: 3px;
                background: linear-gradient(135deg, var(--heart-red), var(--deep-red));
                z-index: 1001;
                transition: width 0.3s ease;
            `;
            document.body.appendChild(progressBar);
        }
        this.elements.scrollProgressBar = progressBar;
        return progressBar;
    }

    throttledScrollPreserveDesign() {
        if (!this.topBarConfig.ticking && this.topBarConfig.initialized && this.topBarConfig.enabled) {
            window.requestAnimationFrame(() => {
                this.handleScrollPreserveDesign();
                this.topBarConfig.ticking = false;
            });
            this.topBarConfig.ticking = true;
        }
    }

    handleScrollPreserveDesign() {
        const currentY = window.pageYOffset || document.documentElement.scrollTop;
        const delta = currentY - this.topBarConfig.lastScrollY;

        this.updateScrollProgress();

        if (Math.abs(delta) < this.topBarConfig.scrollThreshold) {
            return;
        }

        if (currentY <= 10) {
            this.showTopbarPreserveDesign();
        } else if (delta > 0 && currentY > this.topBarConfig.hideOffset) {
            this.hideTopbarPreserveDesign();
        } else if (delta < 0) {
            this.showTopbarPreserveDesign();
        }

        this.topBarConfig.lastScrollY = currentY;
    }

    showTopbarPreserveDesign() {
        if (!this.topBarConfig.isHidden || !this.elements.searchHeader) return;

        const topbar = this.elements.searchHeader;
        
        topbar.classList.remove('header-hidden');
        topbar.classList.add('header-visible');

        this.topBarConfig.isHidden = false;
    }

    hideTopbarPreserveDesign() {
        if (this.topBarConfig.isHidden || !this.elements.searchHeader) return;

        const topbar = this.elements.searchHeader;
        
        topbar.classList.add('header-hidden');
        topbar.classList.remove('header-visible');

        this.topBarConfig.isHidden = true;
    }

    updateScrollProgress() {
        if (!this.elements.scrollProgressBar) return;

        const windowHeight = window.innerHeight;
        const documentHeight = document.documentElement.scrollHeight;
        const scrollY = window.pageYOffset || document.documentElement.scrollTop;
        const scrollPercent = documentHeight > windowHeight ? (scrollY / (documentHeight - windowHeight)) * 100 : 0;

        this.elements.scrollProgressBar.style.width = `${Math.min(scrollPercent, 100)}%`;
    }

    async initializeDashboard() {
        try {
            console.log('Dashboard: Initializing dashboard components...');
            
            // Show loading states
            this.showLoadingStates();
            
            // Initialize enhanced data manager if available
            if (window.EnhancedDashboardDataManager && this.rtdb && this.firebase) {
                this.dataManager = new window.EnhancedDashboardDataManager(this.rtdb, this.firebase);
                
                this.dataManager.onDataUpdate = (dataType, data) => {
                    console.log(`Dashboard: Received ${dataType} update, count: ${Object.keys(data || {}).length}`);
                    this.dashboardData[dataType] = data;
                    this.loadingStates[dataType] = false;
                    
                    switch(dataType) {
                        case 'patients':
                            this.updateDashboardStats();
                            this.updateEnhancedPatientsDisplay();
                            this.updateWeeklyTracker();
                            this.updateDeliveryList();
                            break;
                            
                        case 'appointments':
                            this.updateDashboardStats();
                            this.updateEnhancedAppointmentsDisplay();
                            break;
                            
                        case 'labResults':
                            this.checkAbnormalLabResults();
                            break;
                            
                        case 'medications':
                            this.checkMedicationRefills();
                            break;
                    }
                    
                    this.updateUnifiedDashboard();
                    this.hideLoadingStates();
                };
                
                const success = await this.dataManager.initializeAllConnections();
                if (success) {
                    console.log('Dashboard: Enhanced data manager initialized');
                    this.updateUnifiedDashboard();
                } else {
                    console.log('Dashboard: Falling back to basic data loading');
                    this.startBasicRealTimeListeners();
                }
            } else {
                console.log('Dashboard: Using basic data loading');
                this.startBasicRealTimeListeners();
            }
            
            await this.checkDashboardAlerts();
            
            console.log('Dashboard: Initialization complete');
        } catch (error) {
            console.error('Dashboard: Initialization error:', error);
            this.showError('Failed to initialize dashboard. Please refresh the page.');
            this.hideLoadingStates();
        }
    }

    // Enhanced unified dashboard update
    updateUnifiedDashboard() {
        if (!this.dataManager) return;
        
        const stats = this.dataManager.getDashboardStatistics();
        
        this.updateStatCards(stats);
        // System alerts removed - notifications now handled by unified notification system
        this.updateLabResultsSummary(stats.labResults);
        this.updateMedicationsSummary(stats.medications);
        
        console.log('Dashboard: Unified update complete', stats);
    }

    // Update stat cards with enhanced data
    updateStatCards(stats) {
        const cardNumbers = document.querySelectorAll('.card-number');
        
        if (cardNumbers.length >= 4) {
            this.animateNumber(cardNumbers[0], 
                parseInt(cardNumbers[0].textContent) || 0, 
                stats.patients.active
            );
            
            this.animateNumber(cardNumbers[1], 
                parseInt(cardNumbers[1].textContent) || 0, 
                stats.appointments.today
            );
            
            this.animateNumber(cardNumbers[2], 
                parseInt(cardNumbers[2].textContent) || 0, 
                stats.patients.dueSoon
            );
            
            this.animateNumber(cardNumbers[3], 
                parseInt(cardNumbers[3].textContent) || 0, 
                stats.patients.highRisk
            );
        }

        const trendElements = document.querySelectorAll('.card-trend');
        if (trendElements.length >= 4) {
            const trends = this.calculateTrends(stats);
            trendElements[0].innerHTML = trends.patients;
            trendElements[1].innerHTML = trends.appointments;
            trendElements[2].innerHTML = trends.deliveries;
            trendElements[3].innerHTML = trends.highRisk;
        }
    }

    calculateTrends(stats) {
        // This would typically compare with historical data
        // For now, we'll generate reasonable trends based on current data
        return {
            patients: stats.patients.total > 10 ? '↗ 12% from last month' : '↗ New registrations',
            appointments: stats.appointments.today > 0 ? '↗ 8% from last week' : '— No appointments today',
            deliveries: '↘ 3% from last month',
            highRisk: stats.patients.highRisk > 0 ? '⚠ Requires attention' : '✅ All stable'
        };
    }

    // Removed system alerts functionality - alerts are now handled by notification system
    updateAlerts(stats) {
        // System alerts have been removed from dashboard
        // All alerts are now handled through the unified notification system
    }

    generateAlerts(stats) {
        // Alert generation moved to notification system
        return [];
    }

    // Create Lab Results Summary Widget
    updateLabResultsSummary(stats) {
        let labResultsWidget = document.getElementById('labResultsSummary');
        
        if (!labResultsWidget) {
            const dashboardLower = document.querySelector('.dashboard-lower-cards');
            if (!dashboardLower) return;
            
            labResultsWidget = document.createElement('div');
            labResultsWidget.id = 'labResultsSummary';
            labResultsWidget.className = 'summary-widget';
            dashboardLower.appendChild(labResultsWidget);
        }
        
        labResultsWidget.innerHTML = `
            <div class="widget-header">
                <h3><i class="fas fa-flask"></i> Lab Results Summary</h3>
                <a href="Lab Results.html" class="view-all">View All →</a>
            </div>
            <div class="summary-stats">
                <div class="stat-item ${stats.abnormal > 0 ? 'alert' : ''}">
                    <div class="stat-number">${stats.abnormal}</div>
                    <div class="stat-label">Abnormal</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">${stats.pending}</div>
                    <div class="stat-label">Pending</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">${stats.recent}</div>
                    <div class="stat-label">Recent (7d)</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">${stats.total}</div>
                    <div class="stat-label">Total</div>
                </div>
            </div>
            ${stats.requiresAction > 0 ? `
            <div class="action-required" style="padding: 10px; background: rgba(230, 57, 70, 0.1); border-radius: 8px; margin-top: 10px; font-size: 14px; color: #c53030;">
                <i class="fas fa-exclamation-triangle"></i>
                ${stats.requiresAction} result${stats.requiresAction > 1 ? 's require' : ' requires'} immediate attention
            </div>
            ` : ''}
        `;
    }

    // Create Medications Summary Widget
    updateMedicationsSummary(stats) {
        let medicationsWidget = document.getElementById('medicationsSummary');
        
        if (!medicationsWidget) {
            const dashboardLower = document.querySelector('.dashboard-lower-cards');
            if (!dashboardLower) return;
            
            medicationsWidget = document.createElement('div');
            medicationsWidget.id = 'medicationsSummary';
            medicationsWidget.className = 'summary-widget';
            dashboardLower.appendChild(medicationsWidget);
        }
        
        medicationsWidget.innerHTML = `
            <div class="widget-header">
                <h3><i class="fas fa-pills"></i> Medications Overview</h3>
                <a href="Medications.html" class="view-all">View All →</a>
            </div>
            <div class="summary-stats">
                <div class="stat-item">
                    <div class="stat-number">${stats.active}</div>
                    <div class="stat-label">Active</div>
                </div>
                <div class="stat-item ${stats.needsRefill > 0 ? 'warning' : ''}">
                    <div class="stat-number">${stats.needsRefill}</div>
                    <div class="stat-label">Need Refill</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">${stats.highPriority}</div>
                    <div class="stat-label">High Priority</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number">${stats.total}</div>
                    <div class="stat-label">Total</div>
                </div>
            </div>
            ${stats.needsRefill > 0 ? `
            <div class="refill-alert" style="padding: 10px; background: rgba(245, 158, 11, 0.1); border-radius: 8px; margin-top: 10px; font-size: 14px; color: #d69e2e;">
                <i class="fas fa-prescription-bottle-alt"></i>
                ${stats.needsRefill} medication${stats.needsRefill > 1 ? 's need' : ' needs'} refilling soon
            </div>
            ` : ''}
        `;
    }

    // Enhanced real-time listeners with proper data validation
    startBasicRealTimeListeners() {
        if (this.rtdb && this.firebase && this.firebase.database) {
            const { ref, onValue, off } = this.firebase.database;
            
            console.log('Dashboard: Setting up Firebase listeners for all modules...');
            
            // Patients listener
            const patientsRef = ref(this.rtdb, 'patients');
            this.firebaseListeners.patients = onValue(patientsRef, (snapshot) => {
                console.log('Dashboard: Patients data received');
                const data = snapshot.val() || {};
                
                // Validate and clean data
                const validatedData = {};
                Object.entries(data).forEach(([key, patient]) => {
                    if (this.validatePatientData(patient)) {
                        validatedData[key] = this.normalizePatientData(patient);
                    } else {
                        console.warn(`Invalid patient data for ${key}:`, patient);
                    }
                });
                
                this.dashboardData.patients = validatedData;
                this.loadingStates.patients = false;
                this.dataCache.lastUpdate.patients = Date.now();
                
                console.log(`Dashboard: Loaded ${Object.keys(validatedData).length} patients`);
                
                this.updateDashboardStats();
                this.updatePatientsDisplay();
                this.updateWeeklyTracker();
                this.updateDeliveryList();
            }, (error) => {
                console.error('Dashboard: Error fetching patients:', error);
                this.loadingStates.patients = false;
                this.showError('Failed to load patient data');
            });

            // Appointments listener
            const appointmentsRef = ref(this.rtdb, 'appointments');
            this.firebaseListeners.appointments = onValue(appointmentsRef, (snapshot) => {
                console.log('Dashboard: Appointments data received');
                const data = snapshot.val() || {};
                
                // Validate and clean data
                const validatedData = {};
                Object.entries(data).forEach(([key, appointment]) => {
                    if (this.validateAppointmentData(appointment)) {
                        validatedData[key] = this.normalizeAppointmentData(appointment);
                    } else {
                        console.warn(`Invalid appointment data for ${key}:`, appointment);
                    }
                });
                
                this.dashboardData.appointments = validatedData;
                this.loadingStates.appointments = false;
                this.dataCache.lastUpdate.appointments = Date.now();
                
                console.log(`Dashboard: Loaded ${Object.keys(validatedData).length} appointments`);
                
                this.updateDashboardStats();
                this.updateAppointmentsDisplay();
            }, (error) => {
                console.error('Dashboard: Error fetching appointments:', error);
                this.loadingStates.appointments = false;
                this.showError('Failed to load appointment data');
            });

            // Lab Results listener
            const labResultsRef = ref(this.rtdb, 'labResults');
            this.firebaseListeners.labResults = onValue(labResultsRef, (snapshot) => {
                console.log('Dashboard: Lab results data received');
                const data = snapshot.val() || {};
                
                // Validate and clean data
                const validatedData = {};
                Object.entries(data).forEach(([key, result]) => {
                    if (this.validateLabResultData(result)) {
                        validatedData[key] = this.normalizeLabResultData(result);
                    } else {
                        console.warn(`Invalid lab result data for ${key}:`, result);
                    }
                });
                
                this.dashboardData.labResults = validatedData;
                this.loadingStates.labResults = false;
                this.dataCache.lastUpdate.labResults = Date.now();
                
                console.log(`Dashboard: Loaded ${Object.keys(validatedData).length} lab results`);
                
                this.checkAbnormalLabResults();
                
                // Update unified dashboard if not using enhanced data manager
                if (!this.dataManager) {
                    this.updateLabResultsSummary(this.calculateLabResultsStats());
                }
            }, (error) => {
                console.error('Dashboard: Error fetching lab results:', error);
                this.loadingStates.labResults = false;
                this.showError('Failed to load lab results');
            });

            // Medications listener
            const medicationsRef = ref(this.rtdb, 'medications');
            this.firebaseListeners.medications = onValue(medicationsRef, (snapshot) => {
                console.log('Dashboard: Medications data received');
                const data = snapshot.val() || {};
                
                // Validate and clean data
                const validatedData = {};
                Object.entries(data).forEach(([key, medication]) => {
                    if (this.validateMedicationData(medication)) {
                        validatedData[key] = this.normalizeMedicationData(medication);
                    } else {
                        console.warn(`Invalid medication data for ${key}:`, medication);
                    }
                });
                
                this.dashboardData.medications = validatedData;
                this.loadingStates.medications = false;
                this.dataCache.lastUpdate.medications = Date.now();
                
                console.log(`Dashboard: Loaded ${Object.keys(validatedData).length} medications`);
                
                this.checkMedicationRefills();
                
                // Update unified dashboard if not using enhanced data manager
                if (!this.dataManager) {
                    this.updateMedicationsSummary(this.calculateMedicationStats());
                }
            }, (error) => {
                console.error('Dashboard: Error fetching medications:', error);
                this.loadingStates.medications = false;
                this.showError('Failed to load medication data');
            });
            
            console.log('Dashboard: All Firebase listeners set up successfully');
            
            // Check data status after 3 seconds
            setTimeout(() => {
                this.checkDataLoadingStatus();
            }, 3000);
        } else {
            console.log('Dashboard: No Firebase connection, loading mock data');
            this.loadMockData();
        }
    }

    // Check and report data loading status
    checkDataLoadingStatus() {
        const loadedData = {
            patients: Object.keys(this.dashboardData.patients).length,
            appointments: Object.keys(this.dashboardData.appointments).length,
            labResults: Object.keys(this.dashboardData.labResults).length,
            medications: Object.keys(this.dashboardData.medications).length
        };
        
        console.log('Dashboard: Data Loading Status:', loadedData);
        
        // Show notification if any module has no data
        const emptyModules = [];
        if (loadedData.patients === 0) emptyModules.push('Patients');
        if (loadedData.appointments === 0) emptyModules.push('Appointments');
        if (loadedData.labResults === 0) emptyModules.push('Lab Results');
        if (loadedData.medications === 0) emptyModules.push('Medications');
        
        if (emptyModules.length > 0) {
            console.log(`Dashboard: No data found in: ${emptyModules.join(', ')}`);
        } else {
            console.log('Dashboard: All modules have data loaded successfully');
        }
    }

    // Data validation methods
    validatePatientData(patient) {
        const requiredFields = ['patientId', 'fullName'];
        return requiredFields.every(field => patient && patient.hasOwnProperty(field));
    }

    validateAppointmentData(appointment) {
        const requiredFields = ['date', 'patientName'];
        return requiredFields.every(field => appointment && appointment.hasOwnProperty(field));
    }

    validateLabResultData(result) {
        const requiredFields = ['patientId', 'test'];
        return requiredFields.every(field => result && result.hasOwnProperty(field));
    }

    validateMedicationData(medication) {
        const requiredFields = ['patientId', 'medicationName'];
        return requiredFields.every(field => medication && medication.hasOwnProperty(field));
    }

    // Data normalization methods
    normalizePatientData(patient) {
        return {
            patientId: patient.patientId || '',
            fullName: patient.fullName || 'Unknown Patient',
            status: patient.status || 'active',
            lastVisit: patient.lastVisit || new Date().toISOString().split('T')[0],
            age: patient.age || 0,
            pregnancyWeek: patient.pregnancyWeek || 0,
            dueDate: patient.dueDate || '',
            appointmentCount: patient.appointmentCount || 0,
            labResultCount: patient.labResultCount || 0,
            activeMedicationCount: patient.activeMedicationCount || 0,
            ...patient
        };
    }

    normalizeAppointmentData(appointment) {
        const today = new Date().toISOString().split('T')[0];
        return {
            date: appointment.date || today,
            time: appointment.time || appointment.date || new Date().toISOString(),
            patientName: appointment.patientName || appointment.name || 'Unknown',
            purpose: appointment.purpose || appointment.type || 'General Checkup',
            status: appointment.status || 'scheduled',
            isToday: appointment.date === today,
            urgency: appointment.urgency || 'normal',
            ...appointment
        };
    }

    normalizeLabResultData(result) {
        return {
            patientId: result.patientId || '',
            patientName: result.patientName || 'Unknown',
            test: result.test || 'Unknown Test',
            status: result.status || 'normal',
            date: result.date || new Date().toISOString().split('T')[0],
            requiresAction: result.requiresAction || false,
            ...result
        };
    }

    normalizeMedicationData(medication) {
        return {
            patientId: medication.patientId || '',
            patientName: medication.patientName || 'Unknown',
            medicationName: medication.medicationName || 'Unknown Medication',
            status: medication.status || 'active',
            refillReminder: medication.refillReminder || 7,
            startDate: medication.startDate || new Date().toISOString().split('T')[0],
            duration: medication.duration || 30,
            ...medication
        };
    }

    // Calculate stats for basic listeners
    calculateLabResultsStats() {
        const results = Object.values(this.dashboardData.labResults);
        const today = new Date();
        const sevenDaysAgo = new Date(today);
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
        
        return {
            abnormal: results.filter(r => r.status === 'abnormal').length,
            pending: results.filter(r => r.status === 'pending').length,
            recent: results.filter(r => new Date(r.date) >= sevenDaysAgo).length,
            total: results.length,
            requiresAction: results.filter(r => r.requiresAction).length
        };
    }

    calculateMedicationStats() {
        const medications = Object.values(this.dashboardData.medications);
        const needsRefill = [];
        
        medications.forEach(medication => {
            if (medication.status === 'active' && medication.refillReminder) {
                const startDate = new Date(medication.startDate);
                const endDate = new Date(startDate);
                endDate.setDate(endDate.getDate() + medication.duration);
                const reminderDate = new Date(endDate);
                reminderDate.setDate(reminderDate.getDate() - medication.refillReminder);
                
                if (reminderDate <= new Date()) {
                    needsRefill.push(medication);
                }
            }
        });
        
        return {
            active: medications.filter(m => m.status === 'active').length,
            needsRefill: needsRefill.length,
            highPriority: medications.filter(m => m.priority === 'high').length,
            total: medications.length
        };
    }

    // Enhanced patients display with related data
    updateEnhancedPatientsDisplay() {
        const tables = document.querySelectorAll('.dashboard-lower-cards table');
        if (tables.length === 0) return;

        const patientsTable = tables[0];
        const tbody = patientsTable.querySelector('tbody');
        if (!tbody) return;

        const patients = Object.entries(this.dashboardData.patients || {})
            .map(([key, patient]) => {
                // Calculate risk indicators
                const dueDate = new Date(patient.dueDate);
                const today = new Date();
                const daysUntilDue = Math.ceil((dueDate - today) / 86400000);
                
                return {
                    key,
                    ...patient,
                    daysUntilDue,
                    isHighRisk: patient.status === 'high-risk' || daysUntilDue <= 3,
                    isDueSoon: daysUntilDue <= 7 && daysUntilDue > 0,
                    isOverdue: daysUntilDue < 0 && patient.status !== 'Completed'
                };
            })
            .sort((a, b) => {
                // Prioritize by urgency
                if (a.isOverdue && !b.isOverdue) return -1;
                if (b.isOverdue && !a.isOverdue) return 1;
                if (a.isHighRisk && !b.isHighRisk) return -1;
                if (b.isHighRisk && !a.isHighRisk) return 1;
                if (a.isDueSoon && !b.isDueSoon) return -1;
                if (b.isDueSoon && !a.isDueSoon) return 1;
                
                return new Date(b.lastVisit || 0) - new Date(a.lastVisit || 0);
            })
            .slice(0, 5);

        if (patients.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" class="empty-state">
                        <i class="fas fa-user-friends"></i>
                        <p>No patients found</p>
                    </td>
                </tr>
            `;
            return;
        }

        tbody.innerHTML = patients.map(patient => `
            <tr>
                <td>
                    <div class="patient-info-enhanced">
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <span class="patient-indicator ${
                                patient.isOverdue ? 'indicator-high-risk' :
                                patient.isHighRisk ? 'indicator-high-risk' :
                                patient.isDueSoon ? 'indicator-due-soon' : 
                                'indicator-normal'
                            }"></span>
                            <span class="patient-name">${this.sanitizeHTML(patient.fullName)}</span>
                        </div>
                        <div class="patient-meta">
                            <span>ID: ${patient.patientId}</span>
                            ${patient.daysUntilDue !== null && !isNaN(patient.daysUntilDue) ? 
                                `<span>${patient.daysUntilDue > 0 ? 
                                    `Due in ${patient.daysUntilDue}d` : 
                                    patient.daysUntilDue === 0 ? 'Due today!' : 
                                    `${Math.abs(patient.daysUntilDue)}d overdue`
                                }</span>` : ''
                            }
                        </div>
                    </div>
                </td>
                <td>
                    <span class="status-badge status-${patient.status} ${patient.isHighRisk ? 'high-risk' : patient.isDueSoon ? 'due-soon' : ''}">
                        ${this.formatStatus(patient.status)}
                        ${patient.isOverdue ? ' ⚠️' : patient.isHighRisk ? ' 🚨' : patient.isDueSoon ? ' ⏰' : ''}
                    </span>
                </td>
                <td>
                    <div class="date-info">
                        ${this.formatDate(patient.lastVisit)}
                    </div>
                </td>
                <td>
                    <div class="actions-enhanced">
                        <button class="action-btn" onclick="window.pregnaCareApp.showEnhancedPatientDetails('${patient.patientId}')" title="View Details">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="action-btn" onclick="window.pregnaCareApp.scheduleAppointment('${patient.patientId}')" title="Schedule Appointment">
                            <i class="fas fa-calendar-plus"></i>
                        </button>
                        ${patient.isHighRisk || patient.isDueSoon ? `
                        <button class="action-btn urgent" onclick="window.pregnaCareApp.orderLabTest('${patient.patientId}')" title="Order Lab Test">
                            <i class="fas fa-flask"></i>
                        </button>
                        ` : ''}
                    </div>
                </td>
            </tr>
        `).join('');
    }

    // Enhanced appointments display
    updateEnhancedAppointmentsDisplay() {
        const tables = document.querySelectorAll('.dashboard-lower-cards table');
        if (tables.length < 2) return;

        const appointmentsTable = tables[1];
        const tbody = appointmentsTable.querySelector('tbody');
        if (!tbody) return;

        const today = new Date().toISOString().split('T')[0];
        const todayAppointments = Object.entries(this.dashboardData.appointments || {})
            .map(([key, apt]) => ({
                key,
                ...apt,
                appointmentTime: new Date(apt.time || apt.date),
                isToday: (apt.date === today) || apt.isToday
            }))
            .filter(apt => apt.isToday)
            .sort((a, b) => a.appointmentTime - b.appointmentTime)
            .slice(0, 5);

        if (todayAppointments.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="3" style="text-align: center; padding: 20px; color: #666;">
                        <i class="fas fa-calendar-check" style="font-size: 24px; margin-bottom: 8px; color: #10b981;"></i>
                        <br>No appointments scheduled for today
                    </td>
                </tr>
            `;
            return;
        }

        tbody.innerHTML = todayAppointments.map(appointment => {
            const timeString = appointment.appointmentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            const isUpcoming = appointment.appointmentTime > new Date();
            
            return `
                <tr class="${appointment.urgency === 'urgent' ? 'urgent-appointment' : ''}">
                    <td>
                        <div style="display: flex; align-items: center; gap: 6px;">
                            ${isUpcoming ? '<i class="fas fa-clock" style="color: #10b981; font-size: 12px;"></i>' : 
                              '<i class="fas fa-clock" style="color: #666; font-size: 12px;"></i>'}
                            ${timeString}
                        </div>
                    </td>
                    <td>
                        <div class="patient-info-enhanced">
                            <span>${this.sanitizeHTML(appointment.patientName || appointment.name)}</span>
                            ${appointment.patientData ? 
                                `<span class="patient-meta">Week ${appointment.patientData.pregnancyWeek || 'N/A'}</span>` : 
                            ''}
                        </div>
                    </td>
                    <td>
                        ${this.sanitizeHTML(appointment.purpose || appointment.type)}
                        ${appointment.urgency === 'urgent' ? ' <i class="fas fa-exclamation-triangle" style="color: #e63946;"></i>' : ''}
                    </td>
                </tr>
            `;
        }).join('');
    }

    // Basic patients display
    updatePatientsDisplay() {
        // Use enhanced display if available
        if (this.dataManager) {
            this.updateEnhancedPatientsDisplay();
        } else {
            // Basic display logic
            const tables = document.querySelectorAll('.dashboard-lower-cards table');
            if (tables.length === 0) return;

            const patientsTable = tables[0];
            const tbody = patientsTable.querySelector('tbody');
            if (!tbody) return;

            const patients = Object.entries(this.dashboardData.patients)
                .sort(([,a], [,b]) => new Date(b.lastVisit) - new Date(a.lastVisit))
                .slice(0, 5);

            if (patients.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="4" class="empty-state">
                            <i class="fas fa-user-friends"></i>
                            <p>No patients found</p>
                        </td>
                    </tr>
                `;
                return;
            }

            tbody.innerHTML = patients.map(([id, patient]) => `
                <tr>
                    <td>${this.sanitizeHTML(patient.fullName)}</td>
                    <td><span class="status-badge status-${patient.status}">${this.formatStatus(patient.status)}</span></td>
                    <td>${this.formatDate(patient.lastVisit)}</td>
                    <td><i class="fas fa-eye" style="cursor: pointer; color: var(--heart-red);" onclick="window.pregnaCareApp.showPatientDetails('${id}')"></i></td>
                </tr>
            `).join('');
        }
    }

    // Basic appointments display
    updateAppointmentsDisplay() {
        if (this.dataManager) {
            this.updateEnhancedAppointmentsDisplay();
        } else {
            // Basic appointments display
            const tables = document.querySelectorAll('.dashboard-lower-cards table');
            if (tables.length < 2) return;

            const appointmentsTable = tables[1];
            const tbody = appointmentsTable.querySelector('tbody');
            if (!tbody) return;

            const today = new Date().toISOString().split('T')[0];
            const todayAppointments = Object.entries(this.dashboardData.appointments)
                .filter(([,apt]) => apt.date === today || apt.isToday)
                .sort(([,a], [,b]) => this.parseTime(a.time) - this.parseTime(b.time))
                .slice(0, 5);

            if (todayAppointments.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="3" class="empty-state">
                            <i class="fas fa-calendar-check"></i>
                            <p>No appointments today</p>
                        </td>
                    </tr>
                `;
                return;
            }

            tbody.innerHTML = todayAppointments.map(([id, appointment]) => `
                <tr>
                    <td>${new Date(appointment.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</td>
                    <td>${this.sanitizeHTML(appointment.patientName || appointment.name)}</td>
                    <td>${this.sanitizeHTML(appointment.purpose || appointment.type)}</td>
                </tr>
            `).join('');
        }
    }

    // Update dashboard statistics
    updateDashboardStats() {
        const stats = this.calculateDashboardStats();
        
        const cardNumbers = document.querySelectorAll('.card-number');
        if (cardNumbers.length >= 4) {
            this.animateNumber(cardNumbers[0], parseInt(cardNumbers[0].textContent) || 0, stats.newPatients);
            this.animateNumber(cardNumbers[1], parseInt(cardNumbers[1].textContent) || 0, stats.appointments);
            this.animateNumber(cardNumbers[2], parseInt(cardNumbers[2].textContent) || 0, stats.deliveries);
            this.animateNumber(cardNumbers[3], parseInt(cardNumbers[3].textContent) || 0, stats.highRisk);
        }

        // Update trends
        const trendElements = document.querySelectorAll('.card-trend');
        if (trendElements.length >= 4) {
            trendElements[0].innerHTML = stats.newPatients > 0 ? '↗ Active patients' : '— No active patients';
            trendElements[1].innerHTML = stats.appointments > 0 ? `↗ ${stats.appointments} today` : '— No appointments today';
            trendElements[2].innerHTML = stats.deliveries > 0 ? `${stats.deliveries} due soon` : '— None due soon';
            trendElements[3].innerHTML = stats.highRisk > 0 ? '⚠ Requires attention' : '✅ All stable';
        }
    }

    calculateDashboardStats() {
        const today = new Date().toISOString().split('T')[0];
        const patients = Object.values(this.dashboardData.patients);
        const todayAppointments = Object.values(this.dashboardData.appointments)
            .filter(apt => apt.date === today || apt.isToday);
        
        // Calculate deliveries (patients due within 30 days)
        const deliveries = patients.filter(p => {
            if (!p.dueDate) return false;
            const dueDate = new Date(p.dueDate);
            const today = new Date();
            const daysUntilDue = Math.ceil((dueDate - today) / 86400000);
            return daysUntilDue >= 0 && daysUntilDue <= 30;
        }).length;
        
        return {
            newPatients: patients.filter(p => p.status === 'active' || p.status === 'Ongoing').length,
            appointments: todayAppointments.length,
            deliveries: deliveries,
            highRisk: patients.filter(p => p.status === 'high-risk').length
        };
    }

    updateWeeklyTracker() {
        const patients = Object.values(this.dashboardData.patients);
        const trimesterCounts = {
            first: 0,
            second: 0,
            third: 0
        };

        patients.forEach(patient => {
            const week = patient.pregnancyWeek || 0;
            if (week > 0 && week <= 12) trimesterCounts.first++;
            else if (week > 12 && week <= 27) trimesterCounts.second++;
            else if (week > 27) trimesterCounts.third++;
        });

        const highRiskCount = patients.filter(p => p.status === 'high-risk').length;
        const dueThisMonth = patients.filter(p => {
            if (!p.dueDate) return false;
            const dueDate = new Date(p.dueDate);
            const today = new Date();
            const currentMonth = today.getMonth();
            const dueMonth = dueDate.getMonth();
            return dueMonth === currentMonth && dueDate.getFullYear() === today.getFullYear();
        }).length;

        const weeklyTracker = document.querySelector('.weekly-tracker ul');
        if (weeklyTracker) {
            weeklyTracker.innerHTML = `
                <li>1st Trimester - <strong>${trimesterCounts.first}</strong> Patients</li>
                <li>2nd Trimester - <strong>${trimesterCounts.second}</strong> Patients</li>
                <li>3rd Trimester - <strong>${trimesterCounts.third}</strong> Patients</li>
                <li>High Risk - <strong>${highRiskCount}</strong> Patients</li>
                <li>Due this month - <strong>${dueThisMonth}</strong> Patients</li>
            `;
        }

        // Update progress bars
        const total = patients.length || 1;
        const progressContainers = document.querySelectorAll('.weekly-tracker .progress-bar');
        if (progressContainers.length >= 3) {
            const progressBars = progressContainers[0].parentElement.querySelectorAll('.progress');
            if (progressBars.length >= 3) {
                progressBars[0].style.width = `${(trimesterCounts.first / total) * 100}%`;
                progressBars[1].style.width = `${(trimesterCounts.second / total) * 100}%`;
                progressBars[2].style.width = `${(trimesterCounts.third / total) * 100}%`;
                
                const percentageSpans = progressContainers[0].parentElement.querySelectorAll('span:last-child');
                if (percentageSpans.length >= 3) {
                    percentageSpans[0].textContent = `${Math.round((trimesterCounts.first / total) * 100)}%`;
                    percentageSpans[1].textContent = `${Math.round((trimesterCounts.second / total) * 100)}%`;
                    percentageSpans[2].textContent = `${Math.round((trimesterCounts.third / total) * 100)}%`;
                }
            }
        }
    }

    updateDeliveryList() {
        const deliveryList = document.querySelector('.delivery-list');
        if (!deliveryList) return;

        // Get patients due within 30 days
        const upcomingDeliveries = Object.values(this.dashboardData.patients)
            .filter(patient => {
                if (!patient.dueDate) return false;
                const dueDate = new Date(patient.dueDate);
                const today = new Date();
                const daysUntilDue = Math.ceil((dueDate - today) / 86400000);
                return daysUntilDue >= 0 && daysUntilDue <= 30;
            })
            .sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate))
            .slice(0, 5);

        if (upcomingDeliveries.length === 0) {
            deliveryList.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-baby"></i>
                    <p>No deliveries expected in the next 30 days</p>
                </div>
            `;
            return;
        }

        deliveryList.innerHTML = upcomingDeliveries.map(patient => {
            const dueDate = new Date(patient.dueDate);
            const today = new Date();
            const daysUntilDue = Math.ceil((dueDate - today) / 86400000);
            const isUrgent = daysUntilDue <= 7;
            
            return `
                <div class="delivery-item" style="display: flex; justify-content: space-between; align-items: center; padding: 10px; border-bottom: 1px solid #eee;">
                    <div>
                        <div class="delivery-date" style="font-weight: 600; color: var(--deep-red);">${this.formatDate(patient.dueDate)}</div>
                        <div style="font-size: 14px; color: #666;">${this.sanitizeHTML(patient.fullName)}</div>
                    </div>
                    ${isUrgent ? '<div class="delivery-urgent" style="background: #e63946; color: white; padding: 2px 8px; border-radius: 4px; font-size: 12px;">URGENT</div>' : ''}
                </div>
            `;
        }).join('');
    }

    async checkDashboardAlerts() {
        if (!window.NotificationIntegration || !this.dashboardData.patients) return;

        const highRiskPatients = Object.values(this.dashboardData.patients)
            .filter(p => p.status === 'high-risk');
        
        if (highRiskPatients.length > 0) {
            for (const patient of highRiskPatients) {
                await window.NotificationIntegration.patients.notifyApproachingDueDate(patient);
            }
        }
    }

    async checkAbnormalLabResults() {
        if (!window.NotificationIntegration || !this.dashboardData.labResults) return;

        const abnormalResults = Object.values(this.dashboardData.labResults)
            .filter(result => result.status === 'abnormal');
        
        if (abnormalResults.length > 0) {
            abnormalResults.forEach(result => {
                window.NotificationIntegration.labResults.notifyAbnormalResult(result);
            });
        }
    }

    async checkMedicationRefills() {
        if (!window.NotificationIntegration || !this.dashboardData.medications) return;

        const refillsNeeded = [];
        
        Object.values(this.dashboardData.medications).forEach(medication => {
            if (medication.refillReminder && medication.status === 'active') {
                const startDate = new Date(medication.startDate);
                const endDate = new Date(startDate);
                endDate.setDate(endDate.getDate() + medication.duration);
                const reminderDate = new Date(endDate);
                reminderDate.setDate(reminderDate.getDate() - medication.refillReminder);
                
                if (reminderDate <= new Date()) {
                    refillsNeeded.push(medication);
                }
            }
        });
        
        if (refillsNeeded.length > 0) {
            refillsNeeded.forEach(medication => {
                window.NotificationIntegration.medications.notifyRefillReminder({
                    ...medication,
                    daysUntilRefill: medication.refillReminder
                });
            });
        }
    }

    // Event Listeners Setup
    setupEventListeners() {
        this.setupDropdowns();
        this.setupSearch();
        this.setupNavigation();
        this.setupTimeFilter();
        this.setupLogout();
    }

    setupDropdowns() {
        const notifIcon = document.getElementById('notifIcon');
        const helpIcon = document.getElementById('helpIcon');
        const notifDropdown = document.getElementById('notifDropdown');
        const helpDropdown = document.getElementById('helpDropdown');

        if (notifIcon && notifDropdown) {
            notifIcon.addEventListener('click', (e) => {
                e.stopPropagation();
                this.toggleDropdown(notifDropdown);
                if (helpDropdown) helpDropdown.classList.remove('show');
            });
        }

        if (helpIcon && helpDropdown) {
            helpIcon.addEventListener('click', (e) => {
                e.stopPropagation();
                this.toggleDropdown(helpDropdown);
                if (notifDropdown) notifDropdown.classList.remove('show');
            });

            const emergencyItem = helpDropdown.querySelector('li:first-child');
            if (emergencyItem) {
                emergencyItem.style.cursor = 'pointer';
                emergencyItem.addEventListener('click', () => {
                    this.callEmergency();
                });
            }
        }

        // Close dropdowns when clicking outside
        document.addEventListener('click', () => {
            document.querySelectorAll('.dropdown').forEach(dropdown => {
                dropdown.classList.remove('show');
            });
        });
    }

    setupSearch() {
        const searchInput = document.querySelector('.search input');
        if (!searchInput) return;

        searchInput.addEventListener('input', (e) => {
            const query = e.target.value.trim();
            
            if (this.searchTimeout) {
                clearTimeout(this.searchTimeout);
            }

            this.searchTimeout = setTimeout(() => {
                this.performSearch(query);
            }, 300);
        });

        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                this.performSearch(e.target.value.trim());
            }
        });
    }

    setupNavigation() {
        const navLinks = document.querySelectorAll('.nav a');
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                if (link.getAttribute('href') === 'Dashboard.html') {
                    e.preventDefault();
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                    this.showTopbarPreserveDesign();
                }
                navLinks.forEach(l => l.classList.remove('active'));
                link.classList.add('active');
            });
        });
    }

    setupTimeFilter() {
        const timeFilter = document.querySelector('#timeFilter');
        if (timeFilter) {
            timeFilter.addEventListener('change', (e) => {
                console.log('Time filter changed to:', e.target.value);
                this.updateDashboardByTimeFilter(e.target.value);
            });
        }
    }

    setupLogout() {
        const logoutElements = document.querySelectorAll('.logout, [href*="logout"]');
        logoutElements.forEach(element => {
            element.addEventListener('click', async (e) => {
                e.preventDefault();
                if (confirm('Are you sure you want to logout?')) {
                    try {
                        if (this.auth && this.auth.signOut) {
                            await this.auth.signOut();
                        } else {
                            window.location.href = 'Admin login.html';
                        }
                    } catch (error) {
                        console.error('Logout error:', error);
                        window.location.href = 'Admin login.html';
                    }
                }
            });
        });
    }

    // Loading States Management
    showLoadingStates() {
        const tables = document.querySelectorAll('.dashboard-lower-cards table tbody');
        tables.forEach(tbody => {
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" class="data-loading" style="text-align: center; padding: 40px;">
                        <div style="display: inline-block;">Loading data...</div>
                    </td>
                </tr>
            `;
        });
    }

    hideLoadingStates() {
        // Loading states are automatically hidden when data is displayed
        console.log('Dashboard: All data loaded');
    }

    // Utility Methods
    toggleDropdown(dropdown) {
        dropdown.classList.toggle('show');
    }

    performSearch(query) {
        console.log('Searching for:', query);
        
        if (!query) {
            // Clear any existing search highlights
            document.querySelectorAll('.dashboard-lower-cards table tbody tr').forEach(row => {
                row.style.display = '';
            });
            return;
        }
        
        const lowerQuery = query.toLowerCase();
        let hasResults = false;
        
        // Search in patient and appointment tables
        document.querySelectorAll('.dashboard-lower-cards table tbody tr').forEach(row => {
            const text = row.textContent.toLowerCase();
            const shouldShow = text.includes(lowerQuery);
            row.style.display = shouldShow ? '' : 'none';
            if (shouldShow) hasResults = true;
        });
        
        if (!hasResults) {
            this.showNotification('No results found for your search', 'info');
        }
    }

    animateNumber(element, from, to) {
        const duration = 1000;
        const start = Date.now();
        
        const timer = setInterval(() => {
            const progress = (Date.now() - start) / duration;
            
            if (progress >= 1) {
                element.textContent = to;
                clearInterval(timer);
            } else {
                const current = Math.floor(from + (to - from) * this.easeOutQuart(progress));
                element.textContent = current;
            }
        }, 16);
    }

    easeOutQuart(t) {
        return 1 - (--t) * t * t * t;
    }

    formatDate(date) {
        if (!date) return 'N/A';
        const d = new Date(date);
        if (isNaN(d.getTime())) return 'Invalid Date';
        
        return d.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    formatStatus(status) {
        const statusMap = {
            'active': 'Active',
            'high-risk': 'High Risk',
            'due-soon': 'Due Soon',
            'inactive': 'Inactive',
            'pending': 'Pending',
            'Ongoing': 'Ongoing',
            'Completed': 'Completed',
            'scheduled': 'Scheduled',
            'cancelled': 'Cancelled',
            'normal': 'Normal',
            'abnormal': 'Abnormal'
        };
        return statusMap[status] || status.charAt(0).toUpperCase() + status.slice(1);
    }

    parseTime(timeStr) {
        if (timeStr instanceof Date) {
            return timeStr.getHours() * 60 + timeStr.getMinutes();
        }
        
        const date = new Date(timeStr);
        if (!isNaN(date.getTime())) {
            return date.getHours() * 60 + date.getMinutes();
        }
        
        // Handle "HH:MM AM/PM" format
        const [time, period] = timeStr.split(' ');
        let [hours, minutes] = time.split(':').map(Number);
        if (period === 'PM' && hours !== 12) hours += 12;
        if (period === 'AM' && hours === 12) hours = 0;
        return hours * 60 + minutes;
    }

    updateCurrentDate() {
        const today = new Date();
        const dateString = today.toLocaleDateString('en-US', {
            weekday: 'long',
            month: 'long',
            day: 'numeric',
            year: 'numeric'
        });
        
        document.querySelectorAll('[data-current-date]').forEach(element => {
            element.textContent = dateString;
        });
    }

    getInitials(name) {
        if (!name) return 'AD';
        
        // Handle email addresses
        if (name.includes('@')) {
            return name.split('@')[0].substring(0, 2).toUpperCase();
        }
        
        // Handle regular names
        const words = name.trim().split(' ').filter(word => word.length > 0);
        if (words.length === 1) {
            return words[0].substring(0, 2).toUpperCase();
        } else {
            return (words[0][0] + (words[1] ? words[1][0] : words[0][1])).toUpperCase();
        }
    }

    sanitizeHTML(str) {
        if (!str) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    showSuccess(message) {
        this.showNotification(message, 'success');
    }

    showError(message) {
        this.showNotification(message, 'error');
    }

    showNotification(message, type = 'info') {
        if (window.showNotification) {
            window.showNotification(message, type, 'dashboard');
        } else {
            console.log(`Dashboard notification [${type}]:`, message);
            
            // Fallback notification
            const notification = document.createElement('div');
            notification.className = `notification notification-${type}`;
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 15px 20px;
                background: ${type === 'success' ? '#10b981' : type === 'error' ? '#e63946' : '#3b82f6'};
                color: white;
                border-radius: 8px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                z-index: 9999;
                animation: slideIn 0.3s ease-out;
            `;
            notification.textContent = message;
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.style.animation = 'fadeOut 0.3s ease-out';
                setTimeout(() => notification.remove(), 300);
            }, 3000);
        }
    }

    redirectToLogin() {
        window.location.href = 'Admin login.html';
    }

    updateUserDisplay(profile) {
        const userElement = document.querySelector('.user');
        if (!userElement) return;

        if (profile) {
            let fullName = profile.fullName || 
                          (profile.firstName && profile.lastName ? `${profile.firstName} ${profile.lastName}` : '') ||
                          profile.name ||
                          profile.email ||
                          'Admin User';
            
            const initials = this.getInitials(fullName);
            
            userElement.innerHTML = `
                <div class="circle">${this.sanitizeHTML(initials)}</div>
                <p>${this.sanitizeHTML(fullName)}<br>
                <span>${this.sanitizeHTML(profile.role || 'Administrator')}</span></p>
            `;
            
            console.log('Dashboard: User display updated -', fullName);
        } else {
            userElement.innerHTML = `
                <div class="circle">--</div>
                <p>Loading...<br><span>Admin</span></p>
            `;
        }
    }

    // Public API Methods
    async showPatientDetails(patientId) {
        const patient = this.dashboardData.patients[patientId];
        if (!patient) {
            this.showError('Patient not found');
            return;
        }

        console.log('Showing patient details:', patient);
        
        const details = `
Patient Details:

Name: ${patient.fullName}
ID: ${patient.patientId}
Age: ${patient.age || 'N/A'}
Status: ${this.formatStatus(patient.status)}
Pregnancy Week: ${patient.pregnancyWeek || 'N/A'}
Last Visit: ${this.formatDate(patient.lastVisit)}

Trimester: ${patient.pregnancyWeek <= 12 ? '1st' : patient.pregnancyWeek <= 27 ? '2nd' : '3rd'}
Est. Due Date: ${patient.dueDate ? this.formatDate(patient.dueDate) : this.calculateDueDate(patient.pregnancyWeek)}
        `;
        
        alert(details);

        // Send notification if available
        if (window.NotificationIntegration) {
            window.NotificationIntegration.patients.notifyNewPatient({
                patientId: patient.patientId,
                fullName: patient.fullName
            });
        }
    }

    async showEnhancedPatientDetails(patientId) {
        if (this.dataManager) {
            const completeData = this.dataManager.getPatientCompleteData(patientId);
            
            if (!completeData) {
                this.showError('Patient not found');
                return;
            }
            
            const { patient, appointments, labResults, medications } = completeData;
            
            const details = `
Enhanced Patient Details:

Name: ${patient.fullName}
ID: ${patient.patientId}
Status: ${this.formatStatus(patient.status)}

Related Data:
- Appointments: ${appointments.length} (${appointments.filter(a => a.isUpcoming).length} upcoming)
- Lab Results: ${labResults.length} (${labResults.filter(l => l.isAbnormal).length} abnormal)
- Medications: ${medications.length} (${medications.filter(m => m.isActive).length} active)

Recent Activity:
${this.formatRecentActivity(appointments, labResults, medications)}
            `;
            
            alert(details);
        } else {
            this.showPatientDetails(patientId);
        }
    }

    formatRecentActivity(appointments, labResults, medications) {
        const activities = [];
        
        appointments
            .filter(a => a.isUpcoming)
            .slice(0, 2)
            .forEach(apt => {
                activities.push(`📅 Appointment on ${this.formatDate(apt.time)}`);
            });
        
        labResults
            .filter(l => l.isAbnormal)
            .slice(0, 2)
            .forEach(lab => {
                activities.push(`🔬 Abnormal ${lab.test} result`);
            });
        
        medications
            .filter(m => m.isActive && m.priorityLevel === 3)
            .slice(0, 2)
            .forEach(med => {
                activities.push(`💊 High-priority: ${med.medicationName}`);
            });
        
        return activities.length > 0 ? activities.join('\n') : 'No recent activity';
    }

    calculateDueDate(currentWeek) {
        if (!currentWeek || currentWeek <= 0) return 'N/A';
        const weeksRemaining = 40 - currentWeek;
        const dueDate = new Date();
        dueDate.setDate(dueDate.getDate() + (weeksRemaining * 7));
        return this.formatDate(dueDate);
    }

    callEmergency() {
        const emergencyNumber = '+639171234567';
        if (confirm(`Call emergency number ${emergencyNumber}?`)) {
            window.location.href = `tel:${emergencyNumber}`;
            
            // Log emergency call
            if (window.NotificationIntegration) {
                window.NotificationIntegration.patients.notifyNewPatient({
                    patientId: 'emergency-' + Date.now(),
                    fullName: 'Emergency Call Initiated'
                });
            }
        }
    }

    async updateDashboardByTimeFilter(timeFrame) {
        console.log('Updating dashboard for time frame:', timeFrame);
        this.showNotification(`Loading ${timeFrame} data...`, 'info');
        
        // In a real implementation, this would filter the data
        // For now, we'll just update the stats
        setTimeout(() => {
            this.updateDashboardStats();
            this.showSuccess(`Dashboard updated to show ${timeFrame} data`);
        }, 500);
    }

    // Quick action methods
    scheduleAppointment(patientId) {
        sessionStorage.setItem('scheduleForPatient', patientId);
        window.location.href = 'Appointments.html';
    }

    orderLabTest(patientId) {
        sessionStorage.setItem('orderForPatient', patientId);
        window.location.href = 'Lab Results.html';
    }

    // Public methods for manual control
    toggleSearchHeader() {
        console.log('Dashboard: Manual toggle triggered');
        if (this.topBarConfig.isHidden) {
            this.showTopbarPreserveDesign();
        } else {
            this.hideTopbarPreserveDesign();
        }
        
        this.showNotification(`Topbar ${this.topBarConfig.isHidden ? 'shown' : 'hidden'} manually`, 'info');
    }

    scrollToTop() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
        this.showTopbarPreserveDesign();
    }

    // Load initial data (fallback for when Firebase is not available)
    loadInitialData() {
        if (Object.keys(this.dashboardData.patients).length === 0 && !this.rtdb) {
            this.loadMockData();
        }
    }

    // Load mock data for testing
    loadMockData() {
        console.log('Dashboard: Loading mock data for testing');
        
        this.dashboardData.patients = {
            'patient1': {
                patientId: 'PT001',
                fullName: 'Emma Smith',
                status: 'Ongoing',
                lastVisit: '2025-01-15',
                age: 28,
                pregnancyWeek: 24,
                dueDate: '2025-04-20',
                appointmentCount: 3,
                labResultCount: 2,
                activeMedicationCount: 1
            },
            'patient2': {
                patientId: 'PT002',
                fullName: 'Maria Santos',
                status: 'high-risk',
                lastVisit: '2025-01-16',
                age: 32,
                pregnancyWeek: 30,
                dueDate: '2025-03-15',
                appointmentCount: 5,
                labResultCount: 4,
                activeMedicationCount: 3
            },
            'patient3': {
                patientId: 'PT003',
                fullName: 'Anna Johnson',
                status: 'Ongoing',
                lastVisit: '2025-01-14',
                age: 26,
                pregnancyWeek: 16,
                dueDate: '2025-06-01',
                appointmentCount: 2,
                labResultCount: 1,
                activeMedicationCount: 0
            }
        };

        const today = new Date();
        this.dashboardData.appointments = {
            'apt1': {
                date: today.toISOString().split('T')[0],
                time: new Date(today.getTime() + 1 * 60 * 60 * 1000).toISOString(),
                patientName: 'Emma Smith',
                purpose: 'Routine Checkup',
                status: 'scheduled',
                isToday: true,
                urgency: 'normal'
            },
            'apt2': {
                date: today.toISOString().split('T')[0],
                time: new Date(today.getTime() + 2 * 60 * 60 * 1000).toISOString(),
                patientName: 'Maria Santos',
                purpose: 'High-risk Follow-up',
                status: 'scheduled',
                isToday: true,
                urgency: 'urgent'
            }
        };

        this.dashboardData.labResults = {
            'lab1': {
                patientId: 'PT002',
                patientName: 'Maria Santos',
                test: 'Glucose Test',
                status: 'abnormal',
                date: today.toISOString().split('T')[0],
                requiresAction: true
            }
        };

        this.dashboardData.medications = {
            'med1': {
                patientId: 'PT002',
                patientName: 'Maria Santos',
                medicationName: 'Prenatal Vitamins',
                status: 'active',
                refillReminder: 5,
                startDate: '2025-01-01',
                duration: 90
            }
        };

        // Hide loading states
        this.loadingStates = {
            patients: false,
            appointments: false,
            labResults: false,
            medications: false
        };

        // Update all displays
        this.updateDashboardStats();
        this.updateEnhancedPatientsDisplay();
        this.updateEnhancedAppointmentsDisplay();
        this.updateWeeklyTracker();
        this.updateDeliveryList();
        
        // Create basic stats for enhanced features
        if (!this.dataManager) {
            const mockStats = {
                patients: { active: 3, highRisk: 1, dueSoon: 2, overdue: 0, total: 3 },
                appointments: { today: 2, pending: 2, urgent: 1 },
                labResults: { abnormal: 1, pending: 0, recent: 1, total: 1, requiresAction: 1 },
                medications: { active: 1, needsRefill: 1, highPriority: 0, total: 1 }
            };
            
            this.updateStatCards(mockStats);
            // System alerts removed - notifications handled by unified system
            this.updateLabResultsSummary(mockStats.labResults);
            this.updateMedicationsSummary(mockStats.medications);
        }
        
        this.showNotification('Dashboard loaded with demo data', 'info');
    }

    // Add method to display data fetching status
    displayDataFetchingStatus() {
        const statusContainer = document.createElement('div');
        statusContainer.id = 'dataFetchingStatus';
        statusContainer.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: white;
            border-radius: 12px;
            padding: 15px 20px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            z-index: 1000;
            min-width: 250px;
            display: none;
        `;
        
        const modules = ['patients', 'appointments', 'labResults', 'medications'];
        const statusHTML = modules.map(module => {
            const count = Object.keys(this.dashboardData[module] || {}).length;
            const loading = this.loadingStates[module];
            const status = loading ? '🔄' : count > 0 ? '✅' : '❌';
            return `
                <div style="display: flex; justify-content: space-between; align-items: center; margin: 5px 0;">
                    <span style="text-transform: capitalize;">${module.replace(/([A-Z])/g, ' $1').trim()}</span>
                    <span>${status} ${loading ? 'Loading...' : count + ' records'}</span>
                </div>
            `;
        }).join('');
        
        statusContainer.innerHTML = `
            <h4 style="margin: 0 0 10px 0; color: var(--deep-red);">Data Fetching Status</h4>
            ${statusHTML}
        `;
        
        document.body.appendChild(statusContainer);
        
        // Show status for 5 seconds when data changes
        statusContainer.style.display = 'block';
        setTimeout(() => {
            statusContainer.style.display = 'none';
        }, 5000);
    }

    // Add method to get complete dashboard data for debugging
    getDashboardData() {
        return {
            patients: this.dashboardData.patients,
            appointments: this.dashboardData.appointments,
            labResults: this.dashboardData.labResults,
            medications: this.dashboardData.medications,
            counts: {
                patients: Object.keys(this.dashboardData.patients).length,
                appointments: Object.keys(this.dashboardData.appointments).length,
                labResults: Object.keys(this.dashboardData.labResults).length,
                medications: Object.keys(this.dashboardData.medications).length
            },
            loadingStates: this.loadingStates,
            lastUpdate: this.dataCache.lastUpdate
        };
    }
    debugScroll() {
        console.log('=== DASHBOARD DEBUG INFO ===');
        console.log('Config:', this.topBarConfig);
        console.log('Elements:', {
            topbar: !!this.elements.searchHeader,
            progressBar: !!this.elements.scrollProgressBar
        });
        console.log('Data Manager:', !!this.dataManager);
        console.log('Firebase Manager:', !!this.firebaseManager);
        console.log('Current scroll:', window.pageYOffset || document.documentElement.scrollTop);
        console.log('Dashboard data:', this.dashboardData);
        console.log('Loading states:', this.loadingStates);
        console.log('=== END DEBUG ===');
        
        return {
            config: this.topBarConfig,
            hasDataManager: !!this.dataManager,
            hasFirebaseManager: !!this.firebaseManager,
            dataKeys: Object.keys(this.dashboardData),
            dataCounts: Object.fromEntries(
                Object.entries(this.dashboardData).map(([key, value]) => [
                    key, 
                    Array.isArray(value) ? value.length : Object.keys(value || {}).length
                ])
            ),
            loadingStates: this.loadingStates
        };
    }

    // Cleanup method
    destroy() {
        // Remove scroll listener
        if (this.throttledScroll) {
            window.removeEventListener('scroll', this.throttledScroll);
        }
        
        // Clear timeouts
        if (this.searchTimeout) {
            clearTimeout(this.searchTimeout);
        }
        
        // Clean up Firebase listeners
        if (this.firebase && this.firebase.database) {
            const { off } = this.firebase.database;
            Object.values(this.firebaseListeners).forEach(listener => {
                if (listener) off(listener);
            });
        }
        
        // Clean up data manager
        if (this.dataManager && this.dataManager.cleanup) {
            this.dataManager.cleanup();
        }
        
        // Remove added elements
        const progressBar = document.querySelector('.scroll-progress-bar');
        if (progressBar) progressBar.remove();
        
        const styles = document.getElementById('dashboard-enhanced-css');
        if (styles) styles.remove();
        
        // Clean up topbar classes
        if (this.elements.searchHeader) {
            this.elements.searchHeader.classList.remove('topbar-autohide', 'header-hidden', 'header-visible');
        }
        
        console.log('Dashboard: Cleaned up successfully');
    }

    // Show topbar with design preservation
    showTopbarPreserveDesign() {
// Initialize the application
const pregnaCareApp = new PregnaCareApp();

// Make it globally accessible
window.pregnaCareApp = pregnaCareApp;

// Global helper functions
window.PregnaCare = {
    showPatientDetails: (id) => pregnaCareApp.showPatientDetails(id),
    showEnhancedPatientDetails: (id) => pregnaCareApp.showEnhancedPatientDetails(id),
    callEmergency: () => pregnaCareApp.callEmergency(),
    toggleSearchHeader: () => pregnaCareApp.toggleSearchHeader(),
    scrollToTop: () => pregnaCareApp.scrollToTop(),
    scheduleAppointment: (id) => pregnaCareApp.scheduleAppointment(id),
    orderLabTest: (id) => pregnaCareApp.orderLabTest(id),
    debug: () => pregnaCareApp.debugScroll(),
    getDashboardData: () => pregnaCareApp.getDashboardData(),
    checkDataStatus: () => pregnaCareApp.displayDataFetchingStatus()
};

console.log('🚀 PregnaCare Dashboard Complete Version loaded');
console.log('📋 Features:');
console.log('  - Direct Firebase initialization with config');
console.log('  - Complete Firebase real-time data fetching');
console.log('  - Data validation and normalization');
console.log('  - Enhanced error handling and loading states');
console.log('  - Auto-hide topbar with Ctrl+H toggle');
console.log('  - Lab results and medications summaries');
console.log('  - Mock data fallback for testing');
console.log('  - Memory leak prevention with proper cleanup');
console.log('  - System alerts removed - using unified notification system');
console.log('📊 Available Commands:');
console.log('  - window.PregnaCare.getDashboardData() - View all loaded data');
console.log('  - window.PregnaCare.checkDataStatus() - Check data fetching status');
console.log('  - window.PregnaCare.debug() - Debug dashboard state');
console.log('🔍 Troubleshooting:');
console.log('  - Check console for "Dashboard: X data received" messages');
console.log('  - Run window.PregnaCare.getDashboardData() to see loaded data');
console.log('  - Check Network tab for Firebase connections');
    }}