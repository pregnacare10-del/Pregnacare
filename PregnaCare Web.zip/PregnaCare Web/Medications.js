// PregnaCare Medications System - Firebase Integration with Unified Notifications
// Author: Claude AI Assistant
// Date: January 2025

// Firebase Configuration - Using compat version
const firebaseConfig = {
    apiKey: "AIzaSyBGPYM5JHrSXOd9PWbQ4TzoqUtlf5qCwjs",
    authDomain: "pregnacare-web.firebaseapp.com",
    databaseURL: "https://pregnacare-web-default-rtdb.firebaseio.com",
    projectId: "pregnacare-web",
    storageBucket: "pregnacare-web.firebasestorage.app",
    messagingSenderId: "408625794290",
    appId: "1:408625794290:web:bb131c8b35869b31acd46b",
    measurementId: "G-HZB017TYX3"
};

// Initialize Firebase using global objects from compat CDN
let app, database, auth;

try {
    app = firebase.initializeApp(firebaseConfig);
    database = firebase.database();
    auth = firebase.auth();
    console.log('✅ Firebase initialized successfully');
    
    // Test Firebase connection immediately
    database.ref('.info/connected').on('value', function(snapshot) {
        if (snapshot.val() === true) {
            console.log('✅ Connected to Firebase Realtime Database');
        } else {
            console.log('❌ Disconnected from Firebase');
        }
    });
} catch (error) {
    console.error('❌ Firebase initialization error:', error);
}

// Global variables
let currentUser = null;
let medicationSystem = null;
let messagingSystem = null;

// Initialize application immediately
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded, initializing application...');
    
    // Create mock user for demo
    currentUser = {
        uid: 'medications-module',
        displayName: 'Medications System',
        email: 'medications@pregnacare.com'
    };
    
    initializeApplication();
});

// Authentication state listener
auth.onAuthStateChanged((user) => {
    if (user) {
        currentUser = user;
        console.log('User authenticated:', user.uid);
        if (!medicationSystem || !messagingSystem) {
            initializeApplication();
        }
    } else {
        // If no user, create demo user for testing
        if (!currentUser) {
            currentUser = {
                uid: 'medications-module',
                displayName: 'Medications System',
                email: 'medications@pregnacare.com'
            };
            initializeApplication();
        }
    }
});

// Initialize application after authentication
async function initializeApplication() {
    console.log('Initializing application with Firebase...');
    
    try {
        if (!currentUser) {
            throw new Error('No user available');
        }
        
        // Initialize notification system
        if (database && window.notificationSystem) {
            await window.notificationSystem.initialize(database, currentUser);
            console.log('✅ Notification system initialized for Medications');
        }
        
        messagingSystem = new MessagingSystemLegacy();
        medicationSystem = new MedicationSystem();
        
        // Setup event listeners first
        setupEventListeners();
        
        // Then initialize systems
        initializeMessaging();
        initializeMedicationSystem();
        
        // Start medication monitoring
        startMedicationMonitoring();
        
        console.log('Application initialized successfully');
    } catch (error) {
        console.error('Error initializing application:', error);
        // Show user-friendly error message
        const container = document.getElementById('toastContainer');
        if (container) {
            const toast = document.createElement('div');
            toast.className = 'toast toast-error';
            toast.innerHTML = `
                <div class="toast-content">
                    <i class="fas fa-exclamation-circle"></i>
                    <span>Failed to initialize application. Please refresh the page.</span>
                </div>
            `;
            container.appendChild(toast);
        }
    }
}

// Start monitoring medications for refills and interactions
function startMedicationMonitoring() {
    // Check for refill reminders daily
    checkRefillReminders();
    setInterval(() => {
        checkRefillReminders();
    }, 24 * 60 * 60 * 1000);
    
    // Check for drug interactions when medications change
    if (medicationSystem) {
        medicationSystem.checkDrugInteractions = checkDrugInteractions;
    }
}

// Check for medication refill reminders
function checkRefillReminders() {
    if (!medicationSystem || !medicationSystem.medications) return;
    
    const today = new Date();
    
    medicationSystem.medications.forEach(medication => {
        if (medication.refillReminder && medication.status === 'active') {
            const startDate = new Date(medication.startDate);
            const endDate = new Date(startDate);
            endDate.setDate(endDate.getDate() + medication.duration);
            
            const daysUntilEnd = Math.ceil((endDate - today) / 86400000);
            
            if (daysUntilEnd <= medication.refillReminder && daysUntilEnd > 0) {
                const notificationKey = `medication_refill_${medication.id}_${daysUntilEnd}`;
                if (!hasRecentNotification(notificationKey)) {
                    if (window.NotificationIntegration && window.NotificationIntegration.medications) {
                        window.NotificationIntegration.medications.notifyRefillReminder({
                            id: medication.id,
                            patientName: medication.patientName,
                            medicationName: medication.medicationName,
                            daysUntilRefill: daysUntilEnd
                        });
                    }
                    markNotificationSent(notificationKey);
                }
            }
        }
    });
}

// Check for drug interactions
function checkDrugInteractions(patientId) {
    if (!medicationSystem || !medicationSystem.medications) return;
    
    // Get all active medications for the patient
    const patientMedications = medicationSystem.medications.filter(med => 
        med.patientId === patientId && med.status === 'active'
    );
    
    // Simple interaction check (in real app, this would use a drug interaction API)
    const interactions = [];
    
    // Example interaction rules
    const interactionRules = [
        { drug1: 'aspirin', drug2: 'warfarin', severity: 'high' },
        { drug1: 'ibuprofen', drug2: 'aspirin', severity: 'moderate' },
        // Add more interaction rules as needed
    ];
    
    // Check each pair of medications
    for (let i = 0; i < patientMedications.length; i++) {
        for (let j = i + 1; j < patientMedications.length; j++) {
            const med1 = patientMedications[i].medicationName.toLowerCase();
            const med2 = patientMedications[j].medicationName.toLowerCase();
            
            interactionRules.forEach(rule => {
                if ((med1.includes(rule.drug1) && med2.includes(rule.drug2)) ||
                    (med1.includes(rule.drug2) && med2.includes(rule.drug1))) {
                    interactions.push({
                        medication1: patientMedications[i].medicationName,
                        medication2: patientMedications[j].medicationName,
                        severity: rule.severity,
                        patientName: patientMedications[i].patientName
                    });
                }
            });
        }
    }
    
    // Send notifications for interactions
    interactions.forEach(interaction => {
        const notificationKey = `drug_interaction_${patientId}_${interaction.medication1}_${interaction.medication2}`;
        if (!hasRecentNotification(notificationKey)) {
            if (window.NotificationIntegration && window.NotificationIntegration.medications) {
                window.NotificationIntegration.medications.notifyInteractionWarning(interaction);
            }
            markNotificationSent(notificationKey);
        }
    });
}

// Check if notification was recently sent
function hasRecentNotification(key) {
    const sent = localStorage.getItem(`notif_sent_${key}`);
    if (!sent) return false;
    
    const sentTime = parseInt(sent);
    const hoursSince = (Date.now() - sentTime) / (1000 * 60 * 60);
    
    // Don't send same notification within 24 hours
    return hoursSince < 24;
}

// Mark notification as sent
function markNotificationSent(key) {
    localStorage.setItem(`notif_sent_${key}`, Date.now().toString());
}

// ===== MESSAGING SYSTEM =====
class MessagingSystemLegacy {
    constructor() {
        this.messagesRef = database.ref('messages');
        this.usersRef = database.ref('users');
        this.unreadCount = 0;
        this.messages = [];
    }

    initialize() {
        console.log('Initializing legacy messaging system...');
        this.loadMessages();
        this.updateMessageBadge();
    }

    async loadMessages() {
        try {
            // Listen for real-time messages from Firebase
            this.messagesRef.orderByChild('timestamp').limitToLast(10).on('value', (snapshot) => {
                this.messages = [];
                if (snapshot.exists()) {
                    snapshot.forEach((childSnapshot) => {
                        this.messages.unshift({
                            id: childSnapshot.key,
                            ...childSnapshot.val()
                        });
                    });
                }
                this.displayMessages();
                this.updateMessageBadge();
            }, (error) => {
                console.error('Error loading messages:', error);
                this.messages = [];
                this.displayMessages();
            });
        } catch (error) {
            console.error('Error setting up message listener:', error);
        }
    }

    displayMessages() {
        const messageDropdown = document.getElementById('messageDropdown');
        if (!messageDropdown) return;
        
        const messageList = messageDropdown.querySelector('ul');
        if (!messageList) return;
        
        messageList.innerHTML = '';

        if (this.messages.length === 0) {
            messageList.innerHTML = '<li><p style="text-align: center; color: #888; padding: 10px;">No messages</p></li>';
            return;
        }

        this.messages.slice(0, 5).forEach(message => {
            const messageItem = this.createMessageElement(message);
            messageList.appendChild(messageItem);
        });

        this.unreadCount = this.messages.filter(msg => !msg.read).length;
        this.updateMessageBadge();
    }

    createMessageElement(message) {
        const li = document.createElement('li');
        li.innerHTML = `
            <button type="button" class="notification-item ${!message.read ? 'unread' : ''}" 
                    data-action="view-message" data-message-id="${message.id}">
                <i class="fas ${this.getMessageIcon(message.senderRole)}"></i>
                <span>${message.senderName}: ${(message.content || '').substring(0, 40)}...</span>
            </button>
        `;
        return li;
    }

    getMessageIcon(role) {
        const icons = {
            'doctor': 'fa-user-md',
            'nurse': 'fa-user-nurse',
            'patient': 'fa-user',
            'admin': 'fa-user-shield',
            'system': 'fa-cog'
        };
        return icons[role] || 'fa-user';
    }

    updateMessageBadge() {
        const badge = document.querySelector('.notification-badge');
        if (badge && badge.parentElement.querySelector('.fa-message')) {
            badge.textContent = this.unreadCount;
            badge.style.display = this.unreadCount > 0 ? 'inline-block' : 'none';
        }
    }

    showToast(message, type = 'info') {
        // Use unified notification system
        if (window.showNotification) {
            window.showNotification(message, type, 'medications');
        }
    }
}

// ===== MEDICATION SYSTEM =====
class MedicationSystem {
    constructor() {
        this.medicationsRef = database.ref('medications');
        this.patientsRef = database.ref('patients');
        this.medications = [];
        this.patients = [];
        this.currentPage = 1;
        this.itemsPerPage = 25;
        this.sortBy = 'startDate';
        this.sortOrder = 'desc';
        this.isLoading = false;
        this.patientsLoaded = false;
    }

    initialize() {
        console.log('Initializing medication system with Firebase...');
        this.loadPatients();
        this.loadMedications();
        this.setupFormValidation();
    }

    // Load patients from Firebase
    async loadPatients() {
        console.log('📚 Loading patients from Firebase...');
        
        try {
            this.patientsRef.on('value', (snapshot) => {
                console.log('👥 Patients data received. Exists:', snapshot.exists());
                
                if (snapshot.exists()) {
                    const data = snapshot.val();
                    this.patients = Object.entries(data).map(([key, value]) => ({
                        key: key,
                        id: value.patientId,
                        fullName: value.fullName,
                        firstName: value.firstName,
                        lastName: value.lastName,
                        middleName: value.middleName,
                        age: value.age,
                        status: value.status,
                        birthdate: value.birthdate,
                        dueDate: value.dueDate,
                        ...value
                    }));
                    
                    // Sort patients by patient ID for dropdown
                    this.patients.sort((a, b) => {
                        const aNum = parseInt(a.id.replace('PT', ''));
                        const bNum = parseInt(b.id.replace('PT', ''));
                        return aNum - bNum;
                    });
                    
                    console.log(`✅ Loaded ${this.patients.length} patients`);
                } else {
                    this.patients = [];
                    console.log('📭 No patients found in database');
                }
                
                this.patientsLoaded = true;
                this.populatePatientDropdown();
                
            }, (error) => {
                console.error('❌ Firebase patients database error:', error);
                this.patients = [];
                this.patientsLoaded = true;
                this.populatePatientDropdown();
            });
        } catch (error) {
            console.error('❌ Error setting up patients Firebase listener:', error);
            this.patients = [];
            this.patientsLoaded = true;
        }
    }

    // Populate patient dropdown
    populatePatientDropdown() {
        const patientSelect = document.getElementById('patientSelect');
        
        if (!patientSelect) {
            console.log('Patient select element not found');
            return;
        }

        console.log('🔄 Populating patient dropdown with', this.patients.length, 'patients');

        // Clear existing options except the first placeholder
        patientSelect.innerHTML = '<option value="">Select a patient...</option>';

        if (this.patients.length === 0) {
            const noPatientOption = document.createElement('option');
            noPatientOption.value = '';
            noPatientOption.textContent = 'No patients available - Add patients first';
            noPatientOption.disabled = true;
            patientSelect.appendChild(noPatientOption);
            return;
        }

        // Add patients to dropdown
        this.patients.forEach(patient => {
            if (patient.id) {
                const option = document.createElement('option');
                option.value = patient.id;
                option.textContent = patient.id;
                option.dataset.fullName = patient.fullName || 'Unknown';
                option.dataset.patientKey = patient.key;
                option.dataset.age = patient.age || 'N/A';
                option.dataset.status = patient.status || 'Unknown';
                
                patientSelect.appendChild(option);
            }
        });

        console.log('✅ Patient dropdown populated successfully');
    }

    // Handle patient selection
    handlePatientSelection(selectElement) {
        const selectedOption = selectElement.options[selectElement.selectedIndex];
        const patientIdField = document.getElementById('patientId');
        const patientNameField = document.getElementById('patientName');
        
        if (selectedOption && selectedOption.value) {
            const patientId = selectedOption.value;
            const patientName = selectedOption.dataset.fullName;
            const patientStatus = selectedOption.dataset.status;
            
            console.log('👤 Patient selected:', patientId, patientName);
            
            // Update hidden fields
            if (patientIdField) {
                patientIdField.value = patientId;
            }
            
            if (patientNameField) {
                patientNameField.value = patientName;
            }
            
            // Clear any validation errors
            this.clearFieldError(selectElement);
            
            return {
                patientId: patientId,
                patientName: patientName
            };
        } else {
            // Clear fields when no patient is selected
            if (patientIdField) {
                patientIdField.value = '';
            }
            if (patientNameField) {
                patientNameField.value = '';
            }
        }
        
        return null;
    }

    // Add medication
    async addMedication(medicationData, showToast = true) {
        console.log('🚀 Starting to add medication...');
        console.log('📋 Raw medication data:', medicationData);
        
        // Show loading state on submit button
        const submitBtn = document.getElementById('submitBtn');
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
        submitBtn.disabled = true;
        
        try {
            // Validate that we have required data including patient
            const requiredFields = ['patientId', 'medicationName', 'dosage', 'prescribedBy', 'startDate', 'duration'];
            const missingFields = [];
            
            requiredFields.forEach(field => {
                if (!medicationData[field] || medicationData[field].toString().trim() === '') {
                    missingFields.push(field);
                }
            });
            
            if (missingFields.length > 0) {
                throw new Error(`Missing required fields: ${missingFields.join(', ')}`);
            }

            // Validate that patient exists
            const selectedPatient = this.patients.find(p => p.id === medicationData.patientId);
            if (!selectedPatient) {
                throw new Error('Selected patient not found. Please refresh and try again.');
            }
            
            console.log('✅ Patient validation passed:', selectedPatient.fullName);
            console.log('✅ All required fields validated');
            
            // Clean and prepare the data with proper patient info
            const cleanData = {
                patientId: medicationData.patientId.toString().trim(),
                patientName: selectedPatient.fullName,
                patientKey: selectedPatient.key,
                medicationName: medicationData.medicationName.toString().trim(),
                medicationType: medicationData.medicationType || '',
                dosage: medicationData.dosage.toString().trim(),
                frequency: medicationData.frequency || '',
                prescribedBy: medicationData.prescribedBy.toString().trim(),
                startDate: medicationData.startDate,
                duration: parseInt(medicationData.duration) || 0,
                priority: medicationData.priority || 'normal',
                instructions: medicationData.instructions || '',
                sideEffects: medicationData.sideEffects || '',
                refillReminder: medicationData.refillReminder ? parseInt(medicationData.refillReminder) : null,
                status: 'active',
                createdAt: Date.now(),
                updatedAt: Date.now(),
                createdBy: currentUser.uid
            };
            
            console.log('🧹 Cleaned medication data:', cleanData);
            
            // Test Firebase write capability first
            console.log('🔍 Testing Firebase write permissions...');
            const testRef = database.ref('test_write');
            await testRef.set({ test: true, timestamp: Date.now() });
            await testRef.remove();
            console.log('✅ Firebase write test successful');
            
            // Create a new reference with auto-generated key
            const newMedicationRef = this.medicationsRef.push();
            console.log('📝 Created new Firebase reference:', newMedicationRef.key);
            
            // Add the ID to the data
            cleanData.id = newMedicationRef.key;
            
            // Save to Firebase with timeout
            console.log('💾 Saving to Firebase...');
            const savePromise = newMedicationRef.set(cleanData);
            const timeoutPromise = new Promise((_, reject) => 
                setTimeout(() => reject(new Error('Save operation timed out after 15 seconds')), 15000)
            );
            
            await Promise.race([savePromise, timeoutPromise]);
            console.log('✅ Medication saved successfully with ID:', newMedicationRef.key);
            
            if (showToast) {
                this.showToast(`Medication added successfully for ${selectedPatient.fullName}!`, 'success');
                
                // Send notification
                if (window.NotificationIntegration && window.NotificationIntegration.medications) {
                    window.NotificationIntegration.medications.notifyMedicationAdded({
                        id: newMedicationRef.key,
                        patientName: selectedPatient.fullName,
                        patientId: medicationData.patientId,
                        medicationName: medicationData.medicationName,
                        prescribedBy: medicationData.prescribedBy,
                        dosage: medicationData.dosage
                    });
                }
                
                // Check for drug interactions
                setTimeout(() => {
                    checkDrugInteractions(medicationData.patientId);
                }, 1000);
                
                this.closeModal();
            }
            
            return newMedicationRef.key;
            
        } catch (error) {
            console.error('❌ Error adding medication:', error);
            console.error('Error stack:', error.stack);
            
            let errorMessage = 'Failed to save medication. ';
            if (error.code === 'PERMISSION_DENIED') {
                errorMessage += 'Permission denied. Check Firebase database rules.';
            } else if (error.message.includes('timeout')) {
                errorMessage += 'Request timed out. Check your internet connection.';
            } else if (error.message.includes('Missing required fields')) {
                errorMessage += error.message;
            } else if (error.message.includes('patient not found')) {
                errorMessage += error.message;
            } else {
                errorMessage += error.message || 'Unknown error occurred.';
            }
            
            this.showToast(errorMessage, 'error');
            throw error;
        } finally {
            // Restore button state
            if (submitBtn) {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            }
        }
    }

    async loadMedications() {
        if (this.isLoading) return;
        this.isLoading = true;

        console.log('📚 Loading medications from Firebase...');
        
        const loadingState = document.getElementById('loadingState');
        const noDataState = document.getElementById('noDataState');
        const errorState = document.getElementById('errorState');

        if (loadingState) loadingState.style.display = 'block';
        if (noDataState) noDataState.style.display = 'none';
        if (errorState) errorState.style.display = 'none';

        try {
            this.medicationsRef.on('value', (snapshot) => {
                console.log('📊 Firebase data received. Exists:', snapshot.exists());
                
                if (snapshot.exists()) {
                    const data = snapshot.val();
                    this.medications = Object.entries(data).map(([key, value]) => ({
                        id: key,
                        ...value
                    }));
                    console.log(`✅ Loaded ${this.medications.length} medications`);
                } else {
                    this.medications = [];
                    console.log('📭 No medications found in database');
                }
                
                this.displayMedications();
                
                if (loadingState) loadingState.style.display = 'none';
                if (this.medications.length === 0) {
                    this.showNoDataState();
                }
                this.isLoading = false;
            }, (error) => {
                console.error('❌ Firebase database error:', error);
                if (loadingState) loadingState.style.display = 'none';
                if (errorState) errorState.style.display = 'block';
                this.showToast('Failed to load medications from database', 'error');
                this.isLoading = false;
            });
        } catch (error) {
            console.error('❌ Error setting up Firebase listener:', error);
            if (loadingState) loadingState.style.display = 'none';
            if (errorState) errorState.style.display = 'block';
            this.showToast('Failed to connect to database', 'error');
            this.isLoading = false;
        }
    }

    showNoDataState() {
        const tableBody = document.getElementById('medicationsTableBody');
        if (!tableBody) return;

        // Remove existing rows
        const existingRows = tableBody.querySelectorAll('.medication-row, .table-row, .no-data');
        existingRows.forEach(row => row.remove());

        // Create simplified no data state
        const noDataElement = document.createElement('div');
        noDataElement.className = 'no-data';
        noDataElement.id = 'noDataState';
        
        // Show different message based on whether patients are available
        const hasPatients = this.patients.length > 0;
        const message = hasPatients 
            ? 'Use the "Add Medication" button above to start adding medications to the system.'
            : 'No patients available. Please add patients first before adding medications.';
            
        const actionButton = hasPatients 
            ? '' 
            : '<button class="btn btn-primary" onclick="window.location.href=\'Patients.html\'" style="margin-top: 15px;"><i class="fas fa-user-plus"></i> Add Patients First</button>';
        
        noDataElement.innerHTML = `
            <div class="no-data-icon">
                <i class="fas fa-pills"></i>
            </div>
            <h3>No Medications Found</h3>
            <p>${message}</p>
            ${actionButton}
        `;
        
        tableBody.appendChild(noDataElement);
    }

    // Form validation
    validateField(field) {
        const value = field.value ? field.value.toString().trim() : '';
        const fieldName = field.name;
        const errorElement = document.getElementById(`${fieldName}Error`);

        console.log(`Validating field ${fieldName}: "${value}"`);

        // Special validation for patient selection
        if (fieldName === 'patientSelect') {
            if (field.hasAttribute('required') && !value) {
                this.showFieldError(field, errorElement, 'Please select a patient');
                return false;
            }
            
            // Validate that selected patient still exists
            if (value && !this.patients.find(p => p.id === value)) {
                this.showFieldError(field, errorElement, 'Selected patient no longer exists. Please choose another patient.');
                return false;
            }
        } else if (field.hasAttribute('required') && !value) {
            this.showFieldError(field, errorElement, 'This field is required');
            return false;
        }

        // Additional validation for specific fields
        if (fieldName === 'duration' && value) {
            const duration = parseInt(value);
            if (isNaN(duration) || duration < 1 || duration > 365) {
                this.showFieldError(field, errorElement, 'Duration must be between 1 and 365 days');
                return false;
            }
        }

        if (fieldName === 'startDate' && value) {
            const startDate = new Date(value);
            const today = new Date();
            const oneYearAgo = new Date();
            oneYearAgo.setFullYear(today.getFullYear() - 1);
            
            if (startDate > today) {
                this.showFieldError(field, errorElement, 'Start date cannot be in the future');
                return false;
            }
            
            if (startDate < oneYearAgo) {
                this.showFieldError(field, errorElement, 'Start date cannot be more than 1 year ago');
                return false;
            }
        }

        this.clearFieldError(field);
        return true;
    }

    async updateMedication(medicationId, medicationData) {
        console.log('Updating medication in Firebase:', medicationId, medicationData);
        
        try {
            const medicationRef = database.ref(`medications/${medicationId}`);
            const existingMedication = this.medications.find(m => m.id === medicationId);
            
            if (!existingMedication) {
                throw new Error('Medication not found');
            }

            // If patient was changed, validate the new patient
            if (medicationData.patientId && medicationData.patientId !== existingMedication.patientId) {
                const selectedPatient = this.patients.find(p => p.id === medicationData.patientId);
                if (!selectedPatient) {
                    throw new Error('Selected patient not found. Please refresh and try again.');
                }
                // Update patient name to match selected patient
                medicationData.patientName = selectedPatient.fullName;
                medicationData.patientKey = selectedPatient.key;
            }
            
            const updatedMedication = {
                ...existingMedication,
                ...medicationData,
                updatedAt: Date.now(),
                updatedBy: currentUser.uid
            };

            await medicationRef.set(updatedMedication);
            console.log('Medication updated in Firebase');

            this.showToast('Medication updated successfully', 'success');
            
            // Check for drug interactions after update
            setTimeout(() => {
                checkDrugInteractions(updatedMedication.patientId);
            }, 1000);
            
            this.closeModal();
            return medicationId;
        } catch (error) {
            console.error('Error updating medication in Firebase:', error);
            this.showToast('Failed to update medication in database', 'error');
            throw error;
        }
    }

    async deleteMedication(medicationId) {
        console.log('Deleting medication from Firebase:', medicationId);
        
        try {
            const medicationRef = database.ref(`medications/${medicationId}`);
            await medicationRef.remove();
            console.log('Medication deleted from Firebase');
            
            this.showToast('Medication deleted successfully', 'success');
        } catch (error) {
            console.error('Error deleting medication from Firebase:', error);
            this.showToast('Failed to delete medication from database', 'error');
            throw error;
        }
    }

    displayMedications() {
        const tableBody = document.getElementById('medicationsTableBody');
        if (!tableBody) return;
        
        const loadingState = document.getElementById('loadingState');

        // Remove existing medication rows
        const existingRows = tableBody.querySelectorAll('.medication-row, .table-row, .no-data');
        existingRows.forEach(row => row.remove());

        if (this.medications.length === 0) {
            if (loadingState) loadingState.style.display = 'none';
            this.showNoDataState();
            return;
        }

        const sortedMedications = this.sortMedications(this.medications);
        const startIndex = (this.currentPage - 1) * this.itemsPerPage;
        const endIndex = startIndex + this.itemsPerPage;
        const paginatedMedications = sortedMedications.slice(startIndex, endIndex);

        paginatedMedications.forEach(medication => {
            const row = this.createMedicationRow(medication);
            tableBody.appendChild(row);
        });

        this.updatePagination(this.medications.length);
        if (loadingState) loadingState.style.display = 'none';
    }

    createMedicationRow(medication) {
        const row = document.createElement('div');
        row.className = 'medication-row';
        
        // Get updated patient info
        const patientInfo = this.patients.find(p => p.id === medication.patientId);
        const patientName = patientInfo ? patientInfo.fullName : (medication.patientName || 'Unknown Patient');
        const patientId = medication.patientId || 'N/A';
        const patientStatus = patientInfo ? ` (${patientInfo.status})` : '';
        
        row.innerHTML = `
            <div class="row-content" data-label="Patient">
                <div class="patient-info">
                    <div class="patient-name">${patientName}${patientStatus}</div>
                    <div class="patient-id">ID: ${patientId}</div>
                </div>
            </div>
            <div class="row-content" data-label="Medication">
                <div class="medication-info">
                    <div class="medication-name">${medication.medicationName}</div>
                    <div class="medication-type">${medication.medicationType || 'N/A'}</div>
                </div>
            </div>
            <div class="row-content" data-label="Dosage">
                <div class="dosage-info">
                    <div class="dosage">${medication.dosage}</div>
                    <div class="frequency">${medication.frequency || 'N/A'}</div>
                </div>
            </div>
            <div class="row-content" data-label="Prescribed By">
                <div class="doctor-info">
                    <div class="doctor-name">${medication.prescribedBy}</div>
                </div>
            </div>
            <div class="row-content" data-label="Start Date">
                <div class="date-info">
                    <div class="start-date">${this.formatDate(medication.startDate)}</div>
                </div>
            </div>
            <div class="row-content" data-label="Duration">
                <div class="duration-info">
                    <div class="duration">${medication.duration} days</div>
                </div>
            </div>
            <div class="row-content" data-label="Status">
                <div class="status-badge status-${medication.status || 'active'}">
                    ${this.getStatusText(medication.status)}
                </div>
            </div>
            <div class="action-buttons" data-label="Actions">
                <div class="btn">
                    <button type="button" class="view-btn" data-action="view-medication" data-medication-id="${medication.id}" title="View Details">
                    View
                    </button>
                    <button type="button" class="edit-btn" data-action="edit-medication" data-medication-id="${medication.id}" title="Edit">
                    Edit
                    </button>
                    <button type="button" class="delete-btn" data-action="delete-medication" data-medication-id="${medication.id}" title="Delete">
                    Delete
                    </button>
                </div>
            </div>
        `;
        return row;
    }

    sortMedications(medications) {
        return medications.sort((a, b) => {
            let aValue = a[this.sortBy] || '';
            let bValue = b[this.sortBy] || '';
            
            if (this.sortBy === 'startDate' || this.sortBy === 'createdAt') {
                aValue = new Date(aValue);
                bValue = new Date(bValue);
            } else if (this.sortBy === 'duration') {
                aValue = parseInt(aValue) || 0;
                bValue = parseInt(bValue) || 0;
            } else {
                aValue = aValue.toString().toLowerCase();
                bValue = bValue.toString().toLowerCase();
            }
            
            if (this.sortOrder === 'asc') {
                return aValue > bValue ? 1 : -1;
            } else {
                return aValue < bValue ? 1 : -1;
            }
        });
    }

    formatDate(dateString) {
        if (!dateString) return 'N/A';
        const date = new Date(dateString);
        if (isNaN(date.getTime())) return 'Invalid Date';
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    getStatusText(status) {
        const statusMap = {
            'active': 'Active',
            'completed': 'Completed',
            'discontinued': 'Discontinued',
            'paused': 'Paused'
        };
        return statusMap[status] || 'Active';
    }

    updatePagination(totalItems) {
        const totalPages = Math.ceil(totalItems / this.itemsPerPage);
        const paginationInfo = document.getElementById('paginationInfo');
        const startIndex = (this.currentPage - 1) * this.itemsPerPage + 1;
        const endIndex = Math.min(startIndex + this.itemsPerPage - 1, totalItems);

        if (paginationInfo) {
            paginationInfo.textContent = totalItems > 0 
                ? `Showing ${startIndex}-${endIndex} of ${totalItems} entries`
                : 'Showing 0 of 0 entries';
        }

        const firstPage = document.getElementById('firstPage');
        const prevPage = document.getElementById('prevPage');
        const nextPage = document.getElementById('nextPage');
        const lastPage = document.getElementById('lastPage');

        if (firstPage) firstPage.disabled = this.currentPage === 1;
        if (prevPage) prevPage.disabled = this.currentPage === 1;
        if (nextPage) nextPage.disabled = this.currentPage === totalPages || totalPages === 0;
        if (lastPage) lastPage.disabled = this.currentPage === totalPages || totalPages === 0;

        this.updatePageNumbers(totalPages);
    }

    updatePageNumbers(totalPages) {
        const pageNumbers = document.getElementById('pageNumbers');
        if (!pageNumbers) return;
        
        pageNumbers.innerHTML = '';

        if (totalPages === 0) return;

        const maxVisiblePages = 5;
        let startPage = Math.max(1, this.currentPage - Math.floor(maxVisiblePages / 2));
        let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);

        for (let i = startPage; i <= endPage; i++) {
            const pageSpan = document.createElement('span');
            pageSpan.className = `page-number ${i === this.currentPage ? 'active' : ''}`;
            pageSpan.textContent = i;
            pageSpan.dataset.page = i;
            pageSpan.addEventListener('click', () => {
                this.currentPage = i;
                this.displayMedications();
            });
            pageNumbers.appendChild(pageSpan);
        }
    }

    setupFormValidation() {
        const form = document.getElementById('medicationForm');
        if (!form) return;
        
        const inputs = form.querySelectorAll('input[required], select[required]');
        inputs.forEach(input => {
            input.addEventListener('blur', () => this.validateField(input));
            input.addEventListener('input', () => this.clearFieldError(input));
        });

        // Setup patient dropdown change handler
        const patientSelect = document.getElementById('patientSelect');
        if (patientSelect) {
            patientSelect.addEventListener('change', (e) => {
                this.handlePatientSelection(e.target);
                this.validateField(e.target);
            });
        }

        // Character counter for instructions
        const instructionsField = document.getElementById('instructions');
        const instructionsCounter = document.getElementById('instructionsCount');
        if (instructionsField && instructionsCounter) {
            instructionsField.addEventListener('input', () => {
                const count = instructionsField.value.length;
                instructionsCounter.textContent = count;
                
                const counter = instructionsCounter.closest('.character-counter');
                if (count > 400) {
                    counter.classList.add('danger');
                    counter.classList.remove('warning');
                } else if (count > 300) {
                    counter.classList.add('warning');
                    counter.classList.remove('danger');
                } else {
                    counter.classList.remove('warning', 'danger');
                }
            });
        }
    }

    showFieldError(field, errorElement, message) {
        field.classList.add('error');
        if (errorElement) {
            errorElement.textContent = message;
            errorElement.classList.add('show');
        }
    }

    clearFieldError(field) {
        field.classList.remove('error');
        const errorElement = document.getElementById(`${field.name}Error`);
        if (errorElement) {
            errorElement.classList.remove('show');
        }
    }

    openModal() {
        const modal = document.getElementById('medicationModal');
        if (modal) {
            modal.style.display = 'flex';
            document.getElementById('modalTitle').textContent = 'Add New Medication';
            document.getElementById('submitBtn').innerHTML = '<i class="fas fa-plus"></i> Add Medication';
            this.resetForm();
            
            // Wait for patients to load before opening modal
            if (!this.patientsLoaded) {
                this.showToast('Loading patients data...', 'info');
                const checkPatients = setInterval(() => {
                    if (this.patientsLoaded) {
                        clearInterval(checkPatients);
                        this.populatePatientDropdown();
                    }
                }, 100);
            } else {
                this.populatePatientDropdown();
            }
            
            // Set default start date to today
            const startDateField = document.getElementById('startDate');
            if (startDateField) {
                const today = new Date().toISOString().split('T')[0];
                startDateField.value = today;
            }
        }
    }

    closeModal() {
        const modal = document.getElementById('medicationModal');
        const detailsModal = document.getElementById('medicationDetailsModal');
        const confirmationModal = document.getElementById('confirmationModal');
        
        if (modal) modal.style.display = 'none';
        if (detailsModal) detailsModal.style.display = 'none';
        if (confirmationModal) confirmationModal.style.display = 'none';
        
        this.resetForm();
    }

    resetForm() {
        const form = document.getElementById('medicationForm');
        if (!form) return;
        
        form.reset();
        const errorElements = form.querySelectorAll('.form-error');
        errorElements.forEach(error => error.classList.remove('show'));
        const inputElements = form.querySelectorAll('input, select, textarea');
        inputElements.forEach(input => input.classList.remove('error'));
        
        // Reset submit button
        const submitBtn = document.getElementById('submitBtn');
        if (submitBtn) {
            submitBtn.innerHTML = '<i class="fas fa-plus"></i> Add Medication';
            delete submitBtn.dataset.medicationId;
        }

        // Reset character counter
        const instructionsCounter = document.getElementById('instructionsCount');
        if (instructionsCounter) {
            instructionsCounter.textContent = '0';
            const counter = instructionsCounter.closest('.character-counter');
            if (counter) {
                counter.classList.remove('warning', 'danger');
            }
        }

        // Reset patient dropdown
        const patientSelect = document.getElementById('patientSelect');
        if (patientSelect) {
            patientSelect.selectedIndex = 0;
        }
    }

    showToast(message, type = 'info') {
        // Use unified notification system
        if (window.showNotification) {
            window.showNotification(message, type, 'medications');
        }
    }
}

// Initialize systems
function initializeMessaging() {
    if (messagingSystem) {
        messagingSystem.initialize();
        
        // Check for navigation from other pages
        checkForNavigationActions();
    }
}

// Check for navigation actions from other pages
function checkForNavigationActions() {
    const messageAction = sessionStorage.getItem('messageAction');
    const selectedConversation = sessionStorage.getItem('selectedConversation');
    
    if (messageAction === 'compose') {
        // Auto-open new message modal if coming from "Compose" action
        setTimeout(() => {
            const newMessageBtn = document.getElementById('newMessageBtn');
            if (newMessageBtn) {
                newMessageBtn.click();
            }
        }, 500);
        sessionStorage.removeItem('messageAction');
    }
    
    if (selectedConversation) {
        // Auto-select conversation if coming from conversation link
        setTimeout(() => {
            if (typeof selectConversation === 'function') {
                selectConversation(selectedConversation);
            }
        }, 1000);
        sessionStorage.removeItem('selectedConversation');
    }
}

function initializeMedicationSystem() {
    if (medicationSystem) {
        medicationSystem.initialize();
    }
}

// Event Listeners Setup
function setupEventListeners() {
    console.log('Setting up event listeners...');
    
    // Wait for DOM to be fully ready
    setTimeout(() => {
        setupMainEventListeners();
    }, 100);
}

function setupMainEventListeners() {
    // Setup Add Medication button clicks (both header and floating button)
    const addMedicationButtons = [
        document.getElementById('addMedicationBtn'),
        document.getElementById('floatingAddBtn')
    ].filter(btn => btn !== null);

    addMedicationButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            console.log('Add medication button clicked');
            if (medicationSystem) {
                medicationSystem.openModal();
            }
        });
    });

    // Use event delegation for other dynamic buttons
    document.addEventListener('click', (e) => {
        const target = e.target.closest('[data-action]');
        if (!target) return;
        
        const action = target.dataset.action;
        
        if (action === 'add-medication') {
            e.preventDefault();
            e.stopPropagation();
            console.log('Add medication action clicked');
            if (medicationSystem) {
                medicationSystem.openModal();
            }
        }
    });

    // Icon buttons - Setup dropdown toggles and message navigation
    setupDropdownToggles();

    // Enhanced form submission with debugging
    const medicationForm = document.getElementById('medicationForm');
    if (medicationForm) {
        // Setup form submit button specifically
        const submitBtn = document.getElementById('submitBtn');
        if (submitBtn) {
            submitBtn.addEventListener('click', async (e) => {
                e.preventDefault();
                e.stopPropagation();
                console.log('📝 Submit button clicked');
                
                if (!medicationSystem) {
                    console.error('❌ Medication system not initialized');
                    return;
                }
                
                // Trigger form submission
                await handleFormSubmission();
            });
        }

        // Also handle form submit event
        medicationForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            console.log('📝 Form submitted via submit event');
            await handleFormSubmission();
        });
    }

    // Form submission handler with patient data extraction
    async function handleFormSubmission() {
        if (!medicationSystem) {
            console.error('❌ Medication system not initialized');
            return;
        }
        
        // Get form data manually for better debugging
        const formElements = medicationForm.elements;
        const medicationData = {};
        
        console.log('📋 Form elements found:', formElements.length);
        
        // Collect form data
        for (let i = 0; i < formElements.length; i++) {
            const element = formElements[i];
            if (element.name && element.type !== 'submit' && element.type !== 'button') {
                medicationData[element.name] = element.value;
                console.log(`Field ${element.name}: "${element.value}"`);
            }
        }

        // Handle patient selection specifically
        const patientSelect = document.getElementById('patientSelect');
        if (patientSelect && patientSelect.value) {
            const selectedPatient = medicationSystem.handlePatientSelection(patientSelect);
            if (selectedPatient) {
                medicationData.patientId = selectedPatient.patientId;
                medicationData.patientName = selectedPatient.patientName;
                console.log('👤 Patient data added:', selectedPatient);
            }
        }
        
        console.log('📊 Collected form data:', medicationData);
        
        // Validate all required fields
        const requiredFields = medicationForm.querySelectorAll('[required]');
        let isValid = true;
        
        requiredFields.forEach(field => {
            if (!medicationSystem.validateField(field)) {
                isValid = false;
            }
        });
        
        if (!isValid) {
            console.log('❌ Form validation failed');
            medicationSystem.showToast('Please fill in all required fields correctly', 'error');
            return;
        }
        
        console.log('✅ Form validation passed');
        
        const submitBtn = document.getElementById('submitBtn');
        const isEdit = !!(submitBtn && submitBtn.dataset.medicationId);

        try {
            if (isEdit) {
                const medicationId = submitBtn.dataset.medicationId;
                await medicationSystem.updateMedication(medicationId, medicationData);
            } else {
                await medicationSystem.addMedication(medicationData);
            }
        } catch (error) {
            console.error('❌ Error submitting form:', error);
        }
    }

    // Close modal buttons
    const closeButtons = [
        document.getElementById('closeModalBtn'),
        document.getElementById('cancelBtn'),
        ...document.querySelectorAll('[data-action="close-modal"]'),
        ...document.querySelectorAll('[data-action="cancel-form"]'),
        ...document.querySelectorAll('[data-action="close-details-modal"]')
    ].filter(btn => btn !== null);

    closeButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('Close modal button clicked');
            if (medicationSystem) {
                medicationSystem.closeModal();
            }
        });
    });

    // Modal backdrop click to close
    const modals = [
        document.getElementById('medicationModal'),
        document.getElementById('medicationDetailsModal'),
        document.getElementById('confirmationModal')
    ].filter(modal => modal !== null);

    modals.forEach(modal => {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                medicationSystem.closeModal();
            }
        });
    });

    // Refresh button
    const refreshBtn = document.getElementById('refreshBtn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('Refresh button clicked');
            if (medicationSystem) {
                medicationSystem.loadMedications();
                medicationSystem.loadPatients(); // Also refresh patients
                medicationSystem.showToast('Data refreshed', 'success');
            }
        });
    }

    // Export button
    const exportBtn = document.getElementById('exportMedications');
    if (exportBtn) {
        exportBtn.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('Export button clicked');
            exportMedicationsToCSV();
        });
    }

    // Search functionality
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        let searchTimeout;
        searchInput.addEventListener('input', (e) => {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                searchMedications(e.target.value);
            }, 300); // Debounce search
        });
    }

    // Pagination controls
    setupPaginationControls();

    // Global click handler for dynamic elements
    document.addEventListener('click', async (e) => {
        const target = e.target.closest('[data-action]');
        if (!target) return;

        const action = target.dataset.action;
        const medicationId = target.dataset.medicationId || target.closest('[data-medication-id]')?.dataset.medicationId;

        console.log('Action clicked:', action, 'Medication ID:', medicationId);

        switch (action) {
            case 'view-medication':
                if (medicationId) viewMedicationDetails(medicationId);
                break;
            case 'edit-medication':
                if (medicationId) editMedication(medicationId);
                break;
            case 'delete-medication':
                if (medicationId) confirmDeleteMedication(medicationId);
                break;
            case 'add-medication':
                if (medicationSystem) {
                    medicationSystem.openModal();
                }
                break;
            case 'retry-connection':
                if (medicationSystem) {
                    medicationSystem.loadMedications();
                    medicationSystem.loadPatients();
                }
                break;
            case 'sort':
                if (medicationSystem && target.dataset.sort) {
                    const sortBy = target.dataset.sort;
                    if (medicationSystem.sortBy === sortBy) {
                        medicationSystem.sortOrder = medicationSystem.sortOrder === 'asc' ? 'desc' : 'asc';
                    } else {
                        medicationSystem.sortBy = sortBy;
                        medicationSystem.sortOrder = 'asc';
                    }
                    medicationSystem.displayMedications();
                }
                break;
        }
    });

    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        // Escape: Close modals
        if (e.key === 'Escape') {
            if (medicationSystem) {
                medicationSystem.closeModal();
            }
        }
        
        // Ctrl/Cmd + N: Add new medication
        if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
            e.preventDefault();
            if (medicationSystem) {
                medicationSystem.openModal();
            }
        }
    });

    console.log('Event listeners setup complete');
}

function setupDropdownToggles() {
    const iconMappings = [
        { iconId: 'messageIcon', dropdownId: 'messageDropdown' },
        { iconId: 'notifIcon', dropdownId: 'notifDropdown' },
        { iconId: 'helpIcon', dropdownId: 'helpDropdown' }
    ];

    iconMappings.forEach(({ iconId, dropdownId }) => {
        const icon = document.getElementById(iconId);
        if (icon) {
            console.log(`Setting up dropdown for ${iconId}`);
            icon.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                console.log(`${iconId} clicked`);
                
                // Special handling for message icon - redirect to Messages page
                if (iconId === 'messageIcon') {
                    // Check if there are unread messages and show in dropdown
                    toggleDropdown(dropdownId);
                    
                    // Add click handler for "View all messages" button
                    const viewAllMessagesBtn = document.getElementById('viewAllMessages');
                    if (viewAllMessagesBtn) {
                        viewAllMessagesBtn.addEventListener('click', (e) => {
                            e.preventDefault();
                            navigateToMessages();
                        });
                    }
                    
                    // Add click handler for "Compose new" button  
                    const composeMessageBtn = document.getElementById('composeMessage');
                    if (composeMessageBtn) {
                        composeMessageBtn.addEventListener('click', (e) => {
                            e.preventDefault();
                            navigateToMessages('compose');
                        });
                    }
                } else {
                    toggleDropdown(dropdownId);
                }
            });
        }
    });

    // Close dropdowns when clicking outside
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.icon-dropdown-group')) {
            document.querySelectorAll('.dropdown.show').forEach(dropdown => {
                dropdown.classList.remove('show');
            });
        }
    });
}

// Navigate to Messages page
function navigateToMessages(action = null) {
    console.log('Navigating to Messages page...', action ? `Action: ${action}` : '');
    
    // Store the action in sessionStorage if needed
    if (action) {
        sessionStorage.setItem('messageAction', action);
    }
    
    // Navigate to Messages page
    window.location.href = 'Messages.html';
}

// Navigate to specific conversation
function navigateToConversation(conversationId) {
    console.log('Navigating to conversation:', conversationId);
    
    // Store the conversation ID to auto-select when Messages page loads
    sessionStorage.setItem('selectedConversation', conversationId);
    
    // Navigate to Messages page
    window.location.href = 'Messages.html';
}

function toggleDropdown(dropdownId) {
    console.log('Toggling dropdown:', dropdownId);
    
    // Close all other dropdowns
    document.querySelectorAll('.dropdown.show').forEach(dropdown => {
        if (dropdown.id !== dropdownId) {
            dropdown.classList.remove('show');
        }
    });
    
    // Toggle current dropdown
    const dropdown = document.getElementById(dropdownId);
    if (dropdown) {
        dropdown.classList.toggle('show');
        console.log(`Dropdown ${dropdownId} is now ${dropdown.classList.contains('show') ? 'open' : 'closed'}`);
    }
}

function setupPaginationControls() {
    const paginationButtons = [
        { id: 'firstPage', action: () => { medicationSystem.currentPage = 1; medicationSystem.displayMedications(); } },
        { id: 'prevPage', action: () => { if (medicationSystem.currentPage > 1) { medicationSystem.currentPage--; medicationSystem.displayMedications(); } } },
        { id: 'nextPage', action: () => { 
            const totalPages = Math.ceil(medicationSystem.medications.length / medicationSystem.itemsPerPage);
            if (medicationSystem.currentPage < totalPages) { medicationSystem.currentPage++; medicationSystem.displayMedications(); }
        }},
        { id: 'lastPage', action: () => { 
            const totalPages = Math.ceil(medicationSystem.medications.length / medicationSystem.itemsPerPage);
            medicationSystem.currentPage = totalPages; medicationSystem.displayMedications(); 
        }}
    ];

    paginationButtons.forEach(({ id, action }) => {
        const btn = document.getElementById(id);
        if (btn) {
            btn.addEventListener('click', action);
        }
    });

    const itemsPerPage = document.getElementById('itemsPerPage');
    if (itemsPerPage) {
        itemsPerPage.addEventListener('change', (e) => {
            medicationSystem.itemsPerPage = parseInt(e.target.value);
            medicationSystem.currentPage = 1;
            medicationSystem.displayMedications();
        });
    }
}

// Helper Functions
function searchMedications(query) {
    if (!medicationSystem) return;
    
    if (!query.trim()) {
        medicationSystem.displayMedications();
        return;
    }

    const filteredMedications = medicationSystem.medications.filter(medication =>
        medication.patientName?.toLowerCase().includes(query.toLowerCase()) ||
        medication.patientId?.toLowerCase().includes(query.toLowerCase()) ||
        medication.medicationName?.toLowerCase().includes(query.toLowerCase()) ||
        medication.prescribedBy?.toLowerCase().includes(query.toLowerCase()) ||
        medication.dosage?.toLowerCase().includes(query.toLowerCase())
    );

    displayFilteredMedications(filteredMedications);
}

function displayFilteredMedications(medications) {
    const tableBody = document.getElementById('medicationsTableBody');
    if (!tableBody) return;
    
    const existingRows = tableBody.querySelectorAll('.medication-row, .table-row');
    existingRows.forEach(row => row.remove());

    // Hide loading and error states
    const loadingState = document.getElementById('loadingState');
    const noDataState = document.getElementById('noDataState');
    const errorState = document.getElementById('errorState');
    
    if (loadingState) loadingState.style.display = 'none';
    if (errorState) errorState.style.display = 'none';

    if (medications.length === 0) {
        const noResults = document.createElement('div');
        noResults.className = 'no-data';
        noResults.innerHTML = `
            <div class="no-data-icon">
                <i class="fas fa-search"></i>
            </div>
            <h3>No medications found</h3>
            <p>Try adjusting your search terms.</p>
        `;
        tableBody.appendChild(noResults);
        
        // Update pagination info
        const paginationInfo = document.getElementById('paginationInfo');
        if (paginationInfo) {
            paginationInfo.textContent = 'Showing 0 of 0 entries';
        }
        return;
    }

    medications.forEach(medication => {
        const row = medicationSystem.createMedicationRow(medication);
        tableBody.appendChild(row);
    });

    // Update pagination info for filtered results
    const paginationInfo = document.getElementById('paginationInfo');
    if (paginationInfo) {
        paginationInfo.textContent = `Showing ${medications.length} of ${medications.length} entries (filtered)`;
    }
}

function viewMedicationDetails(medicationId) {
    const medication = medicationSystem.medications.find(m => m.id === medicationId);
    if (!medication) return;

    // Get updated patient info
    const patientInfo = medicationSystem.patients.find(p => p.id === medication.patientId);
    const currentPatientName = patientInfo ? patientInfo.fullName : medication.patientName;
    const patientStatus = patientInfo ? patientInfo.status : 'Unknown';

    const modal = document.getElementById('medicationDetailsModal');
    const body = document.getElementById('medicationDetailsBody');

    if (!modal || !body) return;

    body.innerHTML = `
        <div class="medication-details">
            <div class="detail-section">
                <h3>Patient Information</h3>
                <div class="detail-grid">
                    <div class="detail-item">
                        <label>Patient Name:</label>
                        <span>${currentPatientName || 'N/A'}</span>
                    </div>
                    <div class="detail-item">
                        <label>Patient ID:</label>
                        <span>${medication.patientId || 'N/A'}</span>
                    </div>
                    <div class="detail-item">
                        <label>Patient Status:</label>
                        <span class="status-badge status-${patientStatus.toLowerCase()}">${patientStatus}</span>
                    </div>
                </div>
            </div>
            <div class="detail-section">
                <h3>Medication Information</h3>
                <div class="detail-grid">
                    <div class="detail-item">
                        <label>Medication Name:</label>
                        <span>${medication.medicationName}</span>
                    </div>
                    <div class="detail-item">
                        <label>Type:</label>
                        <span>${medication.medicationType || 'N/A'}</span>
                    </div>
                    <div class="detail-item">
                        <label>Dosage:</label>
                        <span>${medication.dosage}</span>
                    </div>
                    <div class="detail-item">
                        <label>Frequency:</label>
                        <span>${medication.frequency || 'N/A'}</span>
                    </div>
                    <div class="detail-item">
                        <label>Duration:</label>
                        <span>${medication.duration} days</span>
                    </div>
                    <div class="detail-item">
                        <label>Status:</label>
                        <span class="status-badge status-${medication.status || 'active'}">
                            ${medicationSystem.getStatusText(medication.status)}
                        </span>
                    </div>
                </div>
            </div>
            <div class="detail-section">
                <h3>Prescription Details</h3>
                <div class="detail-grid">
                    <div class="detail-item">
                        <label>Prescribed By:</label>
                        <span>${medication.prescribedBy}</span>
                    </div>
                    <div class="detail-item">
                        <label>Start Date:</label>
                        <span>${medicationSystem.formatDate(medication.startDate)}</span>
                    </div>
                    <div class="detail-item">
                        <label>Priority:</label>
                        <span class="priority-badge priority-${medication.priority || 'normal'}">
                            ${(medication.priority || 'normal').toUpperCase()}
                        </span>
                    </div>
                    ${medication.refillReminder ? `
                    <div class="detail-item">
                        <label>Refill Reminder:</label>
                        <span>${medication.refillReminder} days before</span>
                    </div>
                    ` : ''}
                </div>
            </div>
            ${medication.instructions || medication.sideEffects ? `
            <div class="detail-section">
                <h3>Additional Information</h3>
                ${medication.instructions ? `
                <div class="detail-item">
                    <label>Special Instructions:</label>
                    <span>${medication.instructions}</span>
                </div>
                ` : ''}
                ${medication.sideEffects ? `
                <div class="detail-item">
                    <label>Potential Side Effects:</label>
                    <span>${medication.sideEffects}</span>
                </div>
                ` : ''}
            </div>
            ` : ''}
        </div>
    `;

    // Set up edit button in details modal
    const editBtn = document.getElementById('editFromDetailsBtn');
    if (editBtn) {
        editBtn.onclick = () => {
            modal.style.display = 'none';
            editMedication(medicationId);
        };
    }

    modal.style.display = 'flex';
}

function editMedication(medicationId) {
    const medication = medicationSystem.medications.find(m => m.id === medicationId);
    if (!medication) return;

    const form = document.getElementById('medicationForm');
    if (!form) return;
    
    // Fill form with medication data
    Object.keys(medication).forEach(key => {
        const field = form.querySelector(`[name="${key}"]`);
        if (field) {
            field.value = medication[key] || '';
        }
    });

    // Handle patient dropdown selection for edit
    const patientSelect = document.getElementById('patientSelect');
    if (patientSelect && medication.patientId) {
        patientSelect.value = medication.patientId;
        // Trigger change event to update any dependent fields
        patientSelect.dispatchEvent(new Event('change'));
    }

    // Update character counter for instructions
    const instructionsField = document.getElementById('instructions');
    const instructionsCounter = document.getElementById('instructionsCount');
    if (instructionsField && instructionsCounter) {
        instructionsCounter.textContent = instructionsField.value.length;
    }

    document.getElementById('modalTitle').textContent = 'Edit Medication';
    document.getElementById('submitBtn').innerHTML = '<i class="fas fa-save"></i> Update Medication';
    document.getElementById('submitBtn').dataset.medicationId = medicationId;
    document.getElementById('medicationModal').style.display = 'flex';
}

function confirmDeleteMedication(medicationId) {
    const medication = medicationSystem.medications.find(m => m.id === medicationId);
    if (!medication) return;

    // Get current patient info for better confirmation message
    const patientInfo = medicationSystem.patients.find(p => p.id === medication.patientId);
    const patientName = patientInfo ? patientInfo.fullName : medication.patientName;

    const confirmed = confirm(`Are you sure you want to delete the medication "${medication.medicationName}" for ${patientName}?\n\nThis action cannot be undone.`);
    
    if (confirmed) {
        medicationSystem.deleteMedication(medicationId);
    }
}

function exportMedicationsToCSV() {
    if (!medicationSystem || medicationSystem.medications.length === 0) {
        if (medicationSystem) {
            medicationSystem.showToast('No medications to export', 'warning');
        }
        return;
    }

    const medications = medicationSystem.medications;
    const headers = [
        'Patient Name', 'Patient ID', 'Medication Name', 'Medication Type', 
        'Dosage', 'Frequency', 'Prescribed By', 'Start Date', 'Duration', 
        'Status', 'Priority', 'Instructions', 'Side Effects'
    ];
    
    const csvContent = [
        headers.join(','),
        ...medications.map(med => {
            // Get updated patient name from patients database
            const patientInfo = medicationSystem.patients.find(p => p.id === med.patientId);
            const currentPatientName = patientInfo ? patientInfo.fullName : med.patientName;
            
            return [
                `"${(currentPatientName || '').replace(/"/g, '""')}"`,
                `"${(med.patientId || '').replace(/"/g, '""')}"`,
                `"${(med.medicationName || '').replace(/"/g, '""')}"`,
                `"${(med.medicationType || '').replace(/"/g, '""')}"`,
                `"${(med.dosage || '').replace(/"/g, '""')}"`,
                `"${(med.frequency || '').replace(/"/g, '""')}"`,
                `"${(med.prescribedBy || '').replace(/"/g, '""')}"`,
                `"${(med.startDate || '').replace(/"/g, '""')}"`,
                `"${(med.duration || '').replace(/"/g, '""')}"`,
                `"${(med.status || '').replace(/"/g, '""')}"`,
                `"${(med.priority || '').replace(/"/g, '""')}"`,
                `"${(med.instructions || '').replace(/"/g, '""')}"`,
                `"${(med.sideEffects || '').replace(/"/g, '""')}"`
            ].join(',');
        })
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `medications-export-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    medicationSystem.showToast('Medications exported successfully', 'success');
}